#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
竞彩足球每日数据管道
抓取官方接口 -> 解析 -> 规则判定 -> 输出 matches.json + history.json
数据源:
  - 赛事/赔率: webapi.sporttery.cn/gateway/uniform/football/getMatchCalculatorV1.qry
  - 概率/支持率: webapi.sporttery.cn/gateway/jc/common/getSupportRateV1.qry
  - 单场开奖回填: webapi.sporttery.cn/gateway/uniform/football/getFixedBonusV1.qry
history.json 持久化每次判定的记录，比赛结束后自动回填赛果并标注命中/错误。
"""
import json, time, urllib.request, urllib.parse, sys, os, re

# 强制北京时间（CI 容器为 UTC，数据时间戳与"今日"判定必须用东八区）
os.environ.setdefault("TZ", "Asia/Shanghai")
time.tzset()
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# v1.7.132：竞彩「当天批次」/「是否已开赛」统一取权威北京时间，不用会漂移的
# 系统时钟（沙箱休眠恢复实测慢 6.5h，会把当天判成前一天）。
try:
    import beijing_clock
except Exception:
    beijing_clock = None
try:
    from fetch_hkmo import fetch_and_match as fetch_hkmo_data
except Exception:
    fetch_hkmo_data = None

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://www.sporttery.cn/",
    "Accept": "application/json, text/plain, */*",
}

# ---------------------------------------------------------------------------
# v1.7.129：海外 CI 官方接口「全局熔断」+ 单进程网络墙钟
# 根因（2026-11-08 线上 CI 日志实证）：GitHub Actions 机房在美国，
# webapi.sporttery.cn 对其恒定返回 HTTP 567。主赛程能回退 500.com，
# 但后续「赔率历史」30 场、「赛果回填」929 条仍会逐场调用官方接口，
# 每次 fetch() 8 次重试 × 30s 超时 → 16 分钟 + 55 分钟 = 90 分钟被
# timeout-minutes 强杀（run cancelled），流水线永远走不到「构建+部署」，
# 刷新按钮因此永远拿不到新数据。
# 修复：主赛程一旦确认官方接口不可用并回退备用源，即置 _OFFICIAL_DOWN，
# 之后所有 sporttery 官方接口请求瞬时失败（不再重试/不再 sleep），
# 让 CI 在数分钟内跑完全部步骤。本地中国网络官方接口 HTTP 200，
# 永不置位该标志，行为与改动前完全一致。
# ---------------------------------------------------------------------------
_OFFICIAL_DOWN = False
_FETCH_WALL_SEC = float(os.environ.get("JC_FETCH_WALL_SEC", "0") or 0)  # 0=不限（本地）
_FETCH_T0 = time.time()
# 回填 / 赔率历史等「逐条打官方接口」步骤的单步硬墙钟（与网络状态无关）。
# WAF 是概率性的：主赛程可能侥幸放行，后续接口却全被 567，此时熔断标志未置位，
# 逐条 8 次重试 × sleep 会把单步拖到几百秒。硬墙钟保证任何网络情况下都能按时收尾，
# 且赛果回填是幂等的（查不完的记录下一轮自动补），跳过绝不损坏已结算数据。
_STEP_WALL_SEC = float(os.environ.get("JC_STEP_WALL_SEC", "60") or 60)
_WAF_FAILS = [0]


def _note_waf_fail():
    """连续多轮 fetch 全被 WAF 拒绝 → 自动置熔断（覆盖「主赛程侥幸成功但后续全 567」）。"""
    global _OFFICIAL_DOWN
    _WAF_FAILS[0] += 1
    if _WAF_FAILS[0] >= 3 and not _OFFICIAL_DOWN:
        _OFFICIAL_DOWN = True
        print("  [熔断] 连续 %d 轮官方接口被 WAF 拒绝，后续官方请求瞬时短路"
              % _WAF_FAILS[0], flush=True)


def _official_blocked(url):
    """官方接口是否应被瞬时短路（不占用任何网络时间）。"""
    if "webapi.sporttery.cn" not in url:
        return False                       # 500.com 等非官方源不受影响
    if _OFFICIAL_DOWN:
        return True                        # 主赛程已确认官方不可达
    if _FETCH_WALL_SEC and (time.time() - _FETCH_T0) > _FETCH_WALL_SEC:
        return True                        # 单进程网络总预算耗尽（CI 兜底）
    return False
CALC_URL = "https://webapi.sporttery.cn/gateway/uniform/football/getMatchCalculatorV1.qry?channel=c&clientCode=3001"
SUPPORT_URL = "https://webapi.sporttery.cn/gateway/jc/common/getSupportRateV1.qry"
BONUS_URL = "https://webapi.sporttery.cn/gateway/uniform/football/getFixedBonusV1.qry"
HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(HERE, "rules_config.json")

# 规则组基础配置（threshold 可被回测动态调整）
DEFAULT_CONFIG = {
    "组1热度深负":  {"base": 15, "threshold": 15, "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组6深度过热":  {"base": 22, "threshold": 22, "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组2正路确认":  {"base": 8,  "threshold": 8,  "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组3冷门监控":  {"base": 10, "threshold": 10, "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组4异常水位":  {"base": 87.0, "threshold": 87.0, "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组7资金流入":  {"base": 3.0, "threshold": 3.0, "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组8资金背离":  {"base": 3.0, "threshold": 3.0, "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组9凯利价值":  {"base": 1.5, "threshold": 1.5, "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组10排名压制": {"base": 8,  "threshold": 8,  "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组11进球预期": {"base": 3.0, "threshold": 3.0, "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组12半场掌控": {"base": 52.0, "threshold": 52.0, "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
    "组13攻防压制": {"base": 1.0,  "threshold": 1.0,  "samples": 0, "hit": 0, "miss": 0, "hitRate": None},
}

def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                cfg = json.load(f)
            for k, v in DEFAULT_CONFIG.items():
                cfg.setdefault(k, dict(v))
            return cfg
        except Exception as e:
            print("  规则配置读取失败，用默认值:", e, flush=True)
    return {k: dict(v) for k, v in DEFAULT_CONFIG.items()}

def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=1)

def backtest_rules(cfg, records):
    """用已回填的历史记录统计各规则组命中率，样本充足时动态调参"""
    stats = {}
    for r in records:
        if r.get("hitFlag") not in ("hit", "miss"):
            continue
        for h in r.get("hits") or []:
            g = h.get("g")
            if not g:
                continue
            s = stats.setdefault(g, {"hit": 0, "miss": 0})
            if r["hitFlag"] == "hit":
                s["hit"] += 1
            else:
                s["miss"] += 1
    changed = []
    for g, s in stats.items():
        if g not in cfg:
            continue
        n = s["hit"] + s["miss"]
        rate = round(s["hit"] / n * 100, 1)
        cfg[g]["samples"] = n
        cfg[g]["hit"] = s["hit"]
        cfg[g]["miss"] = s["miss"]
        cfg[g]["hitRate"] = rate
        # 样本不足 20 场不调参，避免噪声
        if n >= 20:
            if rate < 40:
                new_t = round(cfg[g]["threshold"] + 2, 1)
                if new_t != cfg[g]["threshold"]:
                    changed.append(f"{g}: 命中率{rate}%<40%，阈值 {cfg[g]['threshold']}→{new_t}")
                cfg[g]["threshold"] = new_t
            elif rate > 65:
                new_t = round(max(cfg[g]["base"] - 1, cfg[g]["threshold"] - 1), 1)
                if new_t != cfg[g]["threshold"]:
                    changed.append(f"{g}: 命中率{rate}%>65%，阈值 {cfg[g]['threshold']}→{new_t}")
                cfg[g]["threshold"] = new_t
    if changed:
        print("  回测调参: " + "；".join(changed), flush=True)
    return cfg

def fetch_odds_history(mid):
    """抓取单场赔率历史，返回各方向开盘→当前变动百分比和初盘赔率

    带 3 小时 TTL 缓存：赔率历史属慢变数据，每 30 分钟刷新一次无必要，
    缓存后每天外部请求从 ~360 次降到 ~60 次，显著降低 sporttery 反爬风险。
    """
    from webcache import ttl_fetch

    def _go():
        url = BONUS_URL + "?clientCode=3001&matchId=" + str(mid)
        fb = fetch(url)
        if not fb.get("success"):
            # 必须抛异常：ttl_fetch 对「返回值」会缓存、对「异常」不缓存。
            # 若这里返回空结构，一次 WAF 拦截就会把空结果缓存 3 小时。
            raise RuntimeError(fb.get("errorMessage") or "赔率历史接口失败")
        oh = (fb.get("value") or {}).get("oddsHistory") or {}
        had_list = oh.get("hadList") or []
        hhad_list = oh.get("hhadList") or []
        mov = {"h": None, "d": None, "a": None}
        had_open = None
        hhad_open = None
        if len(had_list) >= 2:
            first, last = had_list[0], had_list[-1]
            had_open = {"h": to_float(first.get("h")), "d": to_float(first.get("d")), "a": to_float(first.get("a"))}
            for d in ("h", "d", "a"):
                try:
                    f, l = float(first[d]), float(last[d])
                    if f > 0:
                        mov[d] = round((l - f) / f * 100, 1)
                except (TypeError, ValueError, KeyError):
                    pass
        if len(hhad_list) >= 2:
            first_h = hhad_list[0]
            hhad_open = {"h": to_float(first_h.get("h")), "d": to_float(first_h.get("d")), "a": to_float(first_h.get("a")), "goal": first_h.get("goal")}
        return {"mov": mov, "hadOpen": had_open, "hhadOpen": hhad_open}

    try:
        return ttl_fetch("odds_hist:" + str(mid), _go, ttl_hours=3)
    except Exception as e:
        print(f"  赔率历史失败 {mid}: {e}", flush=True)
        return {"mov": {"h": None, "d": None, "a": None}, "hadOpen": None, "hhadOpen": None}

# 竞彩 WAF 反爬（2026-10-15 实测定位）：webapi.sporttery.cn 对单次请求**概率性**返回
# 403（腾讯云 WAF 拦截页）或 200 但空数据（无 matchInfoList），10 连采仅 3 次通过。
# 重试即可通过（8 次内几乎必过，403 响应本身 <1s，重试成本低）。
# 此前 fetch() 无重试：一次 403 就抛异常 → run_daily.sh 按容错设计恢复旧数据、
# 跳过更新（exit 0）→ 定时任务每天"成功"但数据永远停在旧批次
# （用户侧症状：页面提示「数据已过期，云端抓取任务未执行」）。
WAF_RETRY_CODES = (403, 567)     # 403=腾讯云 WAF；567=竞彩自有反爬


def fetch(url, must_contain=None, tries=8):
    """竞彩 webapi JSON 接口（带 WAF 概率拦截重试）。

    must_contain：响应正文必须包含的子串（如 "matchInfoList"）——WAF 会
    概率性放行却返回空数据（success:true 但无内容），用它识别并重试。
    重试耗尽后若最后拿到的是合法 JSON（只是缺该字段），照样返回该 JSON，
    由调用方按「官方暂无数据」降级处理；只有全程被拦/网络失败才返回
    {"success": False, "errorMessage": ...}。
    """
    # v1.7.129：官方接口熔断时瞬时失败，避免海外 CI 逐场 8 次重试 × 30s
    # 累加成 90 分钟超时（详见文件头 _OFFICIAL_DOWN 说明）。
    if _official_blocked(url):
        return {"success": False, "errorMessage": "官方接口不可用(海外CI熔断/网络预算耗尽)"}
    last_body, last_err = "", ""
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=30) as r:
                last_body = r.read().decode("utf-8", "ignore")
                last_err = ""
        except urllib.error.HTTPError as e:
            last_body, last_err = "", "HTTP %s" % e.code
            if e.code not in WAF_RETRY_CODES:
                break                      # 非 WAF 错误（404/500 等）不重试
            time.sleep(0.5 + 0.4 * i)
            continue
        except Exception as e:
            last_body, last_err = "", repr(e)[:80]
            time.sleep(0.5 + 0.4 * i)
            continue
        if must_contain and must_contain not in last_body:
            last_err = "空响应(缺 %s)" % must_contain
            time.sleep(0.5 + 0.4 * i)
            continue
        break
    if last_body:
        try:
            _WAF_FAILS[0] = 0            # 本轮成功，重置连续失败计数
            return json.loads(last_body)
        except Exception as e:
            return {"success": False, "errorMessage": "JSON 解析失败: %r" % e}
    # 耗尽重试仍失败：若失败原因是 WAF 拒绝（403/567），累计自动熔断
    if any(c in (last_err or "") for c in ("HTTP 403", "HTTP 567")):
        _note_waf_fail()
    return {"success": False, "errorMessage": last_err or "未知错误"}

def to_float(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None

def fmt_rate(dic, key):
    v = dic.get(key) if dic else None
    return to_float(v)

def load_history():
    p = os.path.join(HERE, "history.json")
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f).get("records", [])
        except Exception as e:
            print("  history.json 读取失败，重新开始:", e, flush=True)
    return []

def load_bd():
    """读取北单赛程+开奖（与北单管道联动：近况/交锋/交叉验证/亚盘）"""
    bd = {"matches": [], "records": []}
    for key, p in (("matches", "bd_matches.json"), ("records", "bd_history.json")):
        fp = os.path.join(HERE, p)
        if os.path.exists(fp):
            try:
                with open(fp, encoding="utf-8") as f:
                    d = json.load(f)
                bd[key] = d.get("matches" if key == "matches" else "records", []) or d.get("records", [])
            except Exception:
                pass
    return bd

def team_form(records, team, goal_side=None, limit=6):
    """从历史开奖库统计某队近期战绩（主客合计）：返回 {n,w,d,l,wr,form,home_wr,away_wr,hdp_wr}
    goal_side: 'h'/'a' 表示该队是主/客时如何算盘路"""
    rows = []
    for r in records:
        sc = r.get("score") or ""
        if not sc or "-" not in str(sc) and ":" not in str(sc):
            continue
        parts = re.split(r"[-:]", str(sc))
        if len(parts) != 2:
            continue
        try:
            hs, as_ = int(parts[0]), int(parts[1])
        except ValueError:
            continue
        if r.get("home") == team:
            rows.append(("h", hs, as_, r.get("hgoal") or 0, str(r.get("time") or r.get("date") or "")[-11:]))
        elif r.get("away") == team:
            rows.append(("a", hs, as_, r.get("agoal") or 0, str(r.get("time") or r.get("date") or "")[-11:]))
    rows.sort(key=lambda x: x[4], reverse=True)
    rows = rows[:limit]
    if not rows:
        return None
    w = d = l = 0
    hw = aw = hn = an = 0
    hdp_w = hdp_n = 0
    form = []
    for side, hs, as_, g, _ in rows:
        if hs > as_:
            w += 1; form.append("胜")
            if side == "h": hw += 1
            else: aw += 1
        elif hs == as_:
            d += 1; form.append("平")
        else:
            l += 1; form.append("负")
        if side == "h": hn += 1
        else: an += 1
        # 盘路（让球后）
        if side == "h":
            hdp_n += 1
            if hs + g > as_: hdp_w += 1
        else:
            hdp_n += 1
            if as_ + g > hs: hdp_w += 1
    return {
        "n": len(rows), "w": w, "d": d, "l": l,
        "wr": round(w / len(rows) * 100),
        "form": "".join(form),
        "home_wr": round(hw / hn * 100) if hn else None,
        "away_wr": round(aw / an * 100) if an else None,
        "hdp_wr": round(hdp_w / hdp_n * 100) if hdp_n else None,
    }

def attack_stats(records, team, limit=6):
    """从历史开奖库统计某队近期场均进球/失球（近 limit 场有比分的比赛）。
    返回 {n, gf, ga}；样本不足返回 None"""
    rows = []
    for r in records:
        sc = str(r.get("score") or "")
        if not sc or ("-" not in sc and ":" not in sc):
            continue
        parts = re.split(r"[-:]", sc)
        if len(parts) != 2:
            continue
        try:
            hs, as_ = int(parts[0]), int(parts[1])
        except ValueError:
            continue
        tm = str(r.get("time") or r.get("date") or "")[-11:]
        if r.get("home") == team:
            rows.append((hs, as_, tm))
        elif r.get("away") == team:
            rows.append((as_, hs, tm))
    rows.sort(key=lambda x: x[2], reverse=True)
    rows = rows[:limit]
    if not rows:
        return None
    gf = sum(x[0] for x in rows) / len(rows)
    ga = sum(x[1] for x in rows) / len(rows)
    return {"n": len(rows), "gf": round(gf, 2), "ga": round(ga, 2)}

def team_h2h(records, home, away, limit=6):
    """从历史开奖库匹配两队直接交手（方向不限），按时间倒序取 limit 场：
    返回 {n, hw, dd, aw, last:[比分...]}，以 home 视角"""
    rows = []
    for r in records:
        sc = str(r.get("score") or "")
        parts = re.split(r"[-:]", sc)
        if len(parts) != 2:
            continue
        try:
            hs, as_ = int(parts[0]), int(parts[1])
        except ValueError:
            continue
        h, a = r.get("home"), r.get("away")
        if h == home and a == away:
            rows.append(("h", hs, as_, str(r.get("time") or "")[-11:]))
        elif h == away and a == home:
            rows.append(("a", as_, hs, str(r.get("time") or "")[-11:]))
    rows.sort(key=lambda x: x[3], reverse=True)
    rows = rows[:limit]
    if not rows:
        return None
    hw = dd = aw = 0
    last = []
    for side, hs, as_, _ in rows:
        last.append(f"{hs}-{as_}")
        if side == "h":
            if hs > as_: hw += 1
            elif hs == as_: dd += 1
            else: aw += 1
        else:
            if hs > as_: aw += 1
            elif hs == as_: dd += 1
            else: hw += 1
    return {"n": len(rows), "hw": hw, "dd": dd, "aw": aw, "last": " ".join(last)}

def merge_match_records():
    """合并竞彩history为统一赛果库（按队名+日期去重），供近况/H2H使用"""
    recs = []
    for r in load_history():
        if not r.get("result"):
            continue
        res = r["result"]
        if res.get("cancel") or not res.get("score"):
            continue
        sc = re.split(r"[-:]", str(res.get("score", "")))
        if len(sc) != 2:
            continue
        recs.append({"home": r["home"], "away": r["away"], "score": res["score"],
                     "hgoal": int(r.get("goal") or 0), "agoal": 0,
                     "time": r.get("kickoff") or ""})
    # 去重：同一队对同一队同一天只留一条
    seen = set()
    out = []
    for r in recs:
        key = (r["home"], r["away"], str(r["time"])[:10])
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out

# ---------------- 500 球队页近况（服务端渲染，含近期比分/盘路） ----------------
def fetch_html(url, ref, decode="utf-8", t=15, tries=6):
    """抓 HTML 页面（带 WAF/网络重试；与 fetch() 同一套概率拦截对策）。

    重试耗尽仍失败则抛异常——调用方（球队近况/竞彩映射）均有 try/except 兜底，
    静默降级不影响主流程。
    """
    headers = {"Referer": ref, "User-Agent": HEADERS["User-Agent"],
               "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
               "Accept-Language": "zh-CN,zh;q=0.9"}
    last_err = ""
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=t) as r:
                return r.read().decode(decode, "ignore")
        except urllib.error.HTTPError as e:
            last_err = "HTTP %s" % e.code
            if e.code not in WAF_RETRY_CODES:
                break
            time.sleep(0.5 + 0.4 * i)
        except Exception as e:
            last_err = repr(e)[:80]
            time.sleep(0.5 + 0.4 * i)
    raise RuntimeError("页面抓取失败(%s): %s" % (url[:60], last_err or "未知错误"))

def parse_team_form_html(html, tid, team_name, limit=6):
    """解析 500 球队页"近期战绩"表：每行一场比赛，按 球队ID 归属主/客，返回与 team_form 同结构"""
    i = html.find("近期战绩")
    if i < 0:
        return None
    seg = html[i:i+40000]
    rows = re.findall(r"<tr>.*?</tr>", seg, re.S)
    out = []
    for tr in rows[1:]:  # 跳过表头行
        tds = re.findall(r"<td[^>]*>(.*?)</td>", tr, re.S)
        if len(tds) < 8:
            continue
        def txt(s):
            s = re.sub(r"<[^>]+>", "", s)
            return s.replace("&nbsp;", " ").strip()
        dt = txt(tds[1])
        hm = re.search(r'team/(\d+)/', tds[2])
        am = re.search(r'team/(\d+)/', tds[4])
        if not hm or not am:
            continue
        # 比分：形如 3:0 或 2:1，数字可能带/不带 span
        scm = re.search(r'>(\d+)</span>\s*:\s*<span[^>]*>(\d+)<', tds[3]) or re.search(r'>(\d+)</span>\s*:\s*(\d+)', tds[3])
        if not scm:
            continue
        hs, as_ = int(scm.group(1)), int(scm.group(2))
        res = txt(tds[5])
        res = "胜" if res.endswith("胜") else ("平" if res.endswith("平") else ("负" if res.endswith("负") else ""))
        hdp = txt(tds[6])
        hdp = hdp if hdp in ("赢", "输", "走") else ""
        if hm.group(1) == str(tid):
            side = "h"
        elif am.group(1) == str(tid):
            side = "a"
        else:
            continue
        out.append({"side": side, "hs": hs, "as": as_, "res": res, "hdp": hdp,
                    "league": txt(tds[0]), "date": dt})
    out = out[:limit]
    if not out:
        return None
    w = d = l = hw = aw = hn = an = hdp_w = hdp_n = 0
    form = []
    gf_sum = ga_sum = 0
    for r in out:
        if r["hs"] > r["as"]:
            w += 1; form.append("胜")
            if r["side"] == "h": hw += 1
            else: aw += 1
        elif r["hs"] == r["as"]:
            d += 1; form.append("平")
        else:
            l += 1; form.append("负")
        if r["side"] == "h": hn += 1
        else: an += 1
        if r["hdp"]:
            hdp_n += 1
            if r["hdp"] == "赢":
                hdp_w += 1
        gf_sum += r["hs"]; ga_sum += r["as"]
    return {
        "n": len(out), "w": w, "d": d, "l": l,
        "wr": round(w / len(out) * 100),
        "form": "".join(form),
        "home_wr": round(hw / hn * 100) if hn else None,
        "away_wr": round(aw / an * 100) if an else None,
        "hdp_wr": round(hdp_w / hdp_n * 100) if hdp_n else None,
        "gf": round(gf_sum / len(out), 2) if out else None,
        "ga": round(ga_sum / len(out), 2) if out else None,
        "src": "500球队页",
    }

def fetch_team_form(tid, team_name):
    """抓 500 球队页近况（带 6 小时 TTL 缓存，跨天复用）

    原实现按「自然日」缓存，跨天会重抓 12 队；改为统一 web_cache 的 6 小时 TTL，
    跨天边界也复用上一份近况（球队近况 6 小时变一次对分析无实质影响），
    进一步把 500 球队页请求压到约 48 次/天。
    """
    from webcache import ttl_fetch

    def _go():
        html = fetch_html(f"https://liansai.500.com/team/{tid}/", "https://liansai.500.com/", "gbk")
        time.sleep(0.25)
        return parse_team_form_html(html, tid, team_name)

    try:
        return ttl_fetch("team_form:" + str(tid), _go, ttl_hours=6)
    except Exception as e:
        print(f"  球队页失败 {tid}: {e}", flush=True)
        return None

def fetch_jczq_teamids():
    """抓 500 竞彩页的 场次编号->主客球队500ID 映射（用于抓球队页近况）

    带含日期的 6 小时 TTL 缓存：当天映射不变，30 次/天运行只用 ~4 次真实抓取。
    """
    from webcache import ttl_fetch

    today = time.strftime("%Y-%m-%d")

    def _go():
        html = fetch_html("https://trade.500.com/jczq/", "https://trade.500.com/", "gbk")
        out = {}
        for tr in re.findall(r"<tr[^>]*data-matchnum=\"[^\"]+\"[^>]*>", html):
            g = lambda k: (re.search(k + r'="([^"]*)"', tr) or [None, ""])[1]
            num = g("data-matchnum")
            if not num:
                continue
            out[num] = {"home_id": g("data-homeid"), "away_id": g("data-awayid"),
                        "home": g("data-homesxname"), "away": g("data-awaysxname")}
        return out

    try:
        return ttl_fetch("jczq_teamids:" + today, _go, ttl_hours=6)
    except Exception as e:
        print("  竞彩页抓取失败:", e, flush=True)
        return {}

def cross_check(m, bd_matches):
    """竞彩×北单交叉验证：同一场（队名+日期±1天）两边概率对比。
    北单概率为平均赔率反推（参考模型）。返回 {matched, bdProb, diff, agree}"""
    date = m.get("date") or ""
    # 日期±1天内匹配（北单 scheduleDate 可能与竞彩 businessDate 差一天）
    def near(d):
        try:
            from datetime import datetime, timedelta
            t = datetime.strptime(date[:10], "%Y-%m-%d")
            for off in (-1, 0, 1):
                if str(t + timedelta(days=off))[:10] == str(d)[:10]:
                    return True
        except Exception:
            pass
        return date[:10] == str(d)[:10]
    for bm in bd_matches:
        if bm.get("home") != m.get("home") or bm.get("away") != m.get("away"):
            continue
        if not near(bm.get("date") or ""):
            continue
        p = bm.get("prob")
        if not p or not m.get("hadProb") or not any(v is not None for v in m["hadProb"].values()):
            break
        bd_goal = bm.get("goal", 0)
        # 根据北单盘口类型选择对应赔率：goal=0胜平负用odds，goal≠0让球用hhadOdds
        if bd_goal != 0 and bm.get("hhadOdds"):
            bd_odds = bm["hhadOdds"]
        else:
            bd_odds = bm.get("odds") or {}
        bd_best = max(p, key=p.get)
        jc_had = {k: v for k, v in m["hadProb"].items() if v is not None}
        if not jc_had:
            break
        jc_best = max(jc_had, key=jc_had.get)
        agree = bd_best == jc_best
        diff = round(p[jc_best] - (m["hadProb"][jc_best] or 0), 1)
        return {"matched": True, "bdProb": p, "bdOdds": bd_odds,
                "bdGoal": bd_goal, "jcBest": jc_best, "bdBest": bd_best,
                "agree": agree, "diff": diff,
                "asian": bm.get("asian") or ""}
    return None

def save_history(records):
    p = os.path.join(HERE, "history.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump({"updatedAt": time.strftime("%Y-%m-%d %H:%M:%S"),
                   "total": len(records), "records": records}, f, ensure_ascii=False, indent=1)
    return p

def judge_hit(rec):
    """根据判定方向与赛果判断命中/错误。返回 hit/miss/n-a；未回填返回 None（待开奖）"""
    result = rec.get("result")
    if not result:
        return None  # 尚无赛果，保持待回填
    if result.get("cancel"):
        return "n-a"
    verdict = rec.get("verdict") or {}
    t, d = verdict.get("t"), verdict.get("dir")
    had = result.get("had")
    if not t or not d or not had:
        return "n-a"
    if t == "good":
        return "hit" if had == d else "miss"
    if t in ("bad", "cold"):
        # 危险/冷门 = 预测该方向不会打出
        return "hit" if had != d else "miss"
    return "n-a"

def parse_score(s):
    """把官方比分文本转成 (home, away, had结果) 三元组"""
    if not s:
        return None
    s = str(s).strip()
    if s in ("取消", "延期", "中断"):
        return "cancel"
    for sep in (":", "：", "-"):
        if sep in s:
            parts = s.split(sep)
            if len(parts) == 2:
                try:
                    h, a = int(parts[0]), int(parts[1])
                    had = "h" if h > a else ("a" if a > h else "d")
                    return {"home": h, "away": a, "had": had}
                except ValueError:
                    pass
    return None

def backfill_results(records):
    """对已开赛且未回填的记录调用官方开奖接口回填赛果"""
    now = time.time()
    done = 0
    # v1.7.129：赛果回填提速（CI 90 分钟超时的最大元凶）。
    # 旧逻辑对「已有 result 但缺 halfFullResult」的历史记录也逐条打官方开奖接口，
    # 本地 798 条 × 30s、海外 CI 929 条 × 8 次重试 × 30s → 单独一步就烧 55 分钟。
    # 实测 798 条已有 result 的记录 hitFlag / hhadResult 齐全（缺 0），
    # 命中判定完全不依赖再查一次；半全场 tab 早已下线，halfFullResult 仅剩 2 条为空，
    # 为它重查全库得不偿失。故：已有赛果一律跳过网络请求，只处理真正未开奖的记录。
    _t0 = time.time()
    for rec in records:
        # 单步硬墙钟：无论网络是否被 WAF 概率性拦截，回填最多跑 _STEP_WALL_SEC 秒。
        # 幂等设计 —— 本轮没查完的记录下一轮自动补，绝不损坏已有赛果。
        if time.time() - _t0 > _STEP_WALL_SEC:
            print("  赛果回填达到 %ds 墙钟，剩余记录下一轮补齐" % int(_STEP_WALL_SEC), flush=True)
            break
        if rec.get("result") is not None and rec.get("result") != {}:
            continue
        # 海外 CI 官方接口熔断后，未开奖记录也无法查到赛果，直接整体跳过，
        # 避免对 131 条无赛果记录逐条空等（下一轮网络恢复后自动补齐）。
        if _official_blocked(BONUS_URL):
            break
        kick = rec.get("kickoff") or ""
        if not kick:
            continue
        try:
            kick_ts = time.mktime(time.strptime(kick, "%Y-%m-%d %H:%M"))
        except ValueError:
            continue
        # 开赛 2.5 小时后才查询，等待官方发布开奖结果
        if now < kick_ts + 2.5 * 3600:
            continue
        url = BONUS_URL + "?clientCode=3001&matchId=" + str(rec.get("id", ""))
        try:
            fb = fetch(url)
            v = fb.get("value") or {}
            is_cancel = int(v.get("isCancel") or 0)
            sec = v.get("sectionsNo999") or ""
            score = parse_score(sec)
            if is_cancel:
                rec["result"] = {"score": sec or "取消", "had": None, "cancel": True}
            elif score == "cancel":
                rec["result"] = {"score": sec, "had": None, "cancel": True}
            elif score is not None:
                rec["result"] = {"score": sec, "had": score["had"],
                                 "home": score["home"], "away": score["away"], "cancel": False}
            else:
                # 开奖未发布，保持待回填
                continue
            # 解析半全场官方结果（matchResultList中code=HAFU）
            try:
                mrl = v.get("matchResultList") or []
                for item in mrl:
                    if item.get("code") == "HAFU":
                        comb = item.get("combination", "")  # 如"H:D"=半场主胜全场平
                        parts = comb.split(":")
                        if len(parts) == 2:
                            _map = {"H": "h", "D": "d", "A": "a"}
                            ht = _map.get(parts[0].strip(), "")
                            ft = _map.get(parts[1].strip(), "")
                            if ht and ft:
                                rec["halfFullResult"] = ht + ft  # 如"hd"
                                rec["halfFullDesc"] = item.get("combinationDesc", "")
                        break
            except Exception:
                pass
            rec["hitFlag"] = judge_hit(rec)
            rec["resultAt"] = time.strftime("%Y-%m-%d %H:%M")
            # 让球盘推荐命中判定（竞彩让球胜平负每场都有结果：让胜/让平/让负）
            hv = rec.get("hhadVerdict") or {}
            if hv and hv.get("dir") and score is not None and not is_cancel:
                try:
                    gv = int(hv.get("goal") or rec.get("goal") or 0)
                except (TypeError, ValueError):
                    gv = 0
                adj_home = score["home"] + gv  # 主队+让球数
                hhad_res = "h" if adj_home > score["away"] else ("a" if adj_home < score["away"] else "d")
                rec["hhadResult"] = hhad_res
                # 统一正向判定：推荐方向==实际结果则命中，否则错误
                rec["hhadHit"] = "hit" if hhad_res == hv["dir"] else "miss"
            # 亚指推荐命中判定（基于亚盘盘口准确计算赢盘/输盘/走水）
            av = rec.get("asianVerdict") or {}
            if av and av.get("dir") and score is not None and not is_cancel:
                asian_dir = av["dir"]  # h=上盘, a=下盘
                asian_line_text = av.get("asianLine", "")
                # 亚盘文字转数值（主队让球为正，客队让球为负）
                try:
                    from fetch_hkmo import asian_to_num
                    line_num = asian_to_num(asian_line_text)
                except Exception:
                    line_num = None
                if line_num is not None and line_num != 0:
                    # 确定让球方和盘口绝对值
                    if line_num > 0:
                        # 主队让球，主队=上盘
                        favorite_goals = score["home"]
                        underdog_goals = score["away"]
                    else:
                        # 客队让球，客队=上盘
                        favorite_goals = score["away"]
                        underdog_goals = score["home"]
                    line_abs = abs(line_num)
                    goal_diff = favorite_goals - underdog_goals  # 让球方净胜球
                    # 赢盘判定：净胜球>盘口=上盘赢，净胜球<盘口=下盘赢，净胜球=盘口=走水
                    if goal_diff > line_abs + 0.01:
                        upper_win = True  # 上盘赢
                        push = False
                    elif goal_diff < line_abs - 0.01:
                        upper_win = False  # 下盘赢
                        push = False
                    else:
                        push = True  # 走水
                    if push:
                        rec["asianHit"] = "n-a"  # 走水退本金
                    elif asian_dir == "h":
                        rec["asianHit"] = "hit" if upper_win else "miss"
                    elif asian_dir == "a":
                        rec["asianHit"] = "hit" if not upper_win else "miss"
                    else:
                        rec["asianHit"] = "n-a"
                else:
                    # 平手盘或无法解析盘口，简化为胜负判定
                    if asian_dir == "h":
                        rec["asianHit"] = "hit" if score["home"] > score["away"] else ("n-a" if score["home"] == score["away"] else "miss")
                    elif asian_dir == "a":
                        rec["asianHit"] = "hit" if score["away"] > score["home"] else ("n-a" if score["home"] == score["away"] else "miss")
                    else:
                        rec["asianHit"] = "hit" if score["home"] == score["away"] else "miss"
            # 比分推荐命中判定
            sr = rec.get("scoreRec") or {}
            if sr and sr.get("predicted") and score is not None and not is_cancel:
                actual = f"{score['home']}:{score['away']}"
                rec["scoreActual"] = actual
                if actual == sr["predicted"]:
                    rec["scoreHit"] = "hit"
                elif actual in (sr.get("alternatives") or []):
                    rec["scoreHit"] = "partial"
                else:
                    rec["scoreHit"] = "miss"
            done += 1
            print(f"  回填: {rec.get('num','')} {rec.get('home','')}vs{rec.get('away','')} {sec} -> {rec['hitFlag']}", flush=True)
        except Exception as e:
            print(f"  回填失败 {rec.get('num','')}: {e}", flush=True)
        time.sleep(0.4)
    print(f"  本轮回填 {done} 场", flush=True)
    return records

def backfill_hkmo_history(matches):
    """回填港澳赔率历史记录的赛果和命中判定
    命中逻辑：双方同时降水的方向 = 推荐方向，比赛结果匹配则命中
    赛果来源：今日matches + history.json（竞彩官方赛果）
    """
    history_path = os.path.join(HERE, "hkmo_history.json")
    if not os.path.exists(history_path):
        return
    try:
        with open(history_path, encoding="utf-8") as f:
            history = json.load(f)
    except Exception:
        return
    records = history.get("records", [])
    if not records:
        return
    # 构建比赛赛果映射（按 date|队名 匹配，避免今天未开赛比赛匹配到历史同名比赛赛果）
    score_map = {}
    # 来源1：今日matches
    for m in matches:
        if m.get("result") and m["result"].get("score"):
            mdate = m.get("date", "")
            key = f"{mdate}|{m.get('home','')}vs{m.get('away','')}"
            score_map[key] = m["result"]
    # 来源2：history.json（已完场比赛的赛果 + 普通胜平负推荐方向）
    hist_path = os.path.join(HERE, "history.json")
    verdict_map = {}  # date|队名→普通胜平负推荐方向，用于无港澳降水信号时推导让球盘
    if os.path.exists(hist_path):
        try:
            with open(hist_path, encoding="utf-8") as f:
                hd = json.load(f)
            for r in hd.get("records", []):
                rdate = r.get("date", "")
                if r.get("result") and r["result"].get("score"):
                    key = f"{rdate}|{r.get('home','')}vs{r.get('away','')}"
                    if key not in score_map:
                        score_map[key] = r["result"]
                v = r.get("verdict") or {}
                if v.get("dir"):
                    key = f"{rdate}|{r.get('home','')}vs{r.get('away','')}"
                    verdict_map[key] = v["dir"]
        except Exception:
            pass
    now = time.time()
    done = 0
    for rec in records:
        # 已回填且让球盘/亚指命中也已计算的跳过
        if rec.get("hitFlag") and rec.get("hhadHit") and rec.get("asianHit"):
            continue
        rec_date = rec.get("date", "")
        key = f"{rec_date}|{rec.get('home','')}vs{rec.get('away','')}"
        # 安全检查：比赛未结束（当前时间 < 开赛时间+2.5小时）不回填赛果
        kickoff = rec.get("kickoff", "")
        if kickoff:
            try:
                # kickoff可能包含完整日期(如"2026-09-25 14:00")或仅时间(如"14:00")
                if len(kickoff) >= 10 and kickoff[4] == '-':
                    kt = time.mktime(time.strptime(kickoff, "%Y-%m-%d %H:%M"))
                else:
                    kt = time.mktime(time.strptime(f"{rec_date} {kickoff}", "%Y-%m-%d %H:%M"))
                if now < kt + 2.5 * 3600:
                    continue  # 比赛未结束，跳过回填
            except Exception:
                pass
        # 从bd_history或matches中找赛果
        result = score_map.get(key)
        if not result:
            continue
        score = result.get("score", "")
        if not score or result.get("cancel"):
            rec["result"] = score or "取消"
            rec["hitFlag"] = "n-a"
            done += 1
            continue
        # 解析比分
        try:
            parts = score.replace("：", ":").split(":")
            home_score = int(parts[0])
            away_score = int(parts[1])
        except Exception:
            continue
        # 实际赛果方向
        if home_score > away_score:
            actual = "h"
        elif home_score == away_score:
            actual = "d"
        else:
            actual = "a"
        # 推荐方向 = 双方同时降水的方向
        rec_dirs = rec.get("common_drop_dirs", [])
        if not rec_dirs:
            rec["result"] = score
            if not rec.get("hitFlag"):
                rec["hitFlag"] = "n-a"
                done += 1
        else:
            # 取第一个降水方向作为推荐方向
            pick_dir = rec_dirs[0]
            rec["pickDir"] = pick_dir
            rec["result"] = score
            if not rec.get("hitFlag"):
                rec["hitFlag"] = "hit" if actual == pick_dir else "miss"
                done += 1
        # 让球盘推荐：旧版数据或明显不合理时，根据核心方向+让球数推导最有把握方向
        core_dir = rec.get("pickDir") or (rec_dirs[0] if rec_dirs else None)
        if not core_dir:  # 无港澳降水信号时，用普通胜平负推荐方向作为替代核心方向
            core_dir = verdict_map.get(key)
        hhad_v = rec.get("hhadVerdict") or {}
        if hhad_v and core_dir:
            try:
                gv = int(hhad_v.get("goal", 0) or 0)
            except (TypeError, ValueError):
                gv = 0
            hdir = hhad_v.get("dir")
            # 旧版残留判定：txt含"旧版"或"方向一致"（上一版简单映射的标记）
            is_old = ("旧版" in (hhad_v.get("txt") or "")) or ("方向一致" in (hhad_v.get("txt") or ""))
            # 明显不合理判定：与核心方向+让球数的基本逻辑冲突（不可能出现的结果）
            is_unreasonable = False
            if core_dir == "h":  # 主胜
                if gv > 0 and hdir != "h":  # 主队受让还赢球→必让胜
                    is_unreasonable = True
                elif gv == -1 and hdir == "a":  # 让1球主胜→不可能让负（赢球让1球至少平）
                    is_unreasonable = True
            elif core_dir == "a":  # 客胜
                if gv < 0 and hdir != "a":  # 主队让球还输球→必让负
                    is_unreasonable = True
                elif gv == 1 and hdir == "h":  # 受让1球客胜→不可能让胜
                    is_unreasonable = True
            elif core_dir == "d":  # 平局
                if gv < 0 and hdir == "h":  # 主队让球+平局→让球后主负，不可能让胜
                    is_unreasonable = True
                elif gv > 0 and hdir == "a":  # 主队受让+平局→让球后主胜，不可能让负
                    is_unreasonable = True
            if is_old or is_unreasonable:
                # 根据核心方向+让球数推导最有把握的让球盘方向（条件概率最高）
                if core_dir == "h":  # 主胜
                    if gv > 0:
                        derived_dir, derived_txt = "h", "推荐让胜（主胜+主队受让，必让胜）"
                    elif gv == -1:
                        derived_dir, derived_txt = "h", "推荐让胜（主胜+让1球，赢2球+概率最高约55%）"
                    elif gv == -2:
                        derived_dir, derived_txt = "d", "推荐让平（主胜+让2球，赢2球走让平概率最高）"
                    else:
                        derived_dir, derived_txt = "a", f"推荐让负（主胜+让{abs(gv)}球，穿盘难度大）"
                elif core_dir == "a":  # 客胜
                    if gv < 0:
                        derived_dir, derived_txt = "a", "推荐让负（客胜+主队让球，必让负）"
                    elif gv == 1:
                        derived_dir, derived_txt = "a", "推荐让负（客胜+受让1球，客赢1球概率最高约55%）"
                    elif gv == 2:
                        derived_dir, derived_txt = "d", "推荐让平（客胜+受让2球，客赢2球走让平概率最高）"
                    else:
                        derived_dir, derived_txt = "h", f"推荐让胜（客胜+受让{gv}球，客穿盘难度大）"
                else:  # 平局
                    if gv < 0:
                        derived_dir, derived_txt = "a", "推荐让负（平局+主队让球，让球后主负）"
                    else:
                        derived_dir, derived_txt = "h", "推荐让胜（平局+主队受让，让球后主胜）"
                rec["hhadVerdict"] = {
                    "t": "good", "txt": derived_txt, "dir": derived_dir,
                    "stars": 3, "score": 1.0,
                    "reasons": [f"核心{ {'h':'主胜','d':'平局','a':'客胜'}.get(core_dir, core_dir)}+让球{gv}→{ {'h':'让胜','d':'让平','a':'让负'}.get(derived_dir, derived_dir)}（条件概率最高）"],
                    "goal": hhad_v.get("goal", "0")
                }
                hhad_v = rec["hhadVerdict"]
                if rec.get("hhadHit"):
                    del rec["hhadHit"]
        # 让球盘推荐命中判定
        if hhad_v and hhad_v.get("dir") and not rec.get("hhadHit"):
            try:
                gv = int(hhad_v.get("goal", 0) or 0)
            except (TypeError, ValueError):
                gv = 0
            adj_home = home_score + gv
            if adj_home > away_score:
                hhad_res = "h"
            elif adj_home < away_score:
                hhad_res = "a"
            else:
                hhad_res = "d"
            hhad_dir = hhad_v["dir"]
            # 竞彩让球胜平负每场都有结果，统一正向判定：推荐方向==实际结果则命中
            rec["hhadHit"] = "hit" if hhad_res == hhad_dir else "miss"
        # 亚指推荐命中判定（基于亚盘盘口，比赛结果走水时n-a）
        asian_v = rec.get("asianVerdict") or {}
        if asian_v and asian_v.get("dir") and not rec.get("asianHit"):
            asian_dir = asian_v["dir"]
            asian_line_text = asian_v.get("asianLine", "")
            try:
                from fetch_hkmo import asian_to_num
                line_num = asian_to_num(asian_line_text)
            except Exception:
                line_num = None
            if line_num is not None and line_num != 0:
                if line_num > 0:
                    favorite_goals = home_score
                    underdog_goals = away_score
                else:
                    favorite_goals = away_score
                    underdog_goals = home_score
                line_abs = abs(line_num)
                goal_diff = favorite_goals - underdog_goals
                if goal_diff > line_abs + 0.01:
                    upper_win = True
                    push = False
                elif goal_diff < line_abs - 0.01:
                    upper_win = False
                    push = False
                else:
                    push = True
                if push:
                    rec["asianHit"] = "n-a"
                elif asian_dir == "h":
                    rec["asianHit"] = "hit" if upper_win else "miss"
                elif asian_dir == "a":
                    rec["asianHit"] = "hit" if not upper_win else "miss"
                else:
                    rec["asianHit"] = "n-a"
            else:
                if asian_dir == "h":
                    rec["asianHit"] = "hit" if home_score > away_score else ("n-a" if home_score == away_score else "miss")
                elif asian_dir == "a":
                    rec["asianHit"] = "hit" if away_score > home_score else ("n-a" if home_score == away_score else "miss")
                else:
                    rec["asianHit"] = "hit" if home_score == away_score else "miss"
        done += 1
    history["records"] = records
    with open(history_path, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=1)
    print(f"  港澳历史回填 {done} 场", flush=True)

def merge_model_predict(matches):
    """v1.7.69：把 score_predict.json（football-data 稳定源 + 自建 Poisson 模型，
    不受 Cloudflare 封锁影响）的预测合并进每场比赛的 m['modelPred'] = {h, a}，
    作为 WhoScored 缺失时的兜底，确保【所有】比赛卡片在源站被封时仍有预测可看
    （WhoScored 优先，模型兜底）。

    匹配：score_predict 中文队名(标准全称) ↔ matches 中文队名(竞彩简称) 经 zh_norm
    归一后精确相等；不匹配时再用「互为前缀」模糊兜底（町田泽维⊂町田泽维亚 自动命中）。
    不再限制只用 jcNum/num（竞彩），覆盖全部在售比赛；且只要该场已有 WhoScored
    源站预测(predH)就跳过，避免重复。"""

    def _name_sim(a, b):
        """队名相容：完全相等，或互为前缀（竞彩简称 vs 标准全称，如 町田泽维⊂町田泽维亚）。"""
        if not a or not b:
            return False
        if a == b:
            return True
        return a.startswith(b) or b.startswith(a)

    def _char_sim(a, b):
        """队名字符集重合度（Jaccard）：捕捉非前缀简称（巴黎圣曼 vs 巴黎圣日耳曼、
        埃沃斯堡 vs 埃尔沃斯堡、谢菲联 vs 谢菲尔德联——前缀匹配全部失手）。"""
        if not a or not b:
            return 0.0
        sa, sb = set(a), set(b)
        inter = len(sa & sb)
        return inter / len(sa | sb) if (sa | sb) else 0.0

    try:
        import sys as _sys
        _sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from team_map import TEAM_EN2ZH, zh_norm
    except Exception as _e:
        print("  [模型兜底] team_map 导入失败，跳过：%s" % _e, flush=True)
        return
    _here = os.path.dirname(os.path.abspath(__file__))
    _sp = os.path.join(_here, "score_predict.json")
    if not os.path.exists(_sp):
        return
    try:
        _data = json.load(open(_sp, encoding="utf-8"))
    except Exception:
        return
    _sps = _data.get("matches") or []
    _idx = {}        # 精确键 (h_norm, a_norm) -> rec
    _fuzzy = []      # (h_norm, a_norm, rec) 供模糊兜底扫描
    _bydate = {}     # v1.7.71：日期 -> [(h_norm, a_norm, rec)]，同日字符重合兜底
    for _r in _sps:
        if _r.get("predH") is None:
            continue
        _h = zh_norm(TEAM_EN2ZH.get(_r.get("home"), _r.get("home")) or "")
        _a = zh_norm(TEAM_EN2ZH.get(_r.get("away"), _r.get("away")) or "")
        if not (_h and _a):
            continue
        _idx.setdefault((_h, _a), _r)   # 同一对阵首条优先（通常唯一）
        _fuzzy.append((_h, _a, _r))
        _d = (_r.get("utcDate") or _r.get("date") or "")[:10]
        if _d:
            _bydate.setdefault(_d, []).append((_h, _a, _r))
    _n = 0
    for m in matches:
        if m.get("modelPred"):
            continue
        if m.get("predH") is not None:   # 已有 WhoScored 源站预测，无需兜底
            continue
        _h = zh_norm(m.get("home") or "")
        _a = zh_norm(m.get("away") or "")
        if not (_h and _a):
            continue
        _rec = _idx.get((_h, _a)) or _idx.get((_a, _h))
        if not _rec:
            # 模糊兜底1：竞彩简称 vs 标准全称（互为前缀）匹配
            for (_fh, _fa, _r) in _fuzzy:
                if (_name_sim(_h, _fh) and _name_sim(_a, _fa)) or \
                   (_name_sim(_h, _fa) and _name_sim(_a, _fh)):
                    _rec = _r
                    break
        if not _rec:
            # 模糊兜底2（v1.7.71）：同一场日 + 双方队名字符重合度≥0.6——
            # 非前缀简称（巴黎圣曼/埃沃斯堡/谢菲联）自动命中；同日限定保证不会误配
            _cands = _bydate.get((m.get("date") or "")) or []
            for (_fh, _fa, _r) in _cands:
                if _char_sim(_h, _fh) >= 0.6 and _char_sim(_a, _fa) >= 0.6:
                    _rec = _r
                    break
                if _char_sim(_h, _fa) >= 0.6 and _char_sim(_a, _fh) >= 0.6:
                    _rec = _r
                    break
        if _rec:
            m["modelPred"] = {"h": _rec.get("predH"), "a": _rec.get("predA")}
            _n += 1
    if _n:
        print("  [模型兜底] %d 场合并 score_predict 预测（WhoScored 缺失时兜底显示）" % _n, flush=True)


def main():
    print("[1/5] 抓取赛事与赔率...", flush=True)
    # must_contain：WAF 会概率性放行却返回空数据（success:true 但无 matchInfoList，
    # 实测约 1/15），带上该参数后空响应也会触发重试；重试后仍是合法空响应时
    # 走下方「官方暂无在售比赛」降级路径。
    global _OFFICIAL_DOWN
    # 每轮先清熔断标记；只有本轮官方接口确实不可用才重新写，避免上一轮
    # 熔断残留导致下一轮（网络恢复）被部署守卫误判。
    _down_flag = os.path.join(HERE, ".ci_official_down")
    try:
        os.remove(_down_flag)
    except OSError:
        pass
    calc = fetch(CALC_URL, must_contain="matchInfoList")
    matches = []
    match_ids = []
    blocks = []
    if not calc.get("success"):
        # v1.7.129：主赛程官方接口不可用（海外 CI 恒定 567）→ 置全局熔断。
        # 后续赔率历史 / 支持率 / 赛果回填等所有 sporttery 官方请求将被
        # fetch() 瞬时短路，CI 从 90 分钟超时压缩到数分钟内跑完全部步骤。
        # 同时落标记文件，供 run_daily.sh 的「残缺部署守卫」识别：
        # 海外 CI 只有 500.com 残缺赛程，绝不能让它部署覆盖生产完整数据。
        _OFFICIAL_DOWN = True
        try:
            with open(_down_flag, "w", encoding="utf-8") as _f:
                _f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " official api down (overseas CI)\n")
        except OSError:
            pass
        # 官方接口不可用 -> 回退备用源 500.com。
        # 背景：竞彩官方接口封锁海外 IP（GitHub Actions 机房在美国，稳定返回
        # HTTP 567），而 500.com 竞彩页面海外实测可达（HTTP 200）且数据为服务端
        # 渲染。回退后流水线在任何网络环境都能拿到竞彩赛程与赔率，不再整体中断。
        print("  官方接口不可用（%s），回退备用源 500.com ..."
              % (calc.get("errorMessage") or "无错误信息"), flush=True)
        try:
            from fetch_500 import fetch_jczq_500
            _fb = fetch_jczq_500()
        except Exception as _e:
            print("  备用源异常: %s" % _e, flush=True)
            _fb = None
        if not _fb:
            raise RuntimeError("计算器接口失败: " + str(calc.get("errorMessage", ""))
                               + "（备用源 500.com 同样不可用）")
        matches = _fb
        print("  备用源 500.com 抓到 %d 场" % len(matches), flush=True)
    else:
        blocks = calc.get("value", {}).get("matchInfoList", []) or []
        if not blocks:
            # 官方「成功但无在售」同样要兜底：竞彩在凌晨/停售时段会返回 0 场，
            # 而 500.com 页面仍挂着当日未开赛的场次，取它可避免页面一片空白。
            print("  官方暂无在售比赛（可能全部已开赛/停售），尝试备用源 500.com 补充...", flush=True)
            try:
                from fetch_500 import fetch_jczq_500
                _fb2 = fetch_jczq_500()
            except Exception as _e:
                print("  备用源异常: %s" % _e, flush=True)
                _fb2 = None
            if _fb2:
                matches = _fb2
                print("  备用源 500.com 补充 %d 场" % len(matches), flush=True)
            else:
                print("  备用源同样无数据，仅执行历史回填...", flush=True)
    for block in blocks:
        date = block.get("businessDate", "")
        for m in block.get("subMatchList", []):
            mid = str(m.get("matchId", ""))
            had = m.get("had") or {}
            hhad = m.get("hhad") or {}
            # 强弱悬殊比赛可能只开让球盘(hhad)不开胜平负(had)，只要有一个就保留
            if not had and not hhad:
                continue
            match_date = m.get("matchDate") or date
            match_time = (m.get("matchTime") or "")[:5]
            # 官方排名形如 "[日职3]" / "[日职14]"，提取纯数字
            def rank_num(rk):
                s = re.sub(r"\D", "", rk or "")
                return int(s) if s else None
            # 总进球玩法赔率 s0..s7（进0~7球），算期望进球
            ttg = m.get("ttg") or {}
            ttg_odds = {i: to_float(ttg.get(f"s{i}")) for i in range(8)}
            inv = [1.0/o for o in ttg_odds.values() if o and o > 0]
            goals_exp = None
            if inv:
                tot = sum(inv)
                probs = {i: (1.0/o)/tot for i, o in ttg_odds.items() if o and o > 0}
                goals_exp = round(sum(i*p for i, p in probs.items()), 2)
            # 半全场赔率：hh=主胜/主胜, aa=客胜/客胜, dd=平/平
            hafu = m.get("hafu") or {}
            hh_prob = aa_prob = None
            def imp_prob(od):
                if od and to_float(od) and od != "0":
                    return round(100.0 / to_float(od), 1)
                return None
            hh_prob = imp_prob(hafu.get("hh"))
            aa_prob = imp_prob(hafu.get("aa"))
            matches.append({
                "id": mid,
                "num": m.get("matchNumStr", ""),
                "week": m.get("matchWeek", ""),
                "date": date,
                "kickoff": f"{match_date} {match_time}",
                "time": match_time,
                "league": m.get("leagueAbbName", ""),
                "home": m.get("homeTeamAllName", ""),
                "away": m.get("awayTeamAllName", ""),
                "hr": (m.get("homeRank") or "").strip("[]"),
                "ar": (m.get("awayRank") or "").strip("[]"),
                "hrn": rank_num(m.get("homeRank")),
                "arn": rank_num(m.get("awayRank")),
                "status": m.get("matchStatus", ""),
                "had": {"h": fmt_rate(had, "h"), "d": fmt_rate(had, "d"), "a": fmt_rate(had, "a")},
                "hhad": {"h": fmt_rate(hhad, "h"), "d": fmt_rate(hhad, "d"), "a": fmt_rate(hhad, "a"),
                         "goal": (hhad.get("goalLine") or "")},
                "ttg": ttg_odds,
                "goalsExp": goals_exp,
                "hhProb": hh_prob,
                "aaProb": aa_prob,
            })
            match_ids.append(mid)
    print(f"  共 {len(matches)} 场", flush=True)
    if not matches:
        print("  官方暂无在售比赛，仅执行历史/港澳赛果回填...", flush=True)
        # 无在售比赛时不能直接退出：已开赛比赛（如当天晚场比赛）仍需回填赛果
        try:
            hist_path = os.path.join(HERE, "history.json")
            if os.path.exists(hist_path):
                with open(hist_path, encoding="utf-8") as f:
                    hd = json.load(f)
                hist_records = hd.get("records", [])
                no_result_before = sum(1 for r in hist_records if not r.get("result"))
                hist_backfilled = backfill_results(hist_records)
                for r in hist_backfilled:
                    if r.get("result"):
                        r["hitFlag"] = judge_hit(r)
                save_history(hist_backfilled)
                no_result_after = sum(1 for r in hist_backfilled if not r.get("result"))
                print(f"  历史库回填：{len(hist_records)}条，回填前无赛果{no_result_before}条，回填后无赛果{no_result_after}条", flush=True)
        except Exception as e:
            print(f"  历史库回填失败: {e}", flush=True)
        # 回填港澳赔率历史（函数内部从hkmo_history.json读取并匹配history赛果）
        try:
            backfill_hkmo_history([])
        except Exception as e:
            print(f"  港澳历史回填失败: {e}", flush=True)
        # 同步当天已完场比赛赛果到matches.json（官方停售不返回，页面需显示赛果）
        try:
            m_path = os.path.join(HERE, "matches.json")
            if os.path.exists(m_path):
                with open(m_path, encoding="utf-8") as f:
                    mdata = json.load(f)
                with open(hist_path, encoding="utf-8") as f:
                    hdata = json.load(f)
                h_by_key = {}
                for hr in hdata.get("records", []):
                    h_by_key[f"{hr.get('date')}|{hr.get('home','')}vs{hr.get('away','')}"] = hr
                msynced = 0
                for mx in mdata.get("matches", []):
                    key = f"{mx.get('date')}|{mx.get('home','')}vs{mx.get('away','')}"
                    hr = h_by_key.get(key)
                    if hr and hr.get("result") and not mx.get("result"):
                        mx["result"] = hr["result"]
                        mx["hitFlag"] = hr.get("hitFlag")
                        hkmo = mx.get("hkmo")
                        if hkmo and not hkmo.get("result"):
                            hkmo["result"] = hr["result"].get("score", "")
                            hkmo["hitFlag"] = hr.get("hitFlag") or ""
                        msynced += 1
                if msynced > 0:
                    with open(m_path, "w", encoding="utf-8") as f:
                        json.dump(mdata, f, ensure_ascii=False, indent=2)
                    print(f"  已同步 {msynced} 场当天赛果到matches.json", flush=True)
        except Exception as e:
            print(f"  matches赛果同步失败: {e}", flush=True)
        return []

    print("[2/5] 抓取概率与支持率...", flush=True)
    support = {}
    # 分批请求，避免URL过长
    for i in range(0, len(match_ids), 60):
        chunk = ",".join(match_ids[i:i+60])
        url = SUPPORT_URL + "?matchIds=" + chunk + "&poolCode=hhad,had&sportType=1"
        try:
            sr = fetch(url)
            if sr.get("success") and sr.get("value"):
                support.update(sr["value"])
        except Exception as e:
            print("  支持率请求失败:", e, flush=True)
        time.sleep(0.5)

    print("[3/6] 计算指标与规则判定...", flush=True)
    cfg = load_config()
    for m in matches:
        s = support.get("_" + m["id"]) or {}
        had_s, hhad_s = s.get("HAD") or {}, s.get("HHAD") or {}
        def prob_sup(dic, hk, dk, ak):
            def p(key, k2):
                v = dic.get(key) if dic else None
                if isinstance(v, str) and v.endswith("%"):
                    try: return float(v[:-1])
                    except: return None
                return v
            return {"h": p(hk, None), "d": p(dk, None), "a": p(ak, None)}
        m["hadProb"] = prob_sup(had_s, "hProbability", "dProbability", "aProbability")
        m["hadSup"] = prob_sup(had_s, "hSupportRate", "dSupportRate", "aSupportRate")
        m["hhadProb"] = prob_sup(hhad_s, "hProbability", "dProbability", "aProbability")
        m["hhadSup"] = prob_sup(hhad_s, "hSupportRate", "dSupportRate", "aSupportRate")
        # v1.7.120 数据侧根治「分层串关空白」：CI 海外 IP 官方支持率接口不通时，
        # 走 500.com 备用源只有赔率、没有隐含概率（hadProb 全 None）。下游串关算法
        # 有 `if d_prob < 10: continue`，会把在售场次全部剔除 → 候选池 0 → 三档全空，
        # 页面天天显示「今日无达标组合」。此处从胜平负/让球赔率反推归一化隐含概率
        # （去水位），让备用源数据与官方源结构等价，所有下游模块一并受益。
        if not any((m["hadProb"] or {}).values()):
            m["hadProb"] = implied_from_odds(m.get("had"))
        if not any((m["hhadProb"] or {}).values()):
            m["hhadProb"] = implied_from_odds(
                {k: v for k, v in (m.get("hhad") or {}).items() if k in ("h", "d", "a")})
        m["votes"] = {"h": had_s.get("win"), "d": had_s.get("draw"), "a": had_s.get("lose")}
        m["eValue"] = had_s.get("eValue")
        m["eKey"] = had_s.get("eKey")
        m["absValue"] = had_s.get("absValue")
        # 返还率（备用源 500.com 某些场次缺让球/胜平负赔率，用 .get 兜底避免 KeyError）
        _had = m.get("had") or {}
        h, d, a = _had.get("h"), _had.get("d"), _had.get("a")
        if h and d and a:
            m["returnRate"] = round(1.0 / (1.0/h + 1.0/d + 1.0/a) * 100, 1)
        else:
            m["returnRate"] = None
        m["verdict"], m["hits"], m["score"] = evaluate(m, cfg)

    print("[3.5/6] 抓取赔率历史（资金流向）...", flush=True)
    if _official_blocked(BONUS_URL):
        # 海外 CI：官方赔率历史接口同样 567，逐场请求只会白等（实测 16 分钟全失败）。
        # 走 500.com 备用源的场次本就没有官方赔率历史，直接留空即可。
        print("  官方接口熔断：跳过赔率历史（备用源场次无官方赔率历史）", flush=True)
        for m in matches:
            m["mov"] = {"h": None, "d": None, "a": None}
            m["hadOpen"] = None
            m["hhadOpen"] = None
    else:
        _oh_t0 = time.time()
        for m in matches:
            # 概率性 WAF：主赛程侥幸放行但赔率历史逐场被 567 时，
            # 单步墙钟保证不拖垮整轮（赔率历史属锦上添花，缺了不影响推荐主流程）。
            if time.time() - _oh_t0 > _STEP_WALL_SEC or _official_blocked(BONUS_URL):
                for _m in matches:
                    _m.setdefault("mov", {"h": None, "d": None, "a": None})
                    _m.setdefault("hadOpen", None)
                    _m.setdefault("hhadOpen", None)
                print("  赔率历史达到墙钟/熔断，剩余场次留空（不影响主流程）", flush=True)
                break
            odds_hist = fetch_odds_history(m["id"])
            m["mov"] = odds_hist["mov"]
            m["hadOpen"] = odds_hist["hadOpen"]
            m["hhadOpen"] = odds_hist["hhadOpen"]
            time.sleep(0.4)
    # 赔率变动参与评分后重新判定一次
    for m in matches:
        m["verdict"], m["hits"], m["score"] = evaluate(m, cfg)
    # ===== 智能增强引擎：EV 校准 + 负期望降级（异常时静默跳过，不影响主流程）=====
    try:
        from smart_engine import SmartEngine
        _eng = SmartEngine()
        _n_smart = 0
        _n_down = 0
        for m in matches:
            _r = _eng.predict(m)
            if not _r:
                continue
            m["smart"] = _r
            _n_smart += 1
            _v = m.get("verdict") or {}
            _rs = _v.get("reasons")
            if isinstance(_rs, list):
                _rs.append("智能引擎·校准%.0f%%·EV%+.0f%%·%s" % (
                    _r["p_cal"] * 100, _r["ev"] * 100, _r["advice"]))
            # 正路信号但期望值明显为负 -> 降级为警示，避免误导下注
            if _r.get("type") == "good" and _r.get("ev", 0) < -0.08:
                _v["t"] = "warn"
                _v["stars"] = 0
                _v["txt"] = (_v.get("txt") or "") + "｜智能引擎判定为负期望，已降级为警示"
                _n_down += 1
        print(f"  智能引擎：{_n_smart}/{len(matches)} 场完成 EV 校准，降级 {_n_down} 场", flush=True)
    except Exception as e:
        print(f"  智能引擎跳过: {e}", flush=True)

    # 生成让球盘推荐、亚指推荐、比分推荐
    print("[3.8/6] 生成让球盘/亚指/比分推荐...", flush=True)
    for m in matches:
        core_dir, core_src = get_core_direction(m)
        m["hhadVerdict"] = evaluate_hhad(m, cfg, core_dir)
        m["asianVerdict"] = evaluate_asian(m, cfg, core_dir)
        m["scoreRec"] = gen_score_predict(m)

    print("[4/6] 更新历史记录库...", flush=True)
    records = load_history()
    by_id = {r["id"]: r for r in records}
    now_str = time.strftime("%Y-%m-%d %H:%M")
    new_count = 0
    for m in matches:
        mid = m["id"]
        if mid in by_id:
            # 已存在：若判定为空则用最新判定补充；旧记录补齐推荐方向/星级
            rec = by_id[mid]
            if not rec.get("verdict"):
                rec["verdict"] = m["verdict"]
                rec["hits"] = m["hits"]
                rec["score"] = m["score"]
                rec["prob"] = m["hadProb"]
                rec["sup"] = m["hadSup"]
                rec["hitFlag"] = judge_hit(rec)
            elif rec["verdict"] and not rec["verdict"].get("dir"):
                rec["verdict"]["dir"] = m["score"]["dir"]
                rec["verdict"]["stars"] = m["score"]["stars"]
                rec["verdict"]["score"] = m["score"]["score"]
                rec["verdict"]["reasons"] = m["score"]["reasons"]
                rec["score"] = m["score"]
                rec["hitFlag"] = judge_hit(rec)
            # 补充新推荐字段（若旧记录没有）
            if not rec.get("hhadVerdict"):
                rec["hhadVerdict"] = m.get("hhadVerdict")
            if not rec.get("asianVerdict"):
                rec["asianVerdict"] = m.get("asianVerdict")
            if not rec.get("scoreRec"):
                rec["scoreRec"] = m.get("scoreRec")
        else:
            by_id[mid] = {
                "id": mid, "num": m["num"], "date": m["date"], "kickoff": m["kickoff"],
                "league": m["league"], "home": m["home"], "away": m["away"],
                "goal": (m.get("hhad") or {}).get("goal", ""), "odds": m.get("had") or {},
                "prob": m["hadProb"], "sup": m["hadSup"],
                "hr": m.get("hr"), "ar": m.get("ar"), "hrn": m.get("hrn"), "arn": m.get("arn"),
                "goalsExp": m.get("goalsExp"), "hhProb": m.get("hhProb"), "aaProb": m.get("aaProb"),
                "verdict": m["verdict"], "hits": m["hits"], "score": m["score"],
                "hhadVerdict": m.get("hhadVerdict"), "asianVerdict": m.get("asianVerdict"),
                "scoreRec": m.get("scoreRec"),
                "predAt": now_str, "result": None, "hitFlag": None,
                "hhadHit": None, "asianHit": None, "scoreHit": None,
            }
            new_count += 1
    records = list(by_id.values())
    # 排序：按开赛时间倒序（新→旧）
    records.sort(key=lambda r: r.get("kickoff") or "", reverse=True)
    # 历史永久保存（不设时间窗口），每日追加积累；文件随时间增长，每年约1万条/几MB
    print(f"  历史库共 {len(records)} 条，新增 {new_count} 条（永久保存）", flush=True)

    # 统一修正 hitFlag：无赛果=待回填(None)，有赛果=按规则重算
    for r in records:
        if not r.get("result"):
            r["hitFlag"] = None
        else:
            r["hitFlag"] = judge_hit(r)

    print("[4.5/6] 回测各规则组命中率并调参...", flush=True)
    cfg = backtest_rules(cfg, records)
    save_config(cfg)

    print("[5/6] 回填赛果...", flush=True)
    records = backfill_results(records)
    # 回填历史记录库中未回填的旧记录
    print("[5.05/6] 回填历史记录库未回填赛果...", flush=True)
    try:
        hist_records = load_history()
        hist_backfilled = backfill_results(hist_records)
        save_history(hist_backfilled)
        no_result_before = sum(1 for r in hist_records if not r.get("result"))
        no_result_after = sum(1 for r in hist_backfilled if not r.get("result"))
        print(f"  历史记录库: {len(hist_records)}条, 回填前无赛果{no_result_before}条, 回填后无赛果{no_result_after}条", flush=True)
    except Exception as e:
        print(f"  历史记录库回填失败: {e}", flush=True)

    # 回填高手推荐历史赛果（从history.json按date+num匹配）
    print("[5.06/6] 回填高手推荐历史赛果...", flush=True)
    try:
        expert_hist_path = os.path.join(HERE, "expert_history.json")
        if os.path.exists(expert_hist_path):
            with open(expert_hist_path, encoding="utf-8") as f:
                expert_hist = json.load(f)
            # 建立history.json的date+num -> result映射
            hist_map = {}
            for r in hist_backfilled:
                d = r.get("date", "")
                n = r.get("num", "")
                if d and n:
                    hist_map[f"{d}|{n}"] = r.get("result")
            expert_backfilled = 0
            for expert, recs in expert_hist.items():
                for rec in recs:
                    if rec.get("result") or rec.get("actualScore"):
                        continue
                    d = rec.get("date", "")
                    n = rec.get("num", "")
                    key = f"{d}|{n}"
                    if key in hist_map and hist_map[key]:
                        res = hist_map[key]
                        rec["result"] = res.get("score", "")
                        rec["actualScore"] = res.get("score", "")
                        # 判定命中
                        rec_dir = rec.get("recommendKey", "")
                        had = res.get("had")
                        if had and rec_dir:
                            rec["hit"] = (had == rec_dir)
                        expert_backfilled += 1
            if expert_backfilled > 0:
                with open(expert_hist_path, "w", encoding="utf-8") as f:
                    json.dump(expert_hist, f, ensure_ascii=False, indent=2)
            print(f"  高手推荐历史: 回填{expert_backfilled}条赛果", flush=True)
    except Exception as e:
        print(f"  高手推荐历史回填失败: {e}", flush=True)

    # 注意：save_history移到最后（asianVerdict和BSD赔率更新之后），确保新字段被保存

    # 回填港澳赔率历史记录
    print("[5.1/6] 回填港澳赔率历史...", flush=True)
    try:
        backfill_hkmo_history(matches)
    except Exception as e:
        print(f"  港澳历史回填失败: {e}", flush=True)

    print("[5.5/6] 球队近况 / H2H...", flush=True)
    pool = merge_match_records()
    # 500 球队页近况：只对"有判定/高价值"场次抓（节约请求），其余用自建库
    jc_map = {}
    try:
        jc_map = fetch_jczq_teamids()
    except Exception as e:
        print("  竞彩球队映射失败:", e, flush=True)
    for m in matches:
        m["form"] = {"home": team_form(pool, m["home"], limit=6),
                     "away": team_form(pool, m["away"], limit=6)}
        m["attack"] = {"home": attack_stats(pool, m["home"], limit=6),
                       "away": attack_stats(pool, m["away"], limit=6)}
        # 500 球队页近况（缓存一天）补充：近况 + 攻防（含比分）
        jc = jc_map.get(m["num"])
        if jc:
            fh = fetch_team_form(jc["home_id"], jc["home"])
            fa = fetch_team_form(jc["away_id"], jc["away"])
            if fh:
                m["form"]["home"] = fh
                m["attack"]["home"] = {"n": fh.get("n"), "gf": fh.get("gf"), "ga": fh.get("ga")}
            if fa:
                m["form"]["away"] = fa
                m["attack"]["away"] = {"n": fa.get("n"), "gf": fa.get("gf"), "ga": fa.get("ga")}
        m["h2h"] = team_h2h(pool, m["home"], m["away"], limit=6)
    print(f"  近况/H2H 完成", flush=True)

    # BSD Sports API：伤停/首发/教练/xG/天气/裁判/AI预测
    # 隔离原则（继承接管规范）：结果只写入「独立文件」bsd_data.json，绝不写回核心 matches.json，
    # 避免免费额度耗尽导致部分比赛写入、部分未写，污染核心数据集与模型。
    print("[5.8/6] BSD伤停首发数据...", flush=True)
    try:
        from fetch_bsd import fetch_and_match
        bsd_data = fetch_and_match(matches, cache=True)
        # 独立落盘：核心 matches 列表保持纯净，不被污染
        _bsd_out = {
            "updatedAt": time.strftime("%Y-%m-%d %H:%M:%S"),
            "source": "API-Football (伤停/首发/教练/天气/裁判/AI预测)",
            "independent": True,
            "byNum": bsd_data,
        }
        with open(os.path.join(HERE, "bsd_data.json"), "w", encoding="utf-8") as _f:
            json.dump(_bsd_out, _f, ensure_ascii=False, indent=1)
        bsd_n = len(bsd_data)
        print(f"  BSD匹配 {bsd_n}/{len(matches)} 场（独立文件 bsd_data.json，未污染核心数据）", flush=True)
    except Exception as e:
        print(f"  BSD数据抓取失败: {e}", flush=True)

    # [5.9/6] 香港马会+澳门彩票 赔率（初盘/当前/双方同时降水监控）
    print("[5.9/6] 港澳赔率（香港马会+澳门彩票）...", flush=True)
    hkmo_both_drop = 0
    try:
        if fetch_hkmo_data:
            # 从500彩票网竞彩足球页面获取当日竞彩fid
            try:
                from fetch_hkmo import fetch_jc_fids, name_similar
                jc_fids = fetch_jc_fids()
                print(f"  500竞彩页面获取 {len(jc_fids)} 场fid", flush=True)
                target_bd = []
                for m in matches:
                    key = f"{m.get('home','')}vs{m.get('away','')}"
                    fid_info = jc_fids.get(key)
                    if not fid_info:
                        # 模糊匹配队名（500页面常用简称）
                        for jk, jv in jc_fids.items():
                            jh = jv["home"]
                            ja = jv["away"]
                            mh = m.get('home','')
                            ma = m.get('away','')
                            if name_similar(jh, mh) and name_similar(ja, ma):
                                fid_info = jv
                                break
                    if fid_info:
                        target_bd.append({
                            "fid": fid_info["fid"], "home": m.get('home',''), "away": m.get('away',''),
                            "num": m.get('num',''), "kickoff": m.get('kickoff',''),
                            "league": fid_info.get("league",""), "asian": "",
                        })
                print(f"  竞彩匹配500页面 {len(target_bd)} 场，开始抓取港澳赔率...", flush=True)
                hkmo_data = fetch_hkmo_data(target_bd)
                hkmo_matches = hkmo_data.get("matches", [])
                hkmo_both_drop = hkmo_data.get("both_drop_count", 0)
                # 按队名匹配到竞彩比赛
                hkmo_by_team = {}
                for hm in hkmo_matches:
                    key = f"{hm.get('home','')}vs{hm.get('away','')}"
                    hkmo_by_team[key] = hm
                for m in matches:
                    key = f"{m.get('home','')}vs{m.get('away','')}"
                    if key in hkmo_by_team:
                        m["hkmo"] = hkmo_by_team[key]
                    else:
                        # 模糊匹配
                        for hm in hkmo_matches:
                            if name_similar(hm.get('home',''), m.get('home','')) and name_similar(hm.get('away',''), m.get('away','')):
                                m["hkmo"] = hm
                                break
                print(f"  港澳赔率匹配 {len([m for m in matches if m.get('hkmo')])}/{len(matches)} 场，双方同时降水 {hkmo_both_drop} 场", flush=True)
            except Exception as e:
                print(f"  500竞彩页面港澳抓取失败: {e}", flush=True)
        else:
            print("  港澳赔率模块不可用，跳过", flush=True)
    except Exception as e:
        print(f"  港澳赔率抓取失败: {e}", flush=True)

    # 港澳赔率抓取后重新生成让球盘和亚指推荐（依赖hkmo数据，核心方向可能变化）
    for m in matches:
        core_dir, core_src = get_core_direction(m)
        m["hhadVerdict"] = evaluate_hhad(m, cfg, core_dir)
        m["asianVerdict"] = evaluate_asian(m, cfg, core_dir)
    # 同步更新历史记录中的hhadVerdict和asianVerdict（若旧记录为null）
    for m in matches:
        mid = m["id"]
        if mid in by_id:
            if not by_id[mid].get("hhadVerdict"):
                by_id[mid]["hhadVerdict"] = m.get("hhadVerdict")
            if not by_id[mid].get("asianVerdict"):
                by_id[mid]["asianVerdict"] = m.get("asianVerdict")

    # 同步更新港澳赔率历史记录中的hhadVerdict和asianVerdict
    try:
        hkmo_hist_path = os.path.join(HERE, "hkmo_history.json")
        if os.path.exists(hkmo_hist_path):
            with open(hkmo_hist_path, encoding="utf-8") as f:
                hkmo_hist = json.load(f)
            hkmo_records = hkmo_hist.get("records", [])
            # 按队名匹配
            match_by_team = {}
            for m in matches:
                key = f"{m.get('home','')}vs{m.get('away','')}"
                match_by_team[key] = m
            updated = 0
            for rec in hkmo_records:
                key = f"{rec.get('home','')}vs{rec.get('away','')}"
                if key in match_by_team:
                    m = match_by_team[key]
                    if not rec.get("hhadVerdict") and m.get("hhadVerdict"):
                        rec["hhadVerdict"] = m["hhadVerdict"]
                        updated += 1
                    if not rec.get("asianVerdict") and m.get("asianVerdict"):
                        rec["asianVerdict"] = m["asianVerdict"]
                        updated += 1
            if updated > 0:
                hkmo_hist["records"] = hkmo_records
                with open(hkmo_hist_path, "w", encoding="utf-8") as f:
                    json.dump(hkmo_hist, f, ensure_ascii=False, indent=1)
                print(f"  港澳历史同步推荐字段 {updated} 项", flush=True)
    except Exception as e:
        print(f"  港澳历史同步推荐失败: {e}", flush=True)

    # 同步推荐字段后再次回填，计算让球盘和亚指推荐的命中
    try:
        backfill_hkmo_history(matches)
    except Exception as e:
        print(f"  港澳历史二次回填失败: {e}", flush=True)

    # [5.10/6] BSD多博彩公司实时赔率（Pinnacle/Bet365/1xBet等权威博彩公司+水位变动）
    # 隔离原则（继承接管规范）：赔率结果只写入「独立文件」odds_bsd.json，
    # 绝不写回核心 matches 列表（matches.json），也不进入 history.json（模型训练数据）。
    # 前端从独立全局 ODDS_BSD 读取，本源与模型/核心数据零耦合。
    print("[5.10/6] BSD多博彩公司实时赔率（Pinnacle/Bet365等，独立源）...", flush=True)
    try:
        from fetch_odds_bsd import fetch_and_match as fetch_odds_bsd_data
        odds_bsd_data = fetch_odds_bsd_data(matches)
        odds_bsd_matches = odds_bsd_data.get("matches", [])
        # 独立落盘：核心 matches 列表保持纯净，不被污染
        _obsd_out = {
            "updatedAt": time.strftime("%Y-%m-%d %H:%M:%S"),
            "source": "The Odds API (Pinnacle/Bet365 等)",
            "independent": True,
            "matches": odds_bsd_matches,
            "total_movements": odds_bsd_data.get("total_movements", 0),
        }
        with open(os.path.join(HERE, "odds_bsd.json"), "w", encoding="utf-8") as _f:
            json.dump(_obsd_out, _f, ensure_ascii=False, indent=1)
        odds_bsd_n = len(odds_bsd_matches)
        print(f"  BSD多博彩赔率匹配 {odds_bsd_n}/{len(matches)} 场（独立文件 odds_bsd.json），"
              f"赔率变动 {odds_bsd_data.get('total_movements', 0)} 次", flush=True)
    except Exception as e:
        print(f"  BSD多博彩赔率抓取失败: {e}", flush=True)

    # 串关历史回查（v1.7.34：必须放在 load_locked_parlay 之前！）
    # 先判定、后门禁：已开奖的腿（如已停售的周三003，20:32 已回填 0:3）先把
    # 含它的 pending 档位判成 miss，停售腿门随后只删「真的还没开赛又买不了」
    # 的档位。旧顺序（门禁先删、回查后判）会把用户实际跟过的推荐直接删掉——
    # 2026-10-21 实测：20:32 批次拿到 003 赛果的同一秒，含 003 的三条 pending
    # 已被停售腿门删除，历史里查无此组，用户无法对账。
    parlay_history = check_parlay_history()

    # 串关推荐：当天首次成功生成即锁定发布，之后不再改动已发布档位；
    # 尚未发布过的档位允许补生成（只增不改）——推荐一旦发布就不可篡改，
    # 用户翻查历史时看到的必须和当初发布的完全一致。
    # v1.7.34：传入当日 matches，腿已停售的 pending 档位自动解锁重生（推荐必须可下单）。
    locked_safe, locked_high = load_locked_parlay(matches)
    if locked_safe or locked_high:
        # 只要今天发布过任何一档，该档即锁定，后续跑批无权改写
        safe_parlay = locked_safe if locked_safe else None
        high_odds_parlay = None  # 高倍串关已移除
        gen_at = (locked_safe or locked_high).get('generatedAt', '')
        # 补生成：当天还没发布过的档位（首发时该档无达标组合，后来赔率变化达标了）。
        # 只增不改——已发布档位永远保持原样，绝不被后续跑批覆盖。
        _missing = [k for k in ("parlay2", "parlay3", "parlay4")
                    if not (locked_safe or {}).get(k)]
        if _missing:
            _fresh = gen_safe_parlay(matches) or {}
            _filled = {k: _fresh[k] for k in _missing
                       if _fresh.get(k) and _fresh[k].get("legs")}
            if _filled:
                if not safe_parlay:
                    safe_parlay = {"generatedAt": gen_at,
                                   "candidateCount": _fresh.get("candidateCount", 0),
                                   "strategy": "中倍稳串（今日已锁定，不再变动）",
                                   "locked": True}
                safe_parlay.update(_filled)
                try:
                    save_parlay_history(_filled, None)
                except Exception as e:
                    print(f"  串关历史保存失败: {e}", flush=True)
                print(f"  串关补生成：{len(_filled)} 个未发布档位（已发布档位不变）", flush=True)
        # v1.7.123：锁定语义是「已发布档位绝不改动」，但批次元数据不是已发布内容，
        # 必须补齐——否则定时任务当天重跑覆盖部署后，页面会丢掉批次切换、退化成
        # 单批展示。这里重算只为拿 batches，主批次三档强制同步为今日已发布的原值，
        # 保证用户切到当天批次时看到的与默认完全一致，其余批次作参考。
        if isinstance(safe_parlay, dict) and not safe_parlay.get("batches"):
            try:
                _batched = gen_safe_parlay(matches) or {}
                _blist = _batched.get("batches") or []
                if _blist:
                    _ak = _batched.get("activeBatch")
                    for _b in _blist:
                        if _b.get("batchKey") == _ak:
                            for _k in ("parlay2", "parlay3", "parlay4"):
                                _b[_k] = safe_parlay.get(_k)
                            _b["tierCount"] = sum(1 for _k in ("parlay2", "parlay3", "parlay4")
                                                  if safe_parlay.get(_k))
                            break
                    safe_parlay["batches"] = _blist
                    for _mk in ("activeBatch", "batchDate", "batchLabel", "isToday",
                                "batchNote", "matchCount"):
                        if safe_parlay.get(_mk) is None and _batched.get(_mk) is not None:
                            safe_parlay[_mk] = _batched[_mk]
                    safe_parlay["tierCount"] = sum(1 for _k in ("parlay2", "parlay3", "parlay4")
                                                   if safe_parlay.get(_k))
            except Exception as _e:
                print(f"  串关批次元数据补齐失败（不影响已发布推荐）: {_e}", flush=True)
        print(f"  串关推荐：今日已锁定（{gen_at}），不再变动", flush=True)
    else:
        # 稳胆串关：低赔高信心，追求高命中率（高倍串关已按用户要求永久移除）
        safe_parlay = gen_safe_parlay(matches)
        high_odds_parlay = None
        # v1.7.34：当日无未开球推荐且已无在售候选（赛后场景）时，不落空壳、
        # 不显示「今日无达标」误导卡——今日推荐的归宿是历史战绩区对账
        if safe_parlay and not any(safe_parlay.get(k) for k in ("parlay2", "parlay3", "parlay4")):
            import os as _os
            _pf = _os.path.join(HERE, "parlay_history.json")
            _has_today = False
            try:
                _d = json.load(open(_pf, encoding="utf-8"))
                _has_today = any(r.get("date") == time.strftime("%Y-%m-%d")
                                 for r in _d.get("records", []))
            except Exception:
                pass
            if _has_today:
                safe_parlay = None
        # 保存当天串关推荐到历史记录（仅第一次生成时保存，锁定当天推荐）
        try:
            save_parlay_history(safe_parlay, high_odds_parlay)
        except Exception as e:
            print(f"  串关历史保存失败: {e}", flush=True)
    # 串关历史战绩回查（最终统计：含上方新保存/补生成的当日记录，
    # 判定本身已在 load_locked_parlay 之前做过，这里重算一次拿全量 stats）
    parlay_history = check_parlay_history()

    # 强弱对战分析：筛选实力差距大、得分射手多的比赛
    print("[5.11/6] 强弱对战分析...", flush=True)
    strong_weak = gen_strong_weak_matches(matches)
    
    # 保存强弱对战历史推荐记录（用于赛后追溯命中/错误）
    strongweak_history = save_strongweak_history(strong_weak, matches)

    # 半全场胜平负推荐
    print("[5.12/6] 半全场胜平负推荐...", flush=True)
    half_full = gen_half_full(matches)
    half_full_history = save_half_full_history(half_full, matches)

    # 保存历史记录（在asianVerdict和BSD赔率更新之后，确保新字段被保存）
    hist_path = save_history(records)

    print("[6/6] 输出...", flush=True)
    # 只展示「当前在售、尚未开赛」的竞彩比赛。
    # 竞彩一个销售期是跨天销售的：今天买的票里既有今晚的、也有明天/后天的比赛，
    # 不能按「比赛日期==今天」硬砍，否则会把当前在售、尚未开赛的比赛误删
    # （实测：500.com 在售 7 场，其中 6 场是明天开赛但当天可买，硬过滤只剩 1 场）。
    # 正确标准：保留开赛时间晚于「现在(北京时间)」的比赛（竞彩开赛即停售）；
    # 解析不到时间的场次不过滤，已开赛很久(>3h)的视为不在售剔除。
    import datetime as _dt
    _now = _dt.datetime.utcnow() + _dt.timedelta(hours=8)   # 北京时间 now
    _before = len(matches)

    def _kickoff_dt(m):
        s = (m.get("kickoff") or "").strip()
        for _f in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
            try:
                return _dt.datetime.strptime(s, _f)
            except Exception:
                pass
        d = (m.get("date") or "").strip()
        try:
            return _dt.datetime.strptime(d, "%Y-%m-%d")
        except Exception:
            return None

    def _unsold(m):
        k = _kickoff_dt(m)
        return (k is None) or (k >= _now - _dt.timedelta(hours=3))

    matches = [m for m in matches if _unsold(m)]
    if _before != len(matches):
        print(f"  未开赛过滤：{_before}场 -> {len(matches)}场（剔除已开赛很久的）", flush=True)
    # 过滤后为空兜底：凌晨/停售时段官方返回的常是「上一销售日」的场次，
    # 已开赛很久被滤掉后归零。此时用备用源 500.com 补当前在售场次。
    if not matches:
        try:
            from fetch_500 import fetch_jczq_500
            _fb3 = fetch_jczq_500() or []
        except Exception as _e:
            print("  备用源异常: %s" % _e, flush=True)
            _fb3 = []
        _fb3 = [m for m in _fb3 if _unsold(m)]
        if _fb3:
            matches = _fb3
            print(f"  过滤后为空，备用源 500.com 兜底 {len(matches)} 场", flush=True)
    # v1.7.68：模型预测兜底合并（WhoScored 缺失时竞彩仍有预测可看）
    merge_model_predict(matches)

    out = os.path.join(HERE, "matches.json")
    # v1.7.120 空壳保护：本批次若三档全空（如凌晨在售不足、某接口偶发异常），
    # 不得用空 safeParlay 覆盖磁盘上当日已发布的有效推荐。否则一次抖动就会让
    # 页面整块变空白，且 load_locked_parlay 因当日无历史记录也救不回来。
    _new_empty = not any((safe_parlay or {}).get(k) for k in ("parlay2", "parlay3", "parlay4"))
    if _new_empty and os.path.exists(out):
        try:
            _old = json.load(open(out, encoding="utf-8"))
            _osp = _old.get("safeParlay") or {}
            if any(_osp.get(k) for k in ("parlay2", "parlay3", "parlay4")):
                _today_bj = time.strftime("%Y-%m-%d")
                if (_osp.get("generatedAt") or "")[:10] == _today_bj:
                    safe_parlay = _osp
                    parlay_history = _old.get("parlayHistory") or parlay_history
                    print("  分层串关：本批次无达标组合，沿用当日已发布推荐（防空壳覆盖）", flush=True)
        except Exception as _e:
            print("  分层串关空壳保护跳过: %s" % _e, flush=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump({"updateTime": time.strftime("%Y-%m-%d %H:%M:%S"), "count": len(matches),
                   "matches": matches, "highOddsParlay": high_odds_parlay,
                   "safeParlay": safe_parlay, "parlayHistory": parlay_history,
                   "strongWeak": strong_weak, "strongWeakHistory": strongweak_history,
                   "halfFull": half_full, "halfFullHistory": half_full_history},
                  f, ensure_ascii=False, indent=1)
    print(f"  已写入 {out}（{len(matches)} 场）与 {hist_path}（{len(records)} 条）", flush=True)

    # v1.7.118：高手推荐不再挂在这里。此前它带「北京时间 08:00-23:00」时间门，
    # 且位于本函数最末尾——一旦前面任何一步崩溃（如 500 备用源 KeyError），
    # 高手推荐就永远不执行，数据停更多日无人察觉。现统一由 run_daily.sh
    # 步骤 1.8868 独立无条件执行，并自带失败隔离，与本模块彻底解耦。

    return matches

def rule_weight(cfg, g):
    """规则权重自动寻优：按该规则组历史命中率动态加权。
    样本≥20 时 w = 命中率/50（50% 为基准），封顶 [0.5, 1.8]；样本不足返回 1.0 不调整。"""
    c = cfg.get(g) or {}
    n = c.get("samples") or 0
    if n < 20:
        return 1.0
    rate = c.get("hitRate") if c.get("hitRate") is not None else 50.0
    w = rate / 50.0
    return round(max(0.5, min(1.8, w)), 2)

def evaluate(m, cfg):
    """竞彩版规则判定（阈值由回测配置动态调整）：返回 (verdict, hits, score)
    verdict: {t, txt, dir(推荐方向), stars, score}"""
    hits = []
    prob, sup = m.get("hadProb") or {}, m.get("hadSup") or {}
    rrate = m.get("returnRate")
    # 备用源 500.com 的场次可能没有让球盘（hhad 为空或缺 goal），此处必须容错，
    # 否则整轮抓取崩溃、matches.json 沿用旧快照（页面「数据已过期」红字的根因）。
    goal = (m.get("hhad") or {}).get("goal", 0)

    def diff(d):
        p, s = prob.get(d), sup.get(d)
        if p is None or s is None:
            return None
        return round(s - p, 1)

    t1 = cfg["组1热度深负"]["threshold"]
    t6 = cfg["组6深度过热"]["threshold"]
    t2 = cfg["组2正路确认"]["threshold"]
    t3 = cfg["组3冷门监控"]["threshold"]
    t4 = cfg["组4异常水位"]["threshold"]
    t7 = cfg["组7资金流入"]["threshold"]
    t8 = cfg["组8资金背离"]["threshold"]
    t9 = cfg["组9凯利价值"]["threshold"]
    t10 = cfg["组10排名压制"]["threshold"]
    t11 = cfg["组11进球预期"]["threshold"]
    t12 = cfg["组12半场掌控"]["threshold"]
    t13 = cfg["组13攻防压制"]["threshold"]

    # 组1 热度深负：某方向支持率显著高于概率 -> 该方向过热危险
    for d, name in (("h", "主胜"), ("d", "平局"), ("a", "客胜")):
        dv = diff(d)
        if dv is not None and dv >= t1:
            hits.append({"g": "组1热度深负", "t": "bad", "dir": d,
                         "label": f"{name}支持率{sup[d]}%高于概率{prob[d]}%达{dv}pt，投注过热，该方向危险",
                         "cond": f"{name} 支持率-概率={dv}pt(≥{t1})"})
    # 组6 深度过热
    for d, name in (("h", "主胜"), ("d", "平局"), ("a", "客胜")):
        dv = diff(d)
        if dv is not None and dv >= t6:
            hits.append({"g": "组6深度过热", "t": "bad", "dir": d,
                         "label": f"{name}支持率远超概率{dv}pt，深度过热，机构放任资金涌入",
                         "cond": f"{name} 支持率-概率={dv}pt(≥{t6})"})
    # 组2 正路确认：热门方向(概率>=50)且支持率与概率接近 -> 正路更易打出
    hot = max(("h", "d", "a"), key=lambda d: prob.get(d) or 0)
    hot_p = prob.get(hot) or 0
    if hot_p >= 50:
        dv = diff(hot)
        if dv is not None and abs(dv) < t2:
            hits.append({"g": "组2正路确认", "t": "good", "dir": hot,
                         "label": f"{('主胜','平局','客胜')[('h','d','a').index(hot)]}概率{hot_p}%为热门且支持率偏差仅{dv}pt，方向一致，正路更易打出",
                         "cond": f"热门方向概率{hot_p}%≥50%，支持率-概率={dv}pt(<{t2})"})
    # 组3 冷门监控：让球>=2 且 热门概率>=55 但支持率显著低于概率 -> 小心爆冷
    try:
        gv = int(goal)
    except (TypeError, ValueError):
        gv = 0
    if abs(gv) >= 2 and hot_p >= 55:
        dv = diff(hot)
        if dv is not None and dv <= -t3:
            hits.append({"g": "组3冷门监控", "t": "cold", "dir": hot,
                         "label": f"深盘让球{gv}但{('主胜','平局','客胜')[('h','d','a').index(hot)]}支持率{sup.get(hot)}%低于概率{hot_p}%达{-dv}pt，小心爆冷",
                         "cond": f"让球|{gv}|≥2、热门概率{hot_p}%≥55%、支持率-概率={dv}pt(≤-{t3})"})
    # 组4 异常水位
    if rrate is not None and rrate < t4:
        hits.append({"g": "组4异常水位", "t": "warn", "dir": "",
                     "label": f"胜平负返还率仅{rrate}%，水位异常偏低，谨慎参与",
                     "cond": f"返还率{rrate}%<{t4}%"})

    # 凯利指数 = 赔率 × 官方概率（以返还率为基准，凯利差>0 表示该方向价值偏高）
    kelly, kelly_diff = {}, {}
    for d in ("h", "d", "a"):
        od = (m.get("had") or {}).get(d)
        p = prob.get(d)
        if od and p is not None:
            kelly[d] = round(od * p / 100.0, 3)
            kelly_diff[d] = round(kelly[d] - (rrate or 0) / 100.0, 3)
        else:
            kelly[d], kelly_diff[d] = None, None

    # 组7 资金流入确认：热门方向赔率下降>=阈值 -> 资金流入，强化热门
    mov = m.get("mov") or {}
    mv_hot = mov.get(hot)
    if hot_p >= 45 and mv_hot is not None and mv_hot <= -t7:
        hits.append({"g": "组7资金流入", "t": "good", "dir": hot,
                     "label": f"热门方向{('主胜','平局','客胜')[('h','d','a').index(hot)]}赔率从开盘至今下降{mv_hot}%，资金持续流入，强化打出预期",
                     "cond": f"热门赔率变动={mv_hot}%(≤-{t7})"})
    # 组8 资金背离：热门方向赔率上升>=阈值 -> 资金流出，警示热门
    if hot_p >= 45 and mv_hot is not None and mv_hot >= t8:
        hits.append({"g": "组8资金背离", "t": "bad", "dir": hot,
                     "label": f"热门方向{('主胜','平局','客胜')[('h','d','a').index(hot)]}赔率不降反升{mv_hot}%，资金背离，警惕陷阱",
                     "cond": f"热门赔率变动={mv_hot}%(≥{t8})"})
    # 组9 凯利价值：某方向凯利差显著为正 -> 概率被低估，价值方向
    for d, name in (("h", "主胜"), ("d", "平局"), ("a", "客胜")):
        kd = kelly_diff.get(d)
        if kd is not None and kd * 100 >= t9:
            hits.append({"g": "组9凯利价值", "t": "good", "dir": d,
                         "label": f"{name}凯利指数{kelly[d]}高于返还率{rrate}%，概率或被低估，具备价值",
                         "cond": f"{name} 凯利-返还率={round(kd*100,1)}pt(≥{t9})"})

    # 组10 排名压制：主队排名明显优于客队且主胜热门 -> 实力确认；排名优但市场不认 -> 虚高预警
    hrn, arn = m.get("hrn"), m.get("arn")
    if hrn and arn:
        rank_gap = arn - hrn  # 正值=主队排名更优
        hot_name = ("主胜", "平局", "客胜")[("h", "d", "a").index(hot)]
        if rank_gap >= t10:
            if hot == "h" and hot_p >= 45:
                hits.append({"g": "组10排名压制", "t": "good", "dir": "h",
                             "label": f"主队排名[{m.get('hr')}]优于客队[{m.get('ar')}]达{rank_gap}位且主胜概率{hot_p}%，实力+市场双确认",
                             "cond": f"排名差{rank_gap}位(≥{t10})，主胜概率{hot_p}%≥45%"})
            elif hot == "h" and hot_p < 45:
                hits.append({"g": "组10排名压制", "t": "cold", "dir": "h",
                             "label": f"主队排名[{m.get('hr')}]优于客队[{m.get('ar')}]达{rank_gap}位但主胜概率仅{hot_p}%，排名优势未被市场定价，虚高预警",
                             "cond": f"排名差{rank_gap}位(≥{t10})但主胜概率{hot_p}%<45%"})
        elif rank_gap <= -t10 and hot == "a" and hot_p >= 45:
            hits.append({"g": "组10排名压制", "t": "good", "dir": "a",
                         "label": f"客队排名[{m.get('ar')}]优于主队[{m.get('hr')}]达{-rank_gap}位且客胜概率{hot_p}%，实力+市场双确认",
                         "cond": f"排名差{-rank_gap}位(≥{t10})，客胜概率{hot_p}%≥45%"})

    # 组11 进球预期：总进球期望极高/极低影响让球盘判断（辅助评分，不单独下结论）
    ge = m.get("goalsExp")
    try:
        gv = int(goal)
    except (TypeError, ValueError):
        gv = 0
    if ge is not None and abs(gv) >= 1:
        if ge >= t11:
            hits.append({"g": "组11进球预期", "t": "warn", "dir": hot,
                         "label": f"总进球期望{ge}球偏高，让球{gv}的强队难保不丢球，主胜打出难度加大，谨慎看待",
                         "cond": f"期望进球{ge}≥{t11}、让球{gv}≥1"})
        elif ge <= 2.2 and gv >= 1:
            hits.append({"g": "组11进球预期", "t": "good", "dir": "h",
                         "label": f"总进球期望仅{ge}球偏低，让球{gv}的主队零封概率高，主胜更稳",
                         "cond": f"期望进球{ge}≤2.2、让球{gv}≥1"})

    # 组12 半场掌控：半全场"主/主"或"客/客"隐含概率高 -> 强队全场压制，正路强化
    if m.get("hhProb") is not None and m.get("hhProb") >= t12 and hot == "h":
        hits.append({"g": "组12半场掌控", "t": "good", "dir": "h",
                     "label": f"半全场主/主隐含概率{m['hhProb']}%≥{t12}%，机构预期主队全场压制，强化主胜",
                     "cond": f"主/主隐含概率{m['hhProb']}%≥{t12}%"})
    if m.get("aaProb") is not None and m.get("aaProb") >= t12 and hot == "a":
        hits.append({"g": "组12半场掌控", "t": "good", "dir": "a",
                     "label": f"半全场客/客隐含概率{m['aaProb']}%≥{t12}%，机构预期客队全场压制，强化客胜",
                     "cond": f"客/客隐含概率{m['aaProb']}%≥{t12}%"})

    # 组13 攻防压制：双方近期场均进/失球（北单+竞彩历史池自算）
    atk = m.get("attack") or {}
    ah, aa2 = atk.get("home"), atk.get("away")
    if ah and aa2 and ah["n"] >= 3 and aa2["n"] >= 3:
        h_adv = round(ah["gf"] - aa2["ga"], 2)   # 主队进攻 vs 客队防守净值
        a_adv = round(aa2["gf"] - ah["ga"], 2)   # 客队进攻 vs 主队防守净值
        if h_adv >= t13 and hot == "h":
            hits.append({"g": "组13攻防压制", "t": "good", "dir": "h",
                         "label": f"主队近{ah['n']}场场均进球{ah['gf']} vs 客队近{aa2['n']}场场均失球{aa2['ga']}，攻防净值+{h_adv}，实力压制确认主胜",
                         "cond": f"主攻{ah['gf']}-客防{aa2['ga']}={h_adv}(≥{t13})"})
        if a_adv >= t13 and hot == "a":
            hits.append({"g": "组13攻防压制", "t": "good", "dir": "a",
                         "label": f"客队近{aa2['n']}场场均进球{aa2['gf']} vs 主队近{ah['n']}场场均失球{ah['ga']}，攻防净值+{a_adv}，实力压制确认客胜",
                         "cond": f"客攻{aa2['gf']}-主防{ah['ga']}={a_adv}(≥{t13})"})
        sum_gf = round(ah["gf"] + aa2["gf"], 2)
        ge2 = m.get("goalsExp")
        if ge2 is not None and abs(sum_gf - ge2) >= 1.0:
            hits.append({"g": "组13攻防压制", "t": "warn", "dir": hot,
                         "label": f"双方近期场均进球合计{sum_gf} vs 官方盘口期望{ge2}球，攻防模型与官方分歧，大小球方向谨慎",
                         "cond": f"攻防和{sum_gf} vs 期望{ge2}偏差{round(abs(sum_gf-ge2),2)}(≥1.0)"})

    # 结论优先级: bad > cold > good > warn
    order = {"bad": 0, "cold": 1, "good": 2, "warn": 3}
    hits.sort(key=lambda x: order.get(x["t"], 9))
    verdict = None
    if hits:
        v = hits[0]
        verdict = {"t": v["t"], "txt": v["label"]}

    # 综合信心评分：方向独立打分 -> 推荐方向 + 星级（含规则权重寻优）
    scores = {"h": 0.0, "d": 0.0, "a": 0.0}
    reasons = []
    for h in hits:
        d = h.get("dir")
        if not d:
            continue
        w = rule_weight(cfg, h["g"])
        if h["t"] == "good":
            add = round(1.5 * w, 2)
            scores[d] += add
            reasons.append(f"{h['g']}·{('主胜','平局','客胜')[('h','d','a').index(d)]}+{add}{'×'+str(w) if w != 1.0 else ''}")
        elif h["t"] in ("bad", "cold"):
            sub = round(1.0 * w, 2)
            scores[d] -= sub
            reasons.append(f"{h['g']}·{('主胜','平局','客胜')[('h','d','a').index(d)]}-{sub}{'×'+str(w) if w != 1.0 else ''}")
        elif h["t"] == "warn":
            sub = round(0.5 * w, 2)
            scores[d] -= sub
            reasons.append(f"{h['g']}·{('主胜','平局','客胜')[('h','d','a').index(d)]}-{sub}{'×'+str(w) if w != 1.0 else ''}")
    for d in ("h", "d", "a"):
        pct = mov.get(d)
        if pct is not None and pct <= -t7:
            scores[d] += 1.0
            reasons.append(f"资金流入{('主胜','平局','客胜')[('h','d','a').index(d)]}赔率{pct}%+1.0")
        elif pct is not None and pct >= t8:
            scores[d] -= 1.0
            reasons.append(f"资金流出{('主胜','平局','客胜')[('h','d','a').index(d)]}赔率+{pct}%-1.0")
        kd = kelly_diff.get(d)
        if kd is not None and kd * 100 >= t9:
            scores[d] += 0.5
            reasons.append(f"凯利价值{('主胜','平局','客胜')[('h','d','a').index(d)]}+0.5")
        elif kd is not None and kd * 100 <= -t9:
            scores[d] -= 0.5

    # ========== BSD增强数据维度（伤停/AI预测/教练/天气/裁判/首发）==========
    bsd = m.get("bsd") or {}
    if bsd:
        # 1. 伤停影响：主队伤停多→主胜减分，客队伤停多→客胜减分
        h_inj = bsd.get("injury_count_home", 0) or 0
        a_inj = bsd.get("injury_count_away", 0) or 0
        inj_diff = h_inj - a_inj
        if inj_diff >= 3:  # 主队伤停明显更多
            scores["a"] += 1.5
            scores["h"] -= 0.5
            reasons.append(f"伤停·主队{h_inj}人vs客队{a_inj}人，主队阵容不整→客胜+1.5")
        elif inj_diff <= -3:  # 客队伤停明显更多
            scores["h"] += 1.5
            scores["a"] -= 0.5
            reasons.append(f"伤停·客队{a_inj}人vs主队{h_inj}人，客队阵容不整→主胜+1.5")

        # 2. AI预测方向：从ai_preview中提取预测比分
        ai_preview = bsd.get("ai_preview", "") or ""
        if ai_preview:
            import re
            pred_match = re.search(r'(\d+)\s*[-:]\s*(\d+)', ai_preview)
            if pred_match:
                try:
                    pred_h = int(pred_match.group(1))
                    pred_a = int(pred_match.group(2))
                    if pred_h > pred_a:
                        ai_dir = "h"
                    elif pred_h < pred_a:
                        ai_dir = "a"
                    else:
                        ai_dir = "d"
                    scores[ai_dir] += 2.0
                    reasons.append(f"AI预测·{pred_h}-{pred_a}→{('主胜','平局','客胜')[('h','d','a').index(ai_dir)]}+2.0")
                except (ValueError, IndexError):
                    pass

        # 3. 教练风格：进攻型教练→所在球队胜加分
        home_coach = bsd.get("home_coach") or {}
        away_coach = bsd.get("away_coach") or {}
        h_styles = home_coach.get("styles", []) if isinstance(home_coach, dict) else []
        a_styles = away_coach.get("styles", []) if isinstance(away_coach, dict) else []
        h_attack = any(s in str(h_styles).lower() for s in ['attack', 'pressing', 'offensive'])
        a_attack = any(s in str(a_styles).lower() for s in ['attack', 'pressing', 'offensive'])
        if h_attack and not a_attack:
            scores["h"] += 0.8
            reasons.append(f"教练·主队进攻型({home_coach.get('formation','')})→主胜+0.8")
        elif a_attack and not h_attack:
            scores["a"] += 0.8
            reasons.append(f"教练·客队进攻型({away_coach.get('formation','')})→客胜+0.8")

        # 4. 天气影响：恶劣天气→平局加分
        weather = bsd.get("weather") or {}
        if isinstance(weather, dict):
            temp = weather.get("temperature_c", 20) or 20
            wind = weather.get("wind_speed", 0) or 0
            if temp <= 5 or temp >= 35 or wind >= 30:
                scores["d"] += 0.5
                reasons.append(f"天气·温度{temp}°C/风速{wind}km/h，恶劣天气→平局+0.5")

        # 5. 裁判风格：出牌多的裁判→比赛激烈，分胜负加分
        referee = bsd.get("referee") or {}
        if isinstance(referee, dict):
            yc = referee.get("yellow_cards", 0) or 0
            games = referee.get("career_games", 1) or 1
            yc_per_game = yc / max(games, 1)
            if yc_per_game >= 4:
                scores["d"] -= 0.3
                reasons.append(f"裁判·{referee.get('name','')}场均{yc_per_game:.1f}黄，执法严格→平局-0.3")

        # 6. 预期首发完整性
        lineups = bsd.get("expected_lineups") or {}
        if isinstance(lineups, dict):
            h_lu = lineups.get("home", []) or []
            a_lu = lineups.get("away", []) or []
            h_complete = len(h_lu) >= 10
            a_complete = len(a_lu) >= 10
            if h_complete and not a_complete:
                scores["h"] += 0.5
                reasons.append(f"首发·主队完整({len(h_lu)}人)vs客队不整({len(a_lu)}人)→主胜+0.5")
            elif a_complete and not h_complete:
                scores["a"] += 0.5
                reasons.append(f"首发·客队完整({len(a_lu)}人)vs主队不整({len(h_lu)}人)→客胜+0.5")

    # ========== BSD增强数据维度结束 ==========

    best = max(scores, key=scores.get)
    sc = round(scores[best], 2)
    stars = 5 if sc >= 3.5 else 4 if sc >= 2.5 else 3 if sc >= 1.5 else 2 if sc >= 0.8 else 1 if sc > 0 else 0
    score = {"dir": best, "score": sc, "stars": stars,
             "kelly": {d: kelly[d] for d in "hda"},
             "kellyDiff": {d: (round(kd*100, 1) if kd is not None else None) for d, kd in kelly_diff.items()},
             "mov": mov, "reasons": reasons}
    if verdict:
        verdict["dir"] = best
        verdict["stars"] = stars
        verdict["score"] = sc
        verdict["reasons"] = reasons
    return verdict, hits, score


def get_core_direction(m):
    """获取核心推荐方向（普通胜平负 h/d/a），用于统一让球盘和亚指推荐
    优先级：港澳双方同时降水方向 > 规则引擎综合评分方向 > 胜平负概率最高方向
    """
    # 1. 港澳赔率双方同时降水方向（最权威资金信号）
    hkmo = m.get("hkmo") or {}
    if hkmo.get("both_drop") and hkmo.get("common_drop_dirs"):
        return hkmo["common_drop_dirs"][0], "港澳双方同时降水"
    # 2. 规则引擎综合评分方向
    score = m.get("score") or {}
    if score.get("dir"):
        return score["dir"], "规则引擎综合评分"
    # 3. 胜平负概率最高方向
    prob = m.get("hadProb") or {}
    if prob:
        best = max(("h", "d", "a"), key=lambda d: prob.get(d) or 0)
        return best, "胜平负概率最高"
    return None, "无信号"


def evaluate_hhad(m, cfg, core_dir=None):
    """竞彩让球盘推荐：基于hhad概率/支持率/赔率/初盘变动，返回 {t,txt,dir,stars,score,reasons}
    core_dir: 核心方向（普通胜平负h/d/a），用于确保推荐方向一致性
    """
    hhad = m.get("hhad") or {}
    prob = m.get("hhadProb") or {}
    sup = m.get("hhadSup") or {}
    hhad_open = m.get("hhadOpen") or {}
    goal = hhad.get("goal", "0")
    if not prob or not hhad:
        return None
    # 解析让球数
    try:
        gv = int(goal)
    except (TypeError, ValueError):
        gv = 0
    hits = []
    def diff(d):
        p, s = prob.get(d), sup.get(d)
        if p is None or s is None:
            return None
        return round(s - p, 1)
    t1 = cfg.get("组1热度深负", {}).get("threshold", 15)
    t2 = cfg.get("组2正路确认", {}).get("threshold", 5)
    t7 = cfg.get("组7资金流入", {}).get("threshold", 5)
    t8 = cfg.get("组8资金背离", {}).get("threshold", 5)
    hot = max(("h", "d", "a"), key=lambda d: prob.get(d) or 0)
    hot_p = prob.get(hot) or 0
    dir_names = {"h": "让胜", "d": "让平", "a": "让负"}
    # 组1 热度深负
    for d in ("h", "d", "a"):
        dv = diff(d)
        if dv is not None and dv >= t1:
            hits.append({"t": "bad", "dir": d, "label": f"{dir_names[d]}支持率{sup[d]}%高于概率{prob[d]}%达{dv}pt，投注过热"})
    # 组2 正路确认
    if hot_p >= 50:
        dv = diff(hot)
        if dv is not None and abs(dv) < t2:
            hits.append({"t": "good", "dir": hot, "label": f"{dir_names[hot]}概率{hot_p}%为热门且支持率偏差仅{dv}pt，方向一致"})
    # 资金流入/流出（让球盘初→现）
    mov_hhad = {}
    for d in ("h", "d", "a"):
        od = hhad.get(d)
        op = hhad_open.get(d) if isinstance(hhad_open, dict) else None
        if od and op and op > 0:
            mov_hhad[d] = round((od - op) / op * 100, 1)
    for d in ("h", "d", "a"):
        mv = mov_hhad.get(d)
        if mv is not None and mv <= -t7:
            hits.append({"t": "good", "dir": d, "label": f"{dir_names[d]}赔率从开盘下降{mv}%，资金流入"})
        elif mv is not None and mv >= t8:
            hits.append({"t": "bad", "dir": d, "label": f"{dir_names[d]}赔率上升{mv}%，资金背离"})
    # 评分
    scores = {"h": 0.0, "d": 0.0, "a": 0.0}
    reasons = []
    for h in hits:
        d = h.get("dir")
        if not d:
            continue
        if h["t"] == "good":
            scores[d] += 1.5
            reasons.append(f"让球盘·{dir_names[d]}+1.5")
        elif h["t"] in ("bad", "cold"):
            scores[d] -= 1.0
            reasons.append(f"让球盘·{dir_names[d]}-1.0")

    # ========== BSD增强数据维度（伤停/AI预测/教练/天气/裁判/首发）==========
    bsd = m.get("bsd") or {}
    if bsd:
        # 1. 伤停影响：主队伤停多→主队让球方向减分，客队伤停多→客队让球方向减分
        h_inj = bsd.get("injury_count_home", 0) or 0
        a_inj = bsd.get("injury_count_away", 0) or 0
        inj_diff = h_inj - a_inj  # 正数=主队伤停更多
        if inj_diff >= 3:  # 主队伤停明显更多
            if gv < 0:  # 主队让球：主队伤停多→让胜/让平减分，让负加分
                scores["a"] += 1.5
                scores["h"] -= 0.5
                reasons.append(f"伤停·主队{h_inj}人vs客队{a_inj}人，主队阵容不整→让负+1.5")
            else:  # 主队受让：主队伤停多→让胜减分，让负加分
                scores["a"] += 1.5
                scores["h"] -= 0.5
                reasons.append(f"伤停·主队{h_inj}人vs客队{a_inj}人，主队阵容不整→让负+1.5")
        elif inj_diff <= -3:  # 客队伤停明显更多
            if gv < 0:  # 主队让球：客队伤停多→让胜加分
                scores["h"] += 1.5
                scores["a"] -= 0.5
                reasons.append(f"伤停·客队{a_inj}人vs主队{h_inj}人，客队阵容不整→让胜+1.5")
            else:  # 主队受让：客队伤停多→让胜加分
                scores["h"] += 1.5
                scores["a"] -= 0.5
                reasons.append(f"伤停·客队{a_inj}人vs主队{h_inj}人，客队阵容不整→让胜+1.5")

        # 2. AI预测方向：从ai_preview中提取预测比分，转换为让球方向
        ai_preview = bsd.get("ai_preview", "") or ""
        if ai_preview:
            import re
            # 提取预测比分（如 "Roma 2-0 Torino" 或 "Prediction: Roma 2-0"）
            pred_match = re.search(r'(\d+)\s*[-:]\s*(\d+)', ai_preview)
            if pred_match:
                try:
                    pred_h = int(pred_match.group(1))
                    pred_a = int(pred_match.group(2))
                    adj_pred_h = pred_h + gv
                    if adj_pred_h > pred_a:
                        ai_dir = "h"
                    elif adj_pred_h < pred_a:
                        ai_dir = "a"
                    else:
                        ai_dir = "d"
                    scores[ai_dir] += 2.0
                    reasons.append(f"AI预测·{pred_h}-{pred_a}（让球后{adj_pred_h}-{pred_a}）→{dir_names[ai_dir]}+2.0")
                except (ValueError, IndexError):
                    pass

        # 3. 教练风格：进攻型教练→主胜/大球加分
        home_coach = bsd.get("home_coach") or {}
        away_coach = bsd.get("away_coach") or {}
        h_styles = home_coach.get("styles", []) if isinstance(home_coach, dict) else []
        a_styles = away_coach.get("styles", []) if isinstance(away_coach, dict) else []
        h_attack = any(s in str(h_styles).lower() for s in ['attack', 'pressing', 'offensive', '4-3-3', '4-2-3-1'])
        a_attack = any(s in str(a_styles).lower() for s in ['attack', 'pressing', 'offensive', '4-3-3', '4-2-3-1'])
        if h_attack and not a_attack:
            if gv < 0:  # 主队让球：主队进攻型→让胜加分
                scores["h"] += 0.8
                reasons.append(f"教练·主队进攻型({home_coach.get('formation','')})→让胜+0.8")
        elif a_attack and not h_attack:
            if gv < 0:  # 主队让球：客队进攻型→让负加分
                scores["a"] += 0.8
                reasons.append(f"教练·客队进攻型({away_coach.get('formation','')})→让负+0.8")

        # 4. 天气影响：恶劣天气→小球/平局加分
        weather = bsd.get("weather") or {}
        if isinstance(weather, dict):
            temp = weather.get("temperature_c", 20) or 20
            wind = weather.get("wind_speed", 0) or 0
            if temp <= 5 or temp >= 35 or wind >= 30:
                scores["d"] += 0.5
                reasons.append(f"天气·温度{temp}°C/风速{wind}km/h，恶劣天气→让平+0.5")

        # 5. 裁判风格：出牌多的裁判→比赛激烈，大球/分胜负加分
        referee = bsd.get("referee") or {}
        if isinstance(referee, dict):
            yc = referee.get("yellow_cards", 0) or 0
            games = referee.get("career_games", 1) or 1
            yc_per_game = yc / max(games, 1)
            if yc_per_game >= 4:
                scores["d"] -= 0.3
                reasons.append(f"裁判·{referee.get('name','')}场均{yc_per_game:.1f}黄，执法严格→让平-0.3")

        # 6. 预期首发完整性：首发完整度高的球队加分
        lineups = bsd.get("expected_lineups") or {}
        if isinstance(lineups, dict):
            h_lu = lineups.get("home", []) or []
            a_lu = lineups.get("away", []) or []
            h_complete = len(h_lu) >= 10
            a_complete = len(a_lu) >= 10
            if h_complete and not a_complete:
                if gv < 0:
                    scores["h"] += 0.5
                    reasons.append(f"首发·主队完整({len(h_lu)}人)vs客队不整({len(a_lu)}人)→让胜+0.5")
            elif a_complete and not h_complete:
                if gv < 0:
                    scores["a"] += 0.5
                    reasons.append(f"首发·客队完整({len(a_lu)}人)vs主队不整({len(h_lu)}人)→让负+0.5")

    # ========== BSD增强数据维度结束 ==========
    # 核心方向一致性约束：过滤掉与核心方向矛盾的让球盘方向
    allowed_dirs = {"h", "d", "a"}
    if core_dir:
        if core_dir == "h":  # 核心主胜
            if gv < 0:  # 主队让球：主胜→让球胜或让球平，不能让球负
                allowed_dirs = {"h", "d"}
            else:  # 主队受让：主胜→一定让球胜
                allowed_dirs = {"h"}
        elif core_dir == "a":  # 核心客胜
            if gv < 0:  # 主队让球：客胜→一定让球负
                allowed_dirs = {"a"}
            else:  # 主队受让：客胜→让球负或让球平，不能让球胜
                allowed_dirs = {"a", "d"}
        elif core_dir == "d":  # 核心平局
            if gv < 0:  # 主队让球：平局→让球负
                allowed_dirs = {"a"}
            else:  # 主队受让：平局→让球胜
                allowed_dirs = {"h"}
    # 在允许的方向中选择评分最高的
    filtered_scores = {d: scores[d] for d in allowed_dirs}
    best = max(filtered_scores, key=filtered_scores.get)
    sc = round(filtered_scores[best], 2)
    stars = 5 if sc >= 3.0 else 4 if sc >= 2.0 else 3 if sc >= 1.0 else 2 if sc > 0 else 1
    # 竞彩让球胜平负每场都有结果，必须给出明确推荐方向（让胜/让平/让负）
    # 信心星级根据评分高低调整，评分低=低信心，但仍有推荐方向
    verdict = {"t": "good", "txt": f"推荐{dir_names[best]}（综合评分{sc}）", "dir": best, "stars": stars, "score": sc, "reasons": reasons, "goal": goal}
    return verdict


def evaluate_asian(m, cfg, core_dir=None):
    """亚指让球盘推荐：基于港澳亚盘升降盘+核心方向，返回 {t,txt,dir,stars,asianLine,reasons}
    core_dir: 核心方向（普通胜平负h/d/a），确保推荐方向与港澳降水一致
    亚指方向：h=上盘（让球方），a=下盘（受让方），d=走水
    """
    hkmo = m.get("hkmo") or {}
    asian_line = (hkmo.get("asian") or {}).get("current") or ""
    asian_change = (hkmo.get("asian") or {}).get("change", "none")
    asian_open = (hkmo.get("asian") or {}).get("open", "")
    asian_cur = (hkmo.get("asian") or {}).get("current") or ""
    hhad = m.get("hhad") or {}
    goal = hhad.get("goal", "0")
    had_prob = m.get("hadProb") or {}
    if not asian_line and not asian_cur:
        return None
    hot = max(("h", "d", "a"), key=lambda d: had_prob.get(d) or 0)
    dir_names = {"h": "上盘", "d": "走盘", "a": "下盘"}
    hits = []
    reasons = []
    # 亚盘数值转换（主队让球为正，客队让球为负）
    try:
        from fetch_hkmo import asian_to_num
        line_num = asian_to_num(asian_cur or asian_line)
    except Exception:
        line_num = None
    # 确定主队是上盘还是下盘
    home_is_upper = True  # 默认主队=上盘
    if line_num is not None and line_num < 0:
        home_is_upper = False  # 客队让球，客队=上盘，主队=下盘
    # 升盘=机构看好上盘，降盘=看好下盘
    if asian_change == "up":
        hits.append({"t": "good", "dir": "h", "label": f"亚盘升盘 {asian_open}→{asian_cur}，机构强化上盘"})
        reasons.append(f"亚盘升盘+1.5")
    elif asian_change == "down":
        hits.append({"t": "good", "dir": "a", "label": f"亚盘降盘 {asian_open}→{asian_cur}，机构看衰上盘"})
        reasons.append(f"亚盘降盘+1.5")
    # 核心方向约束：将普通胜平负方向转换为亚指上下盘方向
    core_asian_dir = None
    if core_dir:
        if core_dir == "h":  # 核心主胜
            core_asian_dir = "h" if home_is_upper else "a"  # 主队赢→主队所在盘口
        elif core_dir == "a":  # 核心客胜
            core_asian_dir = "a" if home_is_upper else "h"  # 客队赢→客队所在盘口
        elif core_dir == "d":  # 核心平局
            # 平局时，让球方（上盘）没赢，下盘赢；平手盘走水
            if line_num is not None and abs(line_num) < 0.01:
                core_asian_dir = "d"  # 平手盘平局=走水
            else:
                core_asian_dir = "a"  # 非平手盘平局=下盘赢
        if core_asian_dir:
            hits.append({"t": "good", "dir": core_asian_dir,
                         "label": f"核心方向{('主胜','平局','客胜')[('h','d','a').index(core_dir)]}→{dir_names[core_asian_dir]}"})
            reasons.append(f"核心方向一致+2.0")
    # 竞彩让球与亚盘一致性
    try:
        gv = int(goal)
    except (TypeError, ValueError):
        gv = 0
    if gv != 0 and asian_line:
        hits.append({"t": "warn", "dir": "", "label": f"竞彩让球{goal} vs 亚盘{asian_line}，盘口差异需注意"})
    scores = {"h": 0.0, "d": 0.0, "a": 0.0}
    for h in hits:
        d = h.get("dir")
        if not d:
            continue
        if h["t"] == "good":
            scores[d] += 1.5
        elif h["t"] in ("bad", "cold"):
            scores[d] -= 1.0

    # ========== BSD增强数据维度（伤停/AI预测/教练/天气/裁判/首发）==========
    bsd = m.get("bsd") or {}
    if bsd:
        # 1. 伤停影响：主队伤停多→主队所在盘口减分，客队伤停多→客队所在盘口减分
        h_inj = bsd.get("injury_count_home", 0) or 0
        a_inj = bsd.get("injury_count_away", 0) or 0
        inj_diff = h_inj - a_inj
        if inj_diff >= 3:  # 主队伤停明显更多
            if home_is_upper:  # 主队=上盘→上盘减分，下盘加分
                scores["a"] += 1.5
                scores["h"] -= 0.5
                reasons.append(f"伤停·主队{h_inj}人vs客队{a_inj}人，主队阵容不整→下盘+1.5")
            else:  # 主队=下盘→下盘减分，上盘加分
                scores["h"] += 1.5
                scores["a"] -= 0.5
                reasons.append(f"伤停·主队{h_inj}人vs客队{a_inj}人，主队阵容不整→上盘+1.5")
        elif inj_diff <= -3:  # 客队伤停明显更多
            if home_is_upper:  # 主队=上盘→上盘加分
                scores["h"] += 1.5
                scores["a"] -= 0.5
                reasons.append(f"伤停·客队{a_inj}人vs主队{h_inj}人，客队阵容不整→上盘+1.5")
            else:  # 主队=下盘→下盘加分
                scores["a"] += 1.5
                scores["h"] -= 0.5
                reasons.append(f"伤停·客队{a_inj}人vs主队{h_inj}人，客队阵容不整→下盘+1.5")

        # 2. AI预测方向：从ai_preview中提取预测比分，转换为亚指上下盘
        ai_preview = bsd.get("ai_preview", "") or ""
        if ai_preview:
            import re
            pred_match = re.search(r'(\d+)\s*[-:]\s*(\d+)', ai_preview)
            if pred_match:
                try:
                    pred_h = int(pred_match.group(1))
                    pred_a = int(pred_match.group(2))
                    if line_num is not None and line_num != 0:
                        if line_num > 0:  # 主队让球=上盘
                            goal_diff = pred_h - pred_a
                            upper_win = goal_diff > abs(line_num) + 0.01
                        else:  # 客队让球=上盘
                            goal_diff = pred_a - pred_h
                            upper_win = goal_diff > abs(line_num) + 0.01
                        ai_dir = "h" if upper_win else "a"
                    else:  # 平手盘
                        if pred_h > pred_a:
                            ai_dir = "h" if home_is_upper else "a"
                        elif pred_h < pred_a:
                            ai_dir = "a" if home_is_upper else "h"
                        else:
                            ai_dir = "d"
                    if ai_dir in ("h", "a"):
                        scores[ai_dir] += 2.0
                        reasons.append(f"AI预测·{pred_h}-{pred_a}→{dir_names[ai_dir]}+2.0")
                except (ValueError, IndexError):
                    pass

        # 3. 教练风格：进攻型教练→所在盘口加分
        home_coach = bsd.get("home_coach") or {}
        away_coach = bsd.get("away_coach") or {}
        h_styles = home_coach.get("styles", []) if isinstance(home_coach, dict) else []
        a_styles = away_coach.get("styles", []) if isinstance(away_coach, dict) else []
        h_attack = any(s in str(h_styles).lower() for s in ['attack', 'pressing', 'offensive'])
        a_attack = any(s in str(a_styles).lower() for s in ['attack', 'pressing', 'offensive'])
        if h_attack and not a_attack:
            if home_is_upper:
                scores["h"] += 0.8
                reasons.append(f"教练·主队进攻型→上盘+0.8")
            else:
                scores["a"] += 0.8
                reasons.append(f"教练·主队进攻型→下盘+0.8")
        elif a_attack and not h_attack:
            if home_is_upper:
                scores["a"] += 0.8
                reasons.append(f"教练·客队进攻型→下盘+0.8")
            else:
                scores["h"] += 0.8
                reasons.append(f"教练·客队进攻型→上盘+0.8")

        # 4. 天气影响：恶劣天气→下盘（小球/平局）加分
        weather = bsd.get("weather") or {}
        if isinstance(weather, dict):
            temp = weather.get("temperature_c", 20) or 20
            wind = weather.get("wind_speed", 0) or 0
            if temp <= 5 or temp >= 35 or wind >= 30:
                scores["a"] += 0.5
                reasons.append(f"天气·温度{temp}°C/风速{wind}km/h，恶劣天气→下盘+0.5")

        # 5. 预期首发完整性
        lineups = bsd.get("expected_lineups") or {}
        if isinstance(lineups, dict):
            h_lu = lineups.get("home", []) or []
            a_lu = lineups.get("away", []) or []
            h_complete = len(h_lu) >= 10
            a_complete = len(a_lu) >= 10
            if h_complete and not a_complete:
                if home_is_upper:
                    scores["h"] += 0.5
                    reasons.append(f"首发·主队完整vs客队不整→上盘+0.5")
                else:
                    scores["a"] += 0.5
                    reasons.append(f"首发·主队完整vs客队不整→下盘+0.5")
            elif a_complete and not h_complete:
                if home_is_upper:
                    scores["a"] += 0.5
                    reasons.append(f"首发·客队完整vs主队不整→下盘+0.5")
                else:
                    scores["h"] += 0.5
                    reasons.append(f"首发·客队完整vs主队不整→上盘+0.5")

    # ========== BSD增强数据维度结束 ==========

    # 核心方向作为加分项而非强制选择（让BSD数据也能影响最终方向）
    if core_asian_dir:
        scores[core_asian_dir] += 1.0  # 核心方向加分（从+2.0降为+1.0，避免过度依赖）
    best = max(scores, key=scores.get)
    sc = round(scores[best], 2)
    stars = 4 if sc >= 2.5 else 3 if sc >= 1.5 else 2 if sc > 0 else 1
    # 亚指每场都必须给出推荐方向（上盘/下盘），走水只是比赛结果的一种，不作为推荐方向
    # 如果评分最高的是走水d，则改为上盘/下盘中评分较高的方向
    if best == "d":
        best = "h" if scores["h"] >= scores["a"] else "a"
        sc = round(scores[best], 2)
    verdict = {"t": "good", "txt": f"推荐{dir_names[best]}（{asian_cur or asian_line}，综合评分{sc}）", "dir": best, "stars": stars, "score": sc,
               "asianLine": asian_cur or asian_line, "asianOpen": asian_open, "asianChange": asian_change,
               "reasons": reasons}
    return verdict


def gen_score_predict(m):
    """比分推荐：基于进球预期/胜平负概率/攻防数据/让球，返回 {predicted,alternatives,confidence,reasons}"""
    ge = m.get("goalsExp")
    prob = m.get("hadProb") or {}
    hhad = m.get("hhad") or {}
    attack = m.get("attack") or {}
    if not prob:
        return None
    try:
        gv = int(hhad.get("goal", 0) or 0)
    except (TypeError, ValueError):
        gv = 0
    hot = max(("h", "d", "a"), key=lambda d: prob.get(d) or 0)
    hot_p = prob.get(hot) or 0
    # 预期总进球
    total_goals = ge if ge is not None else 2.5
    # 攻防数据
    ah = attack.get("home") or {}
    aa = attack.get("away") or {}
    h_gf = ah.get("gf", 1.3) if ah else 1.3
    h_ga = ah.get("ga", 1.3) if ah else 1.3
    a_gf = aa.get("gf", 1.3) if aa else 1.3
    a_ga = aa.get("ga", 1.3) if aa else 1.3
    # 主队预期进球 = (主队进攻 + 客队防守) / 2，按总进球缩放
    base_h = (h_gf + a_ga) / 2.0
    base_a = (a_gf + h_ga) / 2.0
    scale = total_goals / max(base_h + base_a, 0.1)
    exp_h = float(f"{base_h * scale:.1f}")
    exp_a = float(f"{base_a * scale:.1f}")
    # 让球调整
    if gv > 0:  # 主队让球，主队更强
        exp_h += 0.3 * gv
    elif gv < 0:
        exp_a += 0.3 * abs(gv)
    exp_h = float(f"{exp_h:.1f}")
    exp_a = float(f"{exp_a:.1f}")
    # 取最可能比分（四舍五入，边界处理）
    def nearest_score(eh, ea):
        sh = max(0, int(round(eh)))
        sa = max(0, int(round(ea)))
        return f"{sh}:{sa}"
    predicted = nearest_score(exp_h, exp_a)
    # 备选比分（±1球范围）
    alts = []
    for dh in (-1, 0, 1):
        for da in (-1, 0, 1):
            if dh == 0 and da == 0:
                continue
            sh = max(0, int(round(exp_h)) + dh)
            sa = max(0, int(round(exp_a)) + da)
            s = f"{sh}:{sa}"
            if s != predicted and s not in alts:
                alts.append(s)
            if len(alts) >= 3:
                break
        if len(alts) >= 3:
            break
    # 信心度
    confidence = min(95, int(hot_p * 0.6 + 40))
    reasons = [
        f"预期总进球{total_goals}球",
        f"主队预期进球{exp_h}·客队预期进球{exp_a}",
        f"热门方向{('主胜','平局','客胜')[('h','d','a').index(hot)]}概率{hot_p}%",
    ]
    if gv != 0:
        reasons.append(f"竞彩让球{gv}球调整")
    return {"predicted": predicted, "alternatives": alts[:3], "confidence": confidence,
            "expHome": exp_h, "expAway": exp_a, "totalGoals": total_goals, "reasons": reasons}


def gen_strong_weak_matches(matches):
    """强弱对战分析：筛选双方实力差距大、得分射手多的比赛。
    判断标准：让球数≥1、概率差距≥25%、进攻火力强、近期状态差距明显。
    数据来源：竞彩官方赔率/概率 + 500球队近况/攻防数据 + 公开球队情报交叉验证。
    返回 [{num, home, away, strongTeam, weakTeam, gapLevel, reasons, scorers, 
            strongInfo, weakInfo, recommendation, dataSource, searchDate}]"""
    import time
    today = time.strftime("%Y-%m-%d")
    search_date = time.strftime("%Y-%m-%d %H:%M")
    result = []

    for m in matches:
        if m.get("date") != today:
            continue
        num = m.get("num", "")
        home = m.get("home", "")
        away = m.get("away", "")
        hhad = m.get("hhad") or {}
        prob = m.get("hadProb") or {}
        attack = m.get("attack") or {}
        form = m.get("form") or {}
        had = m.get("had") or {}

        if not prob or not hhad:
            continue

        try:
            goal = int(hhad.get("goal", 0) or 0)
        except (TypeError, ValueError):
            goal = 0

        # 概率差距
        h_p = prob.get("h", 0) or 0
        d_p = prob.get("d", 0) or 0
        a_p = prob.get("a", 0) or 0
        max_p = max(h_p, a_p)
        min_p = min(h_p, a_p)
        prob_gap = max_p - min_p

        # 进攻数据
        ah = attack.get("home") or {}
        aa = attack.get("away") or {}
        h_gf = ah.get("gf", 0) or 0
        a_gf = aa.get("gf", 0) or 0
        h_ga = ah.get("ga", 0) or 0
        a_ga = aa.get("ga", 0) or 0

        # 近况胜率
        fh = form.get("home") or {}
        fa = form.get("away") or {}
        h_wr = fh.get("wr", 0) or 0
        a_wr = fa.get("wr", 0) or 0
        wr_gap = abs(h_wr - a_wr)

        # 判断强弱队
        if h_p >= a_p:
            strong_team = home
            weak_team = away
            strong_is_home = True
            strong_prob = h_p
            weak_prob = a_p
            strong_gf = h_gf
            weak_gf = a_gf
            strong_wr = h_wr
            weak_wr = a_wr
            strong_ga = h_ga
            weak_ga = a_ga
        else:
            strong_team = away
            weak_team = home
            strong_is_home = False
            strong_prob = a_p
            weak_prob = h_p
            strong_gf = a_gf
            weak_gf = h_gf
            strong_wr = a_wr
            weak_wr = h_wr
            strong_ga = a_ga
            weak_ga = h_ga

        # 强弱判定条件
        gap_score = 0
        reasons = []

        # 让球差距
        if abs(goal) >= 2:
            gap_score += 3
            reasons.append(f"竞彩让球{abs(goal)}球，实力差距悬殊")
        elif abs(goal) >= 1:
            gap_score += 2
            reasons.append(f"竞彩让球{abs(goal)}球，实力差距明显")

        # 概率差距
        if prob_gap >= 40:
            gap_score += 3
            reasons.append(f"胜平负概率差距{prob_gap:.0f}%（{strong_prob:.0f}% vs {weak_prob:.0f}%），强弱分明")
        elif prob_gap >= 25:
            gap_score += 2
            reasons.append(f"胜平负概率差距{prob_gap:.0f}%（{strong_prob:.0f}% vs {weak_prob:.0f}%），优势明显")

        # 进攻火力
        if strong_gf >= 2.0 and weak_ga >= 1.5:
            gap_score += 2
            reasons.append(f"强队场均进球{strong_gf}球，弱队场均失球{weak_ga}球，进攻对位优势大")
        elif strong_gf >= 1.5:
            gap_score += 1
            reasons.append(f"强队场均进球{strong_gf}球，进攻火力充足")

        # 状态差距
        if wr_gap >= 40:
            gap_score += 2
            reasons.append(f"近期胜率差距{wr_gap:.0f}%（{strong_wr:.0f}% vs {weak_wr:.0f}%），状态差距大")
        elif wr_gap >= 20:
            gap_score += 1
            reasons.append(f"近期胜率差距{wr_gap:.0f}%（{strong_wr:.0f}% vs {weak_wr:.0f}%），状态有差距")

        # 主场能力强加分（强队主场胜率高=主场龙，或客场胜率高=客场龙）
        h_home_wr = fh.get("home_wr", 0) or 0
        a_away_wr = fa.get("away_wr", 0) or 0
        if strong_is_home:
            if h_home_wr >= 70:
                gap_score += 2
                reasons.append(f"强队主场胜率{h_home_wr:.0f}%，主场龙属性极强")
            elif h_home_wr >= 55:
                gap_score += 1
                reasons.append(f"强队主场胜率{h_home_wr:.0f}%，主场能力强")
        else:
            if a_away_wr >= 55:
                gap_score += 1
                reasons.append(f"强队客场胜率{a_away_wr:.0f}%，客场作战能力强")

        # 弱队客场/主场差加分（弱队在对应场地表现差，进一步放大差距）
        weak_home_wr = fh.get("home_wr", 0) or 0
        weak_away_wr = fa.get("away_wr", 0) or 0
        if strong_is_home and weak_away_wr <= 25:
            gap_score += 1
            reasons.append(f"弱队客场胜率{weak_away_wr:.0f}%，客场虫属性明显")
        elif not strong_is_home and weak_home_wr <= 30:
            gap_score += 1
            reasons.append(f"弱队主场胜率{weak_home_wr:.0f}%，主场表现差")

        # 硬性过滤：强队近期状态必须好（胜率≥50%），弱队状态差（胜率≤45%）
        # 这样才能保证是"大人打小孩"级别的强弱对决
        if strong_wr < 50:
            continue
        if weak_wr > 45:
            continue

        # 主场能力强过滤：强队主场胜率必须≥50%（主场龙），或客场胜率≥35%（客场不弱）
        # 确保强队在自己的场地有足够统治力（h_home_wr/a_away_wr已在上方加分部分定义）
        if strong_is_home:
            if h_home_wr < 50:
                continue
        else:
            if a_away_wr < 35:
                continue

        # 只有gap_score≥6才纳入强弱对战（只保留"明显"和"悬殊"级别，去掉"较大"）
        if gap_score < 6:
            continue

        # 强弱等级
        if gap_score >= 9:
            gap_level = "悬殊"
        elif gap_score >= 7:
            gap_level = "明显"
        else:
            gap_level = "较大"

        # "大人打小孩"极端标签：让球≥2且概率差距≥35%且强队胜率≥60%
        is_brutal = (abs(goal) >= 2 and prob_gap >= 35 and strong_wr >= 60)

        # 推荐方向
        if strong_is_home:
            rec_dir = "主胜"
            rec_odds = had.get("h", 0)
        else:
            rec_dir = "客胜"
            rec_odds = had.get("a", 0)

        # 让球推荐（与胜平负推荐方向严格一致）
        hhad_v = m.get("hhadVerdict") or {}
        hhad_dir = hhad_v.get("dir", "")
        hhad_names = {"h": "让胜", "d": "让平", "a": "让负"}
        # 根据胜平负推荐方向确定让球盘允许的方向
        if rec_dir == "主胜":
            if goal < 0:  # 主队让球：主胜→让胜或让平
                allowed_hhad = {"h", "d"}
                default_hhad = "h"
            else:  # 主队受让：主胜→一定让胜
                allowed_hhad = {"h"}
                default_hhad = "h"
        elif rec_dir == "客胜":
            if goal < 0:  # 主队让球：客胜→一定让负
                allowed_hhad = {"a"}
                default_hhad = "a"
            else:  # 主队受让：客胜→让负或让平，不能让胜
                allowed_hhad = {"a", "d"}
                default_hhad = "a"
        else:  # 平局
            if goal < 0:  # 主队让球：平局→让负
                allowed_hhad = {"a"}
                default_hhad = "a"
            else:  # 主队受让：平局→让胜
                allowed_hhad = {"h"}
                default_hhad = "h"
        # 优先使用hhadVerdict，但必须在允许方向内
        if hhad_dir and hhad_dir in allowed_hhad:
            hhad_rec = hhad_names[hhad_dir]
            hhad_stars = hhad_v.get("stars", 0)
            hhad_score = hhad_v.get("score", 0)
        elif abs(goal) >= 1:
            # 使用默认方向（与胜平负推荐一致）
            hhad_rec = hhad_names[default_hhad]
            hhad_stars = 0
            hhad_score = 0
        else:
            hhad_rec = "—"
            hhad_stars = 0
            hhad_score = 0

        # 增强数据支撑：伤停、H2H、主客场战绩、关键球员（全部来自真实数据源）
        bsd = m.get("bsd") or {}
        h2h = m.get("h2h") or {}
        form_home = m.get("form", {}).get("home", {}) or {}
        form_away = m.get("form", {}).get("away", {}) or {}

        # 联赛排名差距（BSD无standings字段，暂不显示；如有500排名数据可在此扩展）
        rank_gap = ""

        # 伤停影响（BSD真实数据：injury_count_home/away + 详细伤停名单）
        injury_info = ""
        injury_detail = []
        h_inj = bsd.get("injury_count_home", 0) or 0
        a_inj = bsd.get("injury_count_away", 0) or 0
        h_inj_list = bsd.get("injuries_home", []) or []
        a_inj_list = bsd.get("injuries_away", []) or []
        if isinstance(h_inj, int) and isinstance(a_inj, int) and (h_inj > 0 or a_inj > 0):
            injury_info = f"伤停：主队{h_inj}人/客队{a_inj}人"
            # 提取详细伤停名单（球员名+伤情）
            for inj in h_inj_list[:3]:
                if isinstance(inj, dict):
                    name = inj.get("name", "")
                    reason = inj.get("reason", "")
                    if name:
                        injury_detail.append(f"主队{name}({reason})" if reason else f"主队{name}")
            for inj in a_inj_list[:3]:
                if isinstance(inj, dict):
                    name = inj.get("name", "")
                    reason = inj.get("reason", "")
                    if name:
                        injury_detail.append(f"客队{name}({reason})" if reason else f"客队{name}")
            if h_inj >= 3 or a_inj >= 3:
                if (strong_is_home and a_inj >= 3) or (not strong_is_home and h_inj >= 3):
                    gap_score += 1
                    reasons.append(f"弱队伤停{max(h_inj,a_inj)}人，阵容不整")

        # H2H历史交锋优势（如有真实H2H数据）
        h2h_info = ""
        h2h_home = h2h.get("homeWins") or h2h.get("h", 0)
        h2h_away = h2h.get("awayWins") or h2h.get("a", 0)
        h2h_draw = h2h.get("draws") or h2h.get("d", 0)
        if isinstance(h2h_home, int) and isinstance(h2h_away, int):
            total_h2h = h2h_home + h2h_away + h2h_draw
            if total_h2h >= 3:
                if strong_is_home and h2h_home > h2h_away:
                    h2h_info = f"历史交锋主队{h2h_home}胜{h2h_draw}平{h2h_away}负，占优"
                    gap_score += 1
                    reasons.append(h2h_info)
                elif not strong_is_home and h2h_away > h2h_home:
                    h2h_info = f"历史交锋客队{h2h_away}胜{h2h_draw}平{h2h_home}负，占优"
                    gap_score += 1
                    reasons.append(h2h_info)

        # 主客场战绩（来自500球队近况form数据中的home_wr/away_wr，真实有效）
        # h_home_wr/a_away_wr已在上方加分部分定义
        ha_info = ""
        if strong_is_home:
            # 强队主场 vs 弱队客场
            weak_away_wr = form_away.get("away_wr", 0) or 0
            if h_home_wr >= 50:
                ha_info = f"强队主场胜率{h_home_wr:.0f}% vs 弱队客场胜率{weak_away_wr:.0f}%，主客场差距{abs(h_home_wr-weak_away_wr):.0f}%"
        else:
            # 强队客场 vs 弱队主场
            weak_home_wr = form_home.get("home_wr", 0) or 0
            if a_away_wr >= 40:
                ha_info = f"强队客场胜率{a_away_wr:.0f}% vs 弱队主场胜率{weak_home_wr:.0f}%，主客场差距{abs(a_away_wr-weak_home_wr):.0f}%"

        # 关键球员/射手信息（从BSD ai_preview真实赛前分析中提取，优先进攻核心）
        scorers = []
        top_scorer = ""
        ai_preview = bsd.get("ai_preview", "") or ""
        if ai_preview:
            import re
            # 提取ai_preview中加粗的球员名（**Name**格式）
            bold_names = re.findall(r'\*\*([A-Z][a-zA-Z\s\.\'-]+?)\*\*', ai_preview)
            seen = set()
            # 优先提取与进攻/进球相关段落中的球员（ai_preview中"attack"、"score"附近的球员）
            attack_section = ""
            for keyword in ['attack', 'score', 'goal', 'striker', 'forward', '火力', '进攻']:
                idx = ai_preview.lower().find(keyword)
                if idx > 0:
                    attack_section = ai_preview[max(0,idx-100):idx+200]
                    break
            attack_names = re.findall(r'\*\*([A-Z][a-zA-Z\s\.\'-]+?)\*\*', attack_section) if attack_section else []
            
            # 先从进攻相关段落提取（标注为最强射手）
            for name in attack_names:
                name = name.strip()
                lower_name = name.lower()
                if (len(name) >= 3 and name not in seen 
                    and ' and ' not in lower_name and ' vs ' not in lower_name
                    and not any(w in lower_name for w in ['prediction', 'key', 'storyline', 'expected', 'lineup', 'both', 'home', 'away', 'stade', 'paris', 'lens', 'brest', 'celta', 'malaga', 'heerenveen', 'telstar', 'leipzig', 'hamburg', 'lisbon', 'famalicao', 'lille', 'troyes', 'napoli', 'bologna', 'sassuolo', 'juventus', 'real', 'atletico', 'flamengo', 'corinthians', 'chicago', 'england', 'revolution'])):
                    if not (name.isupper() and len(name) <= 5):
                        seen.add(name)
                        top_scorer = name  # 第一个进攻相关球员标注为最强射手
                        scorers.append(f"★{name}")
                        break
            
            # 再从全文提取其他关键球员
            for name in bold_names:
                name = name.strip()
                lower_name = name.lower()
                if (len(name) >= 3 and name not in seen 
                    and ' and ' not in lower_name and ' vs ' not in lower_name
                    and not any(w in lower_name for w in ['prediction', 'key', 'storyline', 'expected', 'lineup', 'both', 'home', 'away', 'stade', 'paris', 'lens', 'brest', 'celta', 'malaga', 'heerenveen', 'telstar', 'leipzig', 'hamburg', 'lisbon', 'famalicao', 'lille', 'troyes', 'napoli', 'bologna', 'sassuolo', 'juventus', 'real', 'atletico', 'flamengo', 'corinthians', 'chicago', 'england', 'revolution'])):
                    if not (name.isupper() and len(name) <= 5):
                        seen.add(name)
                        scorers.append(name)
                        if len(scorers) >= 4:
                            break
        
        # 也从expected_lineups提取核心球员（前锋位置优先）
        lineups = bsd.get("expected_lineups") or {}
        if len(scorers) < 2 and lineups:
            home_lu = lineups.get("home", []) or []
            away_lu = lineups.get("away", []) or []
            # 强队的前锋优先
            strong_lu = home_lu if strong_is_home else away_lu
            for p in strong_lu:
                if isinstance(p, str) and len(p) >= 3 and p not in seen:
                    seen.add(p)
                    scorers.append(p)
                    if len(scorers) >= 3:
                        break

        # 强队/弱队信息摘要（数据来自竞彩官方概率 + 500球队近况，真实有效）
        # 增加主场能力数据：强队主场胜率/客场胜率
        strong_ha_label = "主场" if strong_is_home else "客场"
        strong_ha_wr = h_home_wr if strong_is_home else a_away_wr
        weak_ha_label = "客场" if strong_is_home else "主场"
        weak_ha_wr = a_away_wr if strong_is_home else h_home_wr
        strong_info = f"胜率{strong_wr:.0f}%·{strong_ha_label}胜率{strong_ha_wr:.0f}%·场均进{strong_gf}球·失{strong_ga}球·概率{strong_prob:.0f}%"
        weak_info = f"胜率{weak_wr:.0f}%·{weak_ha_label}胜率{weak_ha_wr:.0f}%·场均进{weak_gf}球·失{weak_ga}球·概率{weak_prob:.0f}%"

        # 数据真实性验证状态：核心数据（让球/概率/赔率/近况）必须存在才标记已验证
        core_verified = bool(prob and hhad and had and strong_wr > 0)
        # 数据源声明：只声明实际使用的真实数据源
        data_sources = ["竞彩官方赔率/概率/让球", "500球队近况/攻防数据"]
        if bsd:
            data_sources.append("BSD赛前分析/伤停/阵容")
        data_source_str = " + ".join(data_sources)

        result.append({
            "num": num,
            "home": home,
            "away": away,
            "strongTeam": strong_team,
            "weakTeam": weak_team,
            "strongIsHome": strong_is_home,
            "gapLevel": gap_level,
            "gapScore": gap_score,
            "reasons": reasons,
            "scorers": scorers,
            "strongInfo": strong_info,
            "weakInfo": weak_info,
            "recommendation": rec_dir,
            "recommendOdds": rec_odds,
            "hhadRecommendation": hhad_rec,
            "hhadStars": hhad_stars,
            "hhadScore": hhad_score,
            "goal": goal,
            "rankGap": rank_gap,
            "injuryInfo": injury_info,
            "injuryDetail": injury_detail,
            "topScorer": top_scorer,
            "isBrutal": is_brutal,
            "h2hInfo": h2h_info,
            "haInfo": ha_info,
            "homeAdvantage": {
                "strongIsHome": strong_is_home,
                "strongHomeWr": h_home_wr if strong_is_home else a_away_wr,
                "weakAwayWr": a_away_wr if strong_is_home else h_home_wr,
                "label": strong_ha_label,
                "strongHaWr": strong_ha_wr,
                "weakHaWr": weak_ha_wr
            },
            "dataSource": data_source_str,
            "searchDate": search_date,
            "verified": core_verified
        })

    # 按gapScore降序排列
    result.sort(key=lambda x: x["gapScore"], reverse=True)
    print(f"  强弱对战：筛选出{len(result)}场实力差距明显的比赛", flush=True)
    return {"generatedAt": time.strftime("%Y-%m-%d %H:%M:%S"),
            "searchDate": search_date,
            "count": len(result),
            "matches": result}


def save_strongweak_history(strong_weak, matches):
    """保存强弱对战历史推荐记录，用于赛后追溯命中/错误。
    历史文件：strongweak_history.json，按日期存储。
    每场记录：num/home/away/strongTeam/weakTeam/recommendation/recommendOdds/
              hhadRecommendation/goal/gapLevel/gapScore/result/hit/hhadHit"""
    import os
    hist_path = os.path.join(HERE, "strongweak_history.json")
    today = time.strftime("%Y-%m-%d")
    
    # 读取已有历史
    history = {}
    if os.path.exists(hist_path):
        try:
            with open(hist_path, "r", encoding="utf-8") as f:
                history = json.load(f)
        except (json.JSONDecodeError, IOError):
            history = {}
    
    # 构建今天的记录
    today_records = []
    for m in strong_weak.get("matches", []):
        num = m.get("num", "")
        # 从matches中查找赛果回填
        result = ""
        hit = None
        hhad_hit = None
        for orig in matches:
            if orig.get("num") == num:
                # 赛果
                final = orig.get("final") or orig.get("result") or {}
                if isinstance(final, dict):
                    hs = final.get("homeScore")
                    as_ = final.get("awayScore")
                    if hs is not None and as_ is not None:
                        if hs > as_:
                            result = "主胜"
                        elif hs == as_:
                            result = "平局"
                        else:
                            result = "客胜"
                # 胜平负命中判定
                rec = m.get("recommendation", "")
                if result and rec:
                    hit = (rec == result)
                # 让球命中判定（从history records中查找）
                hhad_rec = m.get("hhadRecommendation", "")
                goal = m.get("goal", 0)
                if result and hhad_rec and goal != 0:
                    # 计算让球后结果
                    try:
                        g = int(goal)
                    except (TypeError, ValueError):
                        g = 0
                    # goal<0=主队让球，goal>0=主队受让
                    if result == "主胜":
                        adj = 3 + g  # 主胜=3分
                    elif result == "平局":
                        adj = 1 + g
                    else:
                        adj = 0 + g
                    if adj > 1:
                        hhad_result = "让胜"
                    elif adj == 1:
                        hhad_result = "让平"
                    else:
                        hhad_result = "让负"
                    hhad_hit = (hhad_rec == hhad_result)
                break
        
        today_records.append({
            "num": num,
            "home": m.get("home", ""),
            "away": m.get("away", ""),
            "strongTeam": m.get("strongTeam", ""),
            "weakTeam": m.get("weakTeam", ""),
            "recommendation": m.get("recommendation", ""),
            "recommendOdds": m.get("recommendOdds", 0),
            "hhadRecommendation": m.get("hhadRecommendation", ""),
            "goal": m.get("goal", 0),
            "gapLevel": m.get("gapLevel", ""),
            "gapScore": m.get("gapScore", 0),
            "topScorer": m.get("topScorer", ""),
            "isBrutal": m.get("isBrutal", False),
            "result": result,
            "hit": hit,
            "hhadHit": hhad_hit
        })
    
    history[today] = {
        "date": today,
        "generatedAt": strong_weak.get("generatedAt", ""),
        "count": len(today_records),
        "matches": today_records
    }
    
    with open(hist_path, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=1)
    
    # 历史回填：遍历所有历史日期，从history.json补充赛果和命中判定
    try:
        hist_path2 = os.path.join(HERE, "history.json")
        hist_score_map = {}
        if os.path.exists(hist_path2):
            with open(hist_path2, "r", encoding="utf-8") as f2:
                hist_data = json.load(f2)
            for rec in hist_data.get("records", []):
                d = rec.get("date", "")
                num = rec.get("num", "")
                result = rec.get("result") or {}
                if isinstance(result, dict) and result.get("score") and not result.get("cancel"):
                    try:
                        parts = result["score"].replace("：", ":").split(":")
                        hs, as_ = int(parts[0]), int(parts[1])
                        hist_score_map[f"{d}|{num}"] = {"home": hs, "away": as_}
                    except Exception:
                        pass
        backfilled = 0
        for hist_date, day_data in history.items():
            if hist_date == today:
                continue
            if not isinstance(day_data, dict):
                continue
            for m in day_data.get("matches", []):
                # 已有真实赛果（result非空）才跳过；历史上曾出现hit已预设但result为空的脏数据，需补回填
                if m.get("result"):
                    continue
                num = m.get("num", "")
                key = f"{hist_date}|{num}"
                if key not in hist_score_map:
                    continue
                fs = hist_score_map[key]
                # 胜平负结果 + 具体比分
                score_str = f"{fs['home']}:{fs['away']}"
                if fs["home"] > fs["away"]:
                    m["result"] = f"主胜 {score_str}"
                    m["resultDir"] = "主胜"
                elif fs["home"] == fs["away"]:
                    m["result"] = f"平局 {score_str}"
                    m["resultDir"] = "平局"
                else:
                    m["result"] = f"客胜 {score_str}"
                    m["resultDir"] = "客胜"
                m["actualScore"] = score_str
                rec_text = m.get("recommendation", "")
                if rec_text:
                    m["hit"] = (rec_text == m["resultDir"])
                # 让球命中判定（使用实际比分计算）
                goal = m.get("goal", 0)
                hhad_rec = m.get("hhadRecommendation", "")
                if goal != 0 and hhad_rec and m.get("actualScore"):
                    try:
                        g = int(goal)
                    except (TypeError, ValueError):
                        g = 0
                    # 解析实际比分
                    score_str = m["actualScore"]
                    if ":" in score_str:
                        parts = score_str.split(":")
                        home_goals = int(parts[0])
                        away_goals = int(parts[1])
                        # 计算让球后比分
                        adj_home = home_goals + g
                        if adj_home > away_goals:
                            hhad_result = "让胜"
                        elif adj_home == away_goals:
                            hhad_result = "让平"
                        else:
                            hhad_result = "让负"
                        m["hhadHit"] = (hhad_rec == hhad_result)
                    else:
                        m["hhadHit"] = None
                else:
                    m["hhadHit"] = None
                backfilled += 1
        if backfilled > 0:
            print(f"  强弱对战历史回填：补充{backfilled}场历史赛果", flush=True)
            with open(hist_path, "w", encoding="utf-8") as f:
                json.dump(history, f, ensure_ascii=False, indent=1)
    except Exception as e:
        print(f"  强弱对战历史回填失败: {e}", flush=True)

    # 保存后从文件重读，确保返回值与文件一致
    try:
        with open(hist_path, "r", encoding="utf-8") as f:
            history = json.load(f)
    except Exception:
        pass

    # 统计命中
    hit_count = sum(1 for r in today_records if r["hit"] is True)
    miss_count = sum(1 for r in today_records if r["hit"] is False)
    print(f"  强弱对战历史已保存：{today} {len(today_records)}场（命中{hit_count}/错误{miss_count}）", flush=True)
    return history


# ============ 半全场胜平负推荐 ============
HF_LABELS = {
    "hh": "胜胜", "hd": "胜平", "ha": "胜负",
    "dh": "平胜", "dd": "平平", "da": "平负",
    "ah": "负胜", "ad": "负平", "aa": "负负"
}

def _poisson_prob(lam, k):
    """泊松分布概率"""
    import math
    return (lam ** k) * math.exp(-lam) / math.factorial(k)

def _poisson_match_prob(exp_h, exp_a, max_goals=6):
    """基于泊松分布计算胜平负概率"""
    h_prob = 0.0
    d_prob = 0.0
    a_prob = 0.0
    for i in range(max_goals + 1):
        for j in range(max_goals + 1):
            p = _poisson_prob(exp_h, i) * _poisson_prob(exp_a, j)
            if i > j:
                h_prob += p
            elif i == j:
                d_prob += p
            else:
                a_prob += p
    total = h_prob + d_prob + a_prob
    if total > 0:
        h_prob /= total
        d_prob /= total
        a_prob /= total
    return h_prob, d_prob, a_prob

def gen_half_full(matches):
    """半全场胜平负推荐：基于全场概率+半场泊松概率+条件概率矩阵计算9种组合概率。
    
    算法：
    1. 全场结果概率 → hadProb
    2. 半场结果概率 → 预期进球(scoreRec.expHome/expAway × 0.45)泊松分布
    3. 条件概率矩阵 → 半场领先方全场胜率根据强弱程度动态调整
    4. 联合概率 → P(半场X,全场Y) = P(半场X) × P(全场Y|半场X)
    5. 推荐概率最高的1-2种组合，信心度=概率百分比
    """
    import math
    today = time.strftime("%Y-%m-%d")
    today_matches = [m for m in matches if m.get("date") == today]
    now_ts = time.time()
    results = []
    
    for m in today_matches:
        # 只选未开赛或刚开赛的比赛
        kickoff = m.get("kickoff") or ""
        try:
            kt = time.mktime(time.strptime(kickoff, "%Y-%m-%d %H:%M"))
            if now_ts > kt + 45 * 60:  # 开赛超过45分钟（上半场结束）不再推荐
                continue
        except Exception:
            pass
        
        num = m.get("num", "")
        home = m.get("home", "")
        away = m.get("away", "")
        league = m.get("league", "")
        
        # 全场概率（处理只有让球盘没有胜平负的比赛，值为None时用默认值）
        had_prob = m.get("hadProb") or {}
        full_h = (had_prob.get("h") or 33) / 100.0
        full_d = (had_prob.get("d") or 33) / 100.0
        full_a = (had_prob.get("a") or 34) / 100.0
        
        # 半场预期进球（全场预期 × 0.45，上半场进球通常占全场45%）
        score_rec = m.get("scoreRec") or {}
        exp_home_full = score_rec.get("expHome", 1.4)
        exp_away_full = score_rec.get("expAway", 1.2)
        # 如果没有scoreRec，用goalsExp和攻防数据估算
        if exp_home_full <= 0:
            goals_exp = m.get("goalsExp", 2.5)
            attack = m.get("attack") or {}
            h_atk = attack.get("home", {}).get("gf", 1.3)
            a_atk = attack.get("away", {}).get("gf", 1.1)
            total_atk = h_atk + a_atk
            if total_atk > 0:
                exp_home_full = goals_exp * h_atk / total_atk
                exp_away_full = goals_exp * a_atk / total_atk
            else:
                exp_home_full = goals_exp / 2
                exp_away_full = goals_exp / 2
        
        exp_home_half = exp_home_full * 0.45
        exp_away_half = exp_away_full * 0.45
        
        # 半场泊松概率
        half_h_poisson, half_d_poisson, half_a_poisson = _poisson_match_prob(exp_home_half, exp_away_half)
        
        # 贝叶斯调整：半场概率 = 泊松概率×0.6 + 全场概率×0.4
        # 因为半场和全场结果有较强相关性，全场强队半场也更可能领先
        half_h = half_h_poisson * 0.6 + full_h * 0.4
        half_d = half_d_poisson * 0.6 + full_d * 0.4
        half_a = half_a_poisson * 0.6 + full_a * 0.4
        # 归一化
        half_total = half_h + half_d + half_a
        if half_total > 0:
            half_h /= half_total
            half_d /= half_total
            half_a /= half_total
        
        # 强弱程度系数（用于调整条件概率矩阵）
        # 全场主胜概率越高，半场主胜后全场主胜的概率也越高
        strength = full_h - full_a  # 正数=主队强，负数=客队强
        
        # 条件概率矩阵：P(全场Y | 半场X)
        # 基准矩阵（中等强弱比赛）
        cond_base = {
            "h": {"h": 0.72, "d": 0.18, "a": 0.10},  # 半场主胜
            "d": {"h": 0.40, "d": 0.32, "a": 0.28},  # 半场平
            "a": {"h": 0.10, "d": 0.18, "a": 0.72},  # 半场客胜
        }
        
        # 根据强弱程度动态调整条件概率
        cond = {}
        for hf in ["h", "d", "a"]:
            cond[hf] = {}
            for ff in ["h", "d", "a"]:
                base = cond_base[hf][ff]
                # 强队调整：主队强时，半场各种情况下全场主胜概率提升
                if ff == "h":
                    adj = strength * 0.15  # 强弱差距越大，调整越多
                elif ff == "a":
                    adj = -strength * 0.15
                else:
                    adj = 0
                val = max(0.05, min(0.90, base + adj))
                cond[hf][ff] = val
            # 归一化
            total = sum(cond[hf].values())
            if total > 0:
                for ff in cond[hf]:
                    cond[hf][ff] /= total
        
        # 计算9种联合概率
        probs = {}
        for hf in ["h", "d", "a"]:
            half_p = {"h": half_h, "d": half_d, "a": half_a}[hf]
            for ff in ["h", "d", "a"]:
                key = hf + ff
                probs[key] = half_p * cond[hf][ff]
        
        # 归一化
        total_p = sum(probs.values())
        if total_p > 0:
            for k in probs:
                probs[k] /= total_p
        
        # 排序选推荐
        sorted_probs = sorted(probs.items(), key=lambda x: x[1], reverse=True)
        top1_key, top1_prob = sorted_probs[0]
        top2_key, top2_prob = sorted_probs[1] if len(sorted_probs) > 1 else (None, 0)
        
        # 信心度计算：top1概率 × 数据完整度系数
        data_quality = 1.0
        if not score_rec:
            data_quality *= 0.85
        if not had_prob:
            data_quality *= 0.8
        confidence = round(top1_prob * 100 * data_quality, 1)
        confidence2 = round(top2_prob * 100 * data_quality, 1) if top2_key else 0
        
        # 推荐理由
        reasons = []
        if full_h > 0.55:
            reasons.append(f"全场主胜概率{full_h*100:.0f}%，主队优势明显")
        elif full_a > 0.55:
            reasons.append(f"全场客胜概率{full_a*100:.0f}%，客队优势明显")
        else:
            reasons.append(f"全场胜负接近（主{full_h*100:.0f}%/平{full_d*100:.0f}%/客{full_a*100:.0f}%）")
        
        if half_h > 0.45:
            reasons.append(f"半场主胜概率{half_h*100:.0f}%（预期进{exp_home_half:.1f}球）")
        elif half_a > 0.45:
            reasons.append(f"半场客胜概率{half_a*100:.0f}%（预期进{exp_away_half:.1f}球）")
        else:
            reasons.append(f"半场平局概率{half_d*100:.0f}%，上半场可能胶着")
        
        # 概率分布（用于页面展示）
        prob_dist = {HF_LABELS[k]: round(v * 100, 1) for k, v in sorted_probs}
        
        results.append({
            "num": num,
            "home": home,
            "away": away,
            "league": league,
            "kickoff": kickoff,
            "recommend": HF_LABELS[top1_key],
            "recommendKey": top1_key,
            "confidence": confidence,
            "recommend2": HF_LABELS[top2_key] if top2_key else "",
            "recommend2Key": top2_key or "",
            "confidence2": confidence2,
            "probDist": prob_dist,
            "fullProb": {"h": round(full_h*100,1), "d": round(full_d*100,1), "a": round(full_a*100,1)},
            "halfProb": {"h": round(half_h*100,1), "d": round(half_d*100,1), "a": round(half_a*100,1)},
            "expGoals": {"homeHalf": round(exp_home_half,2), "awayHalf": round(exp_away_half,2),
                          "homeFull": round(exp_home_full,2), "awayFull": round(exp_away_full,2)},
            "reasons": reasons,
            "dataQuality": round(data_quality * 100)
        })
    
    # 按信心度降序
    results.sort(key=lambda x: x["confidence"], reverse=True)
    
    print(f"  半全场推荐：生成{len(results)}场比赛推荐", flush=True)
    return {
        "generatedAt": time.strftime("%Y-%m-%d %H:%M:%S"),
        "searchDate": today,
        "count": len(results),
        "matches": results
    }


def save_half_full_history(half_full, matches):
    """保存半全场推荐历史记录，用于赛后追溯命中/错误。
    历史文件：half_full_history.json，按日期存储。
    每场记录：num/home/away/recommend/confidence/probDist/actualHalfFull/result/hit"""
    import os
    hist_path = os.path.join(HERE, "half_full_history.json")
    today = time.strftime("%Y-%m-%d")
    
    # 读取已有历史
    history = {}
    if os.path.exists(hist_path):
        try:
            with open(hist_path, "r", encoding="utf-8") as f:
                history = json.load(f)
        except (json.JSONDecodeError, IOError):
            history = {}
    
    # 构建赛果查找表（按num）——先从当天matches，再从history.json历史记录
    score_map = {}
    for m in matches:
        num = m.get("num", "")
        result = m.get("result") or {}
        if isinstance(result, dict) and result.get("score"):
            try:
                parts = result["score"].replace("：", ":").split(":")
                hs = int(parts[0])
                as_ = int(parts[1])
                score_map[num] = {"home": hs, "away": as_}
            except Exception:
                pass
    # 从history.json补充历史赛果（覆盖昨天及更早已完场比赛）
    try:
        hist_path2 = os.path.join(HERE, "history.json")
        if os.path.exists(hist_path2):
            with open(hist_path2, "r", encoding="utf-8") as f2:
                hist_data = json.load(f2)
            for rec in hist_data.get("records", []):
                num = rec.get("num", "")
                if num in score_map:
                    continue  # 当天matches已有，优先用当天的
                result = rec.get("result") or {}
                if isinstance(result, dict) and result.get("score") and not result.get("cancel"):
                    try:
                        parts = result["score"].replace("：", ":").split(":")
                        hs = int(parts[0])
                        as_ = int(parts[1])
                        score_map[num] = {"home": hs, "away": as_}
                    except Exception:
                        pass
    except Exception as e:
        print(f"  半全场历史赛果补充失败: {e}", flush=True)
    
    # 构建今天的记录
    today_records = []
    for m in half_full.get("matches", []):
        num = m.get("num", "")
        actual_hf = ""
        hit = None
        
        # 回填实际半全场结果
        if num in score_map:
            # 注意：这里只有全场比分，没有半场比分
            # 半场比分需要从其他来源获取，暂时只标记全场结果
            # 实际半全场需要半场比分，后续可从500彩票网等获取
            full_score = score_map[num]
            full_dir = "h" if full_score["home"] > full_score["away"] else ("d" if full_score["home"] == full_score["away"] else "a")
            actual_hf = f"?{full_dir}"  # ?表示半场未知
            # 只有全场结果无法判定半全场命中，需要半场比分
            hit = None
        
        today_records.append({
            "num": num,
            "home": m.get("home", ""),
            "away": m.get("away", ""),
            "league": m.get("league", ""),
            "kickoff": m.get("kickoff", ""),
            "recommend": m.get("recommend", ""),
            "recommendKey": m.get("recommendKey", ""),
            "confidence": m.get("confidence", 0),
            "recommend2": m.get("recommend2", ""),
            "confidence2": m.get("confidence2", 0),
            "probDist": m.get("probDist", {}),
            "actualHalfFull": actual_hf,
            "hit": hit,
            "fullScore": score_map.get(num, {})
        })
    
    history[today] = {
        "date": today,
        "generatedAt": half_full.get("generatedAt", ""),
        "count": len(today_records),
        "matches": today_records
    }
    
    # 历史回填：遍历所有历史日期的记录，从history.json补充赛果和半全场命中
    try:
        hist_score_map = {}
        if os.path.exists(hist_path2):
            with open(hist_path2, "r", encoding="utf-8") as f2:
                hist_data = json.load(f2)
            for rec in hist_data.get("records", []):
                d = rec.get("date", "")
                num = rec.get("num", "")
                result = rec.get("result") or {}
                hf_result = rec.get("halfFullResult", "")  # 如"hd"
                if isinstance(result, dict) and result.get("score") and not result.get("cancel"):
                    try:
                        parts = result["score"].replace("：", ":").split(":")
                        hs = int(parts[0])
                        as_ = int(parts[1])
                        hist_score_map[f"{d}|{num}"] = {"home": hs, "away": as_, "halfFull": hf_result}
                    except Exception:
                        pass
        # 半全场9种标签映射
        _hf_labels = {"hh":"胜胜","hd":"胜平","ha":"胜负","dh":"平胜","dd":"平平","da":"平负","ah":"负胜","ad":"负平","aa":"负负"}
        backfilled = 0
        for hist_date, day_data in history.items():
            if hist_date == today:
                continue  # 当天已处理
            if not isinstance(day_data, dict):
                continue
            for m in day_data.get("matches", []):
                if m.get("hit") is not None:
                    continue  # 已判定
                num = m.get("num", "")
                key = f"{hist_date}|{num}"
                if key not in hist_score_map:
                    continue
                fs = hist_score_map[key]
                full_dir = "h" if fs["home"] > fs["away"] else ("d" if fs["home"] == fs["away"] else "a")
                m["fullScore"] = {"home": fs["home"], "away": fs["away"]}
                hf_actual = fs.get("halfFull", "")
                if hf_actual:
                    # 有官方半全场结果，精确判定
                    m["actualHalfFull"] = _hf_labels.get(hf_actual, hf_actual)
                    rec_key = m.get("recommendKey", "")
                    m["hit"] = (rec_key == hf_actual)
                    # 次推也判定
                    rec2_key = m.get("recommend2Key", "")
                    if rec2_key and rec2_key == hf_actual:
                        m["hit"] = True
                else:
                    # 无半场比分，仅标记全场结果
                    m["actualHalfFull"] = f"?{full_dir}"
                    m["hit"] = None
                backfilled += 1
        if backfilled > 0:
            print(f"  半全场历史回填：补充{backfilled}场历史赛果", flush=True)
    except Exception as e:
        print(f"  半全场历史回填失败: {e}", flush=True)
    
    with open(hist_path, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=1)
    
    # 保存后从文件重读，确保返回值与文件一致（避免内存dict状态不一致）
    try:
        with open(hist_path, "r", encoding="utf-8") as f:
            history = json.load(f)
    except Exception:
        pass

    hit_count = sum(1 for r in today_records if r["hit"] is True)
    miss_count = sum(1 for r in today_records if r["hit"] is False)
    pending = sum(1 for r in today_records if r["hit"] is None)
    print(f"  半全场历史已保存：{today} {len(today_records)}场（命中{hit_count}/错误{miss_count}/待赛{pending}）", flush=True)
    return history


def gen_high_odds_parlay(matches):
    """高倍混合串关（智能版）：每场比赛从胜平负、让球胜平负、总进球三种玩法中
    自动选择信心度×赔率最优的选项，组成混合高倍串关。
    信心度计算：规则触发+港澳降水+支持率背离+概率价值+数据匹配度。
    只选当天比赛，不跨天。
    返回 {parlay2, parlay3, generatedAt, strategy}"""
    import math
    today = time.strftime("%Y-%m-%d")
    matches = [m for m in matches if m.get("date") == today]
    candidates = []
    now_ts = time.time()

    for m in matches:
        # 只选未开赛的比赛
        kickoff = m.get("kickoff") or ""
        try:
            kt = time.mktime(time.strptime(f"{m.get('date','')} {kickoff}", "%Y-%m-%d %H:%M"))
            if kt < now_ts:
                continue
        except Exception:
            pass

        had = m.get("had") or {}
        hhad = m.get("hhad") or {}
        ttg = m.get("ttg") or {}
        verdict = m.get("verdict") or {}
        hhad_v = m.get("hhadVerdict") or {}
        vtype = verdict.get("t", "n-a")
        stars = verdict.get("stars", 0) or 0
        vdir = verdict.get("dir")
        hkmo = m.get("hkmo") or {}
        both_drop = hkmo.get("both_drop", False)
        prob = m.get("hadProb") or {}
        sup = m.get("hadSup") or {}
        goals_exp = m.get("goalsExp") or 2.5
        attack = m.get("attack") or {}

        match_options = []

        # ===== 玩法1：胜平负 =====
        # 基于历史回测的实际命中率：good正向50-57%，bad正向18-23%，bad反向60-82%
        # 策略：排除bad正向，纳入bad反向，good正向正常
        for d, label in [("h", "主胜"), ("d", "平局"), ("a", "客胜")]:
            odds = had.get(d)
            if not odds or odds < 1.5:
                continue
            # 基础信心度
            conf = 30.0
            reasons = []
            # 规则触发：基于历史回测调整
            if vtype == "good" and vdir == d:
                # good正向：命中率50-57%，高信心
                conf += stars * 10 + 20
                reasons.append(f"正路{stars}★")
            elif vtype == "bad" and vdir != d:
                # bad反向：bad推荐其他方向，当前方向是反向，命中率60-82%
                reverse_label = {"h": "主胜", "d": "平局", "a": "客胜"}.get(vdir, vdir)
                conf += stars * 8 + 25
                reasons.append(f"反指{stars}★(推{reverse_label})")
            elif vtype == "bad" and vdir == d:
                # bad正向：命中率仅18-23%，大幅降分，基本排除
                conf -= 20
                reasons.append(f"危险正向(低命中)")
            elif vtype == "warn" and vdir == d:
                # warn正向：命中率25%，降分
                conf -= 5
                reasons.append(f"谨慎{stars}★")
            # 移除港澳降水加分（仅用于港澳tab，不影响胜平负分析）
            # 支持率背离（支持率<概率=被低估，有价值）
            d_prob = prob.get(d, 0) or 0
            d_sup = sup.get(d, 0) or 0
            divergence = d_prob - d_sup
            if divergence > 10:
                conf += 10
                reasons.append(f"低估{divergence:.0f}%")
            elif divergence > 5:
                conf += 5
            # 赔率价值（概率×赔率>1有价值）
            value = (d_prob / 100.0) * odds if d_prob else 0
            if value > 1.1:
                conf += 8
                reasons.append(f"价值{value:.2f}")
            elif value > 0.9:
                conf += 3
            # 赔率合理性加分
            if 2.5 <= odds <= 6.0:
                conf += 5
            elif 6.0 < odds <= 9.0:
                conf += 0
            else:
                conf -= 5

            conf = min(95, max(20, conf))
            # bad正向信心度低于50的直接排除（命中率太低）
            if vtype == "bad" and vdir == d and conf < 55:
                continue
            match_options.append({
                "play": "胜平负", "playKey": "spf", "dir": d, "label": label,
                "odds": odds, "confidence": round(conf, 1),
                "score": round(conf * odds, 1), "reasons": reasons
            })

        # ===== 玩法2：让球胜平负 =====
        goal = hhad.get("goal", 0)
        hhad_vtype = hhad_v.get("t", "n-a")
        hhad_stars = hhad_v.get("stars", 0) or 0
        hhad_dir = hhad_v.get("dir")
        hhad_prob = m.get("hhadProb") or {}
        hhad_sup = m.get("hhadSup") or {}
        # 让球方向一致性约束：与核心推荐方向（港澳降水>综合评分>概率最高）保持一致
        core_dir, _ = get_core_direction(m)
        try:
            gv = int(goal)
        except (TypeError, ValueError):
            gv = 0
        allowed_hhad = {"h", "d", "a"}
        if core_dir:
            if core_dir == "h":  # 核心主胜
                allowed_hhad = {"h", "d"} if gv < 0 else {"h"}
            elif core_dir == "a":  # 核心客胜
                allowed_hhad = {"a"} if gv < 0 else {"a", "d"}
            elif core_dir == "d":  # 核心平局
                allowed_hhad = {"a"} if gv < 0 else {"h"}
        for d, label in [("h", "让胜"), ("d", "让平"), ("a", "让负")]:
            if d not in allowed_hhad:
                continue  # 跳过与核心方向矛盾的让球方向
            # 低概率过滤：让球数绝对值>=2时，不选穿盘方向（让2球赢3球+概率极低）
            if gv <= -2 and d == "h":
                continue  # 主队让2球+，让胜需要赢3球+，概率太低
            if gv >= 2 and d == "a":
                continue  # 主队受让2球+，让负需要输3球+，概率太低
            odds = hhad.get(d)
            if not odds or odds < 1.5:
                continue
            conf = 28.0
            reasons = []
            if hhad_vtype != "n-a" and hhad_dir == d:
                conf += hhad_stars * 7 + (12 if hhad_vtype in ("bad", "cold") else 6)
                reasons.append(f"让球规则{hhad_vtype}{hhad_stars}★")
            # 移除港澳降水（仅用于港澳tab，不影响让球盘分析）
            d_prob = hhad_prob.get(d, 0) or 0
            d_sup = hhad_sup.get(d, 0) or 0
            divergence = d_prob - d_sup
            if divergence > 10:
                conf += 8
                reasons.append(f"低估{divergence:.0f}%")
            value = (d_prob / 100.0) * odds if d_prob else 0
            if value > 1.1:
                conf += 6
                reasons.append(f"价值{value:.2f}")
            if 2.5 <= odds <= 5.5:
                conf += 5
            elif odds > 8.0:
                conf -= 5

            conf = min(95, max(20, conf))
            match_options.append({
                "play": f"让球{goal}", "playKey": "hhad", "dir": d, "label": label,
                "odds": odds, "confidence": round(conf, 1),
                "score": round(conf * odds, 1), "reasons": reasons
            })

        # ===== 玩法3：总进球 =====
        if ttg and goals_exp:
            # 泊松分布计算每个进球数的概率
            lam = float(goals_exp)
            poisson_probs = []
            for k in range(8):
                p = math.exp(-lam) * (lam ** k) / math.factorial(k)
                poisson_probs.append(p)
            # 攻防稳定性（样本数越多越稳定）
            ah = attack.get("home") or {}
            aa = attack.get("away") or {}
            stability = min(1.0, ((ah.get("n", 0) or 0) + (aa.get("n", 0) or 0)) / 20.0)

            for k in range(8):
                odds = ttg.get(str(k))
                if not odds or odds < 1.5:
                    continue
                # 基于泊松概率的基础信心度（总进球基于数据模型，基础信心度更高）
                base_prob = poisson_probs[k] * 100
                # 只选概率>8%的合理区间（过滤掉5球以上的低概率博冷选项）
                if base_prob < 8.0:
                    continue
                conf = 45 + base_prob * 1.5 * stability
                reasons = [f"预期{goals_exp}球", f"概率{base_prob:.0f}%"]
                # 偏差越小加分
                diff = abs(k - lam)
                if diff < 0.5:
                    conf += 10
                    reasons.append("最可能区间")
                elif diff < 1.0:
                    conf += 5
                # 赔率价值
                value = (base_prob / 100.0) * odds
                if value > 1.0:
                    conf += 6
                    reasons.append(f"价值{value:.2f}")
                elif value > 0.85:
                    conf += 2
                # 赔率合理性（总进球2-5倍最佳）
                if 1.8 <= odds <= 5.0:
                    conf += 5
                elif odds > 7.0:
                    conf -= 8

                conf = min(95, max(20, conf))
                label = f"{k}球" if k < 7 else "7+球"
                match_options.append({
                    "play": "总进球", "playKey": "ttg", "dir": str(k), "label": label,
                    "odds": odds, "confidence": round(conf, 1),
                    "score": round(conf * odds, 1), "reasons": reasons
                })

        # 每场选择Top3最优选项（信心度×赔率排序，但限制单场赔率≤5.0以控制总倍率、务实命中优先）
        match_options.sort(key=lambda x: x["score"], reverse=True)
        ranked = []
        for opt in match_options:
            if opt["odds"] <= 5.0:
                ranked.append(opt)
            if len(ranked) >= 3:
                break
        if len(ranked) < 3:
            # 若合理区间不足3个，从全量中补足
            for opt in match_options:
                if opt not in ranked:
                    ranked.append(opt)
                if len(ranked) >= 3:
                    break
        for opt in ranked[:3]:  # 每场最多3个选项进入候选
            candidates.append({
                "num": m.get("num"), "league": m.get("league"),
                "home": m.get("home"), "away": m.get("away"),
                "kickoff": kickoff, "play": opt["play"], "playKey": opt["playKey"],
                "dir": opt["dir"], "label": opt["label"],
                "odds": opt["odds"], "confidence": opt["confidence"],
                "score": opt["score"], "reasons": opt["reasons"]
            })

    # 按综合评分排序
    candidates.sort(key=lambda x: x["score"], reverse=True)

    def build_parlay(n, min_odds=2.0, max_odds=10.0, total_cap=None, min_conf=65):
        """从candidates中选n场不同比赛，优先混合玩法，组成串关。
        total_cap: 总赔率上限，控制高倍串关不过度虚高（务实命中优先）。
        min_conf: 最低信心门槛，过滤低信心选项。
        组合搜索：在总赔率上限内选择平均信心最高的组合（命中优先），
        总赔率低于下限时不强求（避免选不满返回None）。"""
        import itertools

        # 候选预过滤：单场赔率范围 + 最低信心门槛
        pool = [c for c in candidates if min_odds <= c["odds"] <= max_odds and c["confidence"] >= min_conf]
        if len(pool) < n:
            # 放宽单场赔率上限，但仍保留合理上限（max_odds*1.3），防止虚高
            relaxed_max = max_odds * 1.3
            pool = [c for c in candidates if c["odds"] >= min_odds and c["odds"] <= relaxed_max and c["confidence"] >= min_conf - 5]

        def combo_ok(comb):
            nums = [c["num"] for c in comb]
            if len(set(nums)) != n:
                return False
            # 玩法分散优先：至少2种玩法（n=2时），n>=3时同玩法最多2个
            plays = [c["playKey"] for c in comb]
            if len(set(plays)) < 2 and n >= 2:
                return False
            total = 1.0
            for c in comb:
                total *= c["odds"]
            if total_cap and total > total_cap:
                return False
            return True

        best = None
        best_conf = -1
        for comb in itertools.combinations(pool, n):
            if not combo_ok(comb):
                continue
            avg_conf = sum(c["confidence"] for c in comb) / n
            # 优先高信心；同信心优先总赔率接近上限（保持高倍价值）
            if avg_conf > best_conf:
                best_conf = avg_conf
                best = comb

        if best is None:
            # 最后放宽：不限制玩法分散，但总赔率上限仍生效
            for comb in itertools.combinations(pool, n):
                nums = [c["num"] for c in comb]
                if len(set(nums)) != n:
                    continue
                total = 1.0
                for c in comb:
                    total *= c["odds"]
                if total_cap and total > total_cap:
                    continue
                avg_conf = sum(c["confidence"] for c in comb) / n
                if avg_conf > best_conf:
                    best_conf = avg_conf
                    best = comb

        if best is None:
            return None
        selected = list(best)
        total_odds = 1.0
        for s in selected:
            total_odds *= s["odds"]
        avg_conf = sum(s["confidence"] for s in selected) / len(selected)
        play_types = list(set(s["play"] for s in selected))
        return {
            "type": f"{n}串1", "legs": selected,
            "totalOdds": round(total_odds, 2),
            "avgConfidence": round(avg_conf, 1),
            "minOdds": min(s["odds"] for s in selected),
            "maxOdds": max(s["odds"] for s in selected),
            "playTypes": play_types,
            "isMixed": len(play_types) > 1
        }

    # 中倍稳胆策略：放弃高倍，专注命中率
    # 2串1：单场赔率1.8-3.5，总赔率上限8倍，信心门槛80（稳胆优先）
    parlay2 = build_parlay(2, min_odds=1.8, max_odds=3.5, total_cap=8.0, min_conf=80)
    # 3串1：单场赔率1.8-3.0，总赔率上限15倍，信心门槛80
    parlay3 = build_parlay(3, min_odds=1.8, max_odds=3.0, total_cap=15.0, min_conf=80)

    result = {
        "generatedAt": time.strftime("%Y-%m-%d %H:%M:%S"),
        "candidateCount": len(candidates),
        "strategy": "中倍稳胆：放弃高倍追求命中率，单场赔率1.8-3.5中倍区间，信心门槛80%+，bad反向+good正向策略，混合过关玩法分散",
        "parlay2": parlay2,
        "parlay3": parlay3
    }
    p2_info = f"{parlay2['totalOdds']}倍(信心{parlay2['avgConfidence']}%,{'混合' if parlay2.get('isMixed') else '单一'})" if parlay2 else "N/A"
    p3_info = f"{parlay3['totalOdds']}倍(信心{parlay3['avgConfidence']}%,{'混合' if parlay3.get('isMixed') else '单一'})" if parlay3 else "N/A"
    print(f"  中倍稳胆串关：候选{len(candidates)}个，2串1{p2_info}，3串1{p3_info}", flush=True)
    return result


def implied_from_odds(odds):
    """从胜平负赔率反推归一化隐含概率（去水位，百分数）。

    CI 海外 IP 拿不到官方支持率接口时走 500.com 备用源，只有赔率没有
    hProbability/支持率。下游规则判定、比分预测、串关都以 hadProb 为主信号，
    全 None 会把在售场次整批剔除（串关 `d_prob < 10: continue` → 候选池 0）。
    这里按 1/odds 归一化还原市场共识概率，让备用源结构与官方源等价。
    """
    if not isinstance(odds, dict):
        return {}
    inv = {}
    for k in ("h", "d", "a"):
        v = odds.get(k)
        if isinstance(v, (int, float)) and v > 1:
            inv[k] = 1.0 / v
    s = sum(inv.values())
    if not s:
        return {}
    return {k: round(v / s * 100, 1) for k, v in inv.items()}


def calc_kelly_index(odds, prob):
    """凯利指数计算：Kelly = (b*p - q) / b
    b=净赔率, p=胜率, q=败率
    凯利值>0为正期望值，<0为负期望值"""
    if not odds or odds <= 1:
        return 0
    b = odds - 1
    p = prob / 100
    q = 1 - p
    kelly = (b * p - q) / b
    return kelly * 100  # 百分比表示

def poisson_prob(lam_home, lam_away, max_goals=6):
    """泊松分布计算比分概率矩阵
    返回 {(h,a): prob} 字典"""
    import math
    probs = {}
    for h in range(max_goals+1):
        for a in range(max_goals+1):
            p = (math.exp(-lam_home) * lam_home**h / math.factorial(h)) * \
                (math.exp(-lam_away) * lam_away**a / math.factorial(a))
            probs[(h, a)] = p
    return probs

def poisson_1x2_probs(lam_home, lam_away):
    """泊松分布计算胜平负概率"""
    probs = poisson_prob(lam_home, lam_away)
    home_win = sum(p for (h, a), p in probs.items() if h > a)
    draw = sum(p for (h, a), p in probs.items() if h == a)
    away_win = sum(p for (h, a), p in probs.items() if h < a)
    total = sum(probs.values())
    return {
        'h': home_win/total*100,
        'd': draw/total*100,
        'a': away_win/total*100
    }

def calc_cold_hot_deviation(prob, support):
    """冷热偏差：概率 vs 支持率
    正值=概率高于支持率（被低估，热）
    负值=概率低于支持率（被高估，冷）"""
    return prob - support

def calc_market_move(open_odds, curr_odds):
    """市场异动：初盘 vs 即时盘变动
    负值=赔率下降（庄家看好，降水）
    正值=赔率上升（庄家不看好，升水）"""
    if not open_odds or not curr_odds:
        return 0
    return (curr_odds - open_odds) / open_odds * 100

def calc_dispersion(mov_data):
    """离散度分析：多家博彩公司赔率标准差/均值
    离散度高=分歧大，离散度低=共识强"""
    if not mov_data or len(mov_data) < 3:
        return 0
    # 过滤None值和非数字值
    vals = [v for v in mov_data.values() if v is not None and isinstance(v, (int, float))]
    if len(vals) < 3:
        return 0
    mean = sum(vals) / len(vals)
    if mean == 0:
        return 0
    variance = sum((v - mean)**2 for v in vals) / len(vals)
    std = variance ** 0.5
    return std / mean * 100  # 变异系数

def detect_upset_risk(prob, odds, kelly):
    """冷门预警：综合判断爆冷风险
    返回风险等级: low/medium/high"""
    # 概率<30%但赔率异常低？
    if prob < 30 and odds < 2.0:
        return 'high'  # 异常低赔，可能有内幕
    # 概率>50%但凯利值为负？
    if prob > 50 and kelly < -5:
        return 'medium'  # 正路但价值为负
    # 概率在30-40%之间？
    if 30 <= prob <= 40:
        return 'medium'
    return 'low'

def five_dimension_rating(prob_score, rule_score, odds_score, form_score, market_score):
    """五维雷达评分：五个维度综合评分
    每个维度0-20分，总分100"""
    return min(100, max(0, prob_score + rule_score + odds_score + form_score + market_score))


def calc_same_odds_signal(history_records, play_key, direction, ref_odds=None, goal=None, tol=0.12):
    """历史同指：在相同赔率参考（胜平负）或相同盘口线（让球）下，该方向的历史命中率。
    免费自建，仅用竞彩官方 history.json（354+ 已完赛记录），不依赖任何付费数据。
    返回 (hit_rate 0-100 或 None, n)。样本<5 视为无统计意义，返回 (None, n)。

    - play_key='spf'：用 ref_odds{h,d,a} 全赔率线匹配（三家赔率均落在容差内才算"同指"）
    - play_key='hhad'：用 goal 盘口线 + 同方向 verdict 匹配（历史同盘口同方向命中）
    """
    hits = 0
    n = 0
    for r in history_records:
        res = r.get("result")
        if not isinstance(res, dict) or res.get("home") is None or res.get("cancel"):
            continue
        if play_key == "spf":
            o = r.get("odds") or {}
            # 当前候选赔率含 None（某方向未开售）则无法比"同指"，跳过
            if not (isinstance(ref_odds, dict) and ref_odds.get(direction) is not None):
                continue
            ro = ref_odds.get(direction)
            ho = o.get(direction)
            if not (isinstance(ho, (int, float)) and isinstance(ro, (int, float))):
                continue
            # 同指：按所投方向的那一赔匹配（同一赔率参考 historically 命中率）；
            # 放宽到单一方向容差，避免"三家全同"过于稀疏导致几乎无样本
            if abs(ho - ro) > max(tol, 0.15):
                continue
            actual = res.get("had")
            if actual == direction:
                hits += 1
            n += 1
        elif play_key == "hhad":
            # v1.7.132：goal=None 表示「不限盘口线、同方向」统计。
            # 按「盘口线+方向」细分会让样本稀疏到 1~17 场（统计上无意义），
            # 供串关证据判定时回退到跨盘口的同方向大样本口径。
            if goal is not None and r.get("goal") != goal:
                continue
            hv = r.get("hhadVerdict") or {}
            if hv.get("dir") != direction:
                continue
            hh = r.get("hhadHit")
            if hh == "hit":
                hits += 1
            elif hh == "miss":
                pass
            else:
                continue  # n-a 不计入样本
            n += 1
    if n < 5:
        return (None, n)
    return (round(hits / n * 100, 1), n)

def _parlay_true_prob(m, d):
    """串关用：返回该方向的「校准后真实概率」(0-1)。

    优先采用智能引擎 smart_engine 的校准概率 p_cal：
      - 若串关方向与规则推荐方向一致 → 直接用 p_cal
      - 若方向相反（利用 bad 反指）→ 把 (1 - p_cal) 按市场相对比例分配给其余两个结果
    无智能引擎结果时回退到市场概率。
    """
    prob = m.get("hadProb") or m.get("prob") or {}
    base = (prob.get(d) or 0) / 100.0
    smart = m.get("smart") or {}
    v = m.get("verdict") or {}
    vdir = v.get("dir")
    p_cal = smart.get("p_cal")
    if not vdir or p_cal is None:
        return base
    if d == vdir:
        return min(max(p_cal, 0.02), 0.96)
    others = [x for x in ("h", "d", "a") if x != vdir]
    tot = sum((prob.get(x) or 0) for x in others)
    rest = max(0.0, 1.0 - min(max(p_cal, 0.02), 0.96))
    if tot <= 0:
        return base
    return min(max(rest * (prob.get(d) or 0) / tot, 0.01), 0.95)


def parlay_canon_score(opt):
    """单场单意见选腿评分（v1.7.43 起信心度主导，模块级便于单测）。

    归因实证（parlay_history 72 组回溯 + 二项检验，2026-10-26）：
    · confidence≥75 的腿实际命中 94%（17/18）——模型信心信号可靠；
    · 同指命中率 45-60% 区间实际命中仅 17%（4/24），市场共识期望 49%
      （z=-3.15, p<0.001）——该区间虚高且反向，不能当「地面真相」；
    · 同指 ≥65 区间实际 67-82%（可信），仅作小幅加成（封顶 0.08）。
    v1.7.25/33 曾把同指命中率当第一选腿信号（confidence 权重压到 0.002），
    正是 10-20 后腿级命中 55.9%→36.6%、11 组全败的直接原因。

    评分 = 信心度 + 同指分段修正 + 0.10×EV + 技术/五维微调。
    pTrue 相对市场共识的超额部分截断在 ±0.06（细分样本置信区间全部跨越 0，
    个别 pTrue 异常值不得借此放大 EV）。
    """
    conf = opt.get("confidence") or 0
    so, n_ = opt.get("sameOddsHit"), opt.get("sameOddsN") or 0
    base = conf / 100.0
    so_adj = 0.0
    if so is not None and n_ >= 10:
        if so >= 65:
            so_adj = min(0.08, (so - 65) / 100.0)
        elif so >= 45:
            so_adj = -0.10
        else:
            so_adj = -0.15
    # 该选项自身的期望值（市场共识 + alpha 收缩，与 _leg_prob 同口径）
    o = opt.get("odds") or 0
    ev = 0.0
    if o > 1:
        p_market = 0.886 / o
        pt = opt.get("pTrue")
        if pt:
            p = p_market + (pt / 100.0 - p_market) * 0.6
            p = min(max(p, p_market - 0.06), p_market + 0.06)
        else:
            p = p_market
        ev = min(max(p, 0.01), 0.95) * o - 1.0
    # 期望权重 0.10（原 0.15）：EV 只是调味，信心度才是主菜；
    # tech/fiveDim 仅在同信心同同指时做细微区分。
    return (base + so_adj
            + 0.10 * ev
            + 0.01 * (opt.get("techCount") or 0)
            + 0.001 * (opt.get("fiveDim") or 0))


def _gen_parlay_one_batch(matches):
    """单批次计算核心：先选合格单场，再按把握度取前缀成档（v1.7.122）。

    仅处理「同一竞彩开售批次」的场次；批次分组由 gen_safe_parlay 在外层完成，
    保证任一组合的腿必然来自同一次开售的赛程（不跨周五/周六/周日）。

    用户原则：「选串关是把单场最有把握、数据支撑、合理，才进行串关组合」。
    实现顺序（与旧版「先定 2/3/4 腿档位再凑组合」相反）：
    1. 单场资格（统一绝对标准，不因档位变化）：
       数据支撑 = 后验实证超额 ≥0pt 且同方向样本 ≥20 场；
       合理     = 赔率 1.60~3.20、非平局；
       最有把握 = 按后验命中率降序（市场共识先验 + 历史实证贝叶斯收缩）。
    2. 串关 = 合格单场序列前缀：稳健=前2、均衡=前3、精锐=前4，
       天然严格嵌套、总赔随腿数单调递增。
    3. 合格单场不足 N 条，第 N 档留空并写明原因，绝不降门槛/换腿硬凑。
    4. 推荐资格硬条件：真实 EV 达标且全组无负超额腿，否则标「观望」。
    EV 双口径：模型口径（pTrue，偏保守，仅参考）与地面真实口径
    （腿级实证命中率×总赔−1）——推荐判定/达标线/仓位用真实口径。
    返回 {parlay2, parlay3, parlay4, generatedAt, strategy, candidatePool, ...}
    """
    # v1.7.123 批次隔离：外层 gen_safe_parlay 已按竞彩销售批次（编号前缀=date）
    # 分组、并逐批只保留未开赛场次后调用本函数，因此这里**不再做 36 小时滚动窗口**。
    # 那个窗口正是「把周五和周六串起来」的根因：它把多个批次混进同一候选池再全池
    # 取前缀，稳健 2 串 1 会变成「周六009 + 周五006」；同时它还会把开球时间距现在
    # >36h 的批次（如周日）整体丢弃，让后续批次永远不参与。批次本身就是赛程边界。
    # 这里只再做一次「剔除已开赛」兜底（下方 candidates 循环还有一道同口径过滤）。
    today = time.strftime("%Y-%m-%d")
    now_ts = time.time()

    def _kickoff_ts(m):
        k = m.get("kickoff") or ""
        try:
            if len(k) >= 10 and k[4] == '-':
                return time.mktime(time.strptime(k[:16], "%Y-%m-%d %H:%M"))
            return time.mktime(time.strptime(f"{m.get('date','')} {k}", "%Y-%m-%d %H:%M"))
        except Exception:
            return None

    _kept = []
    for _m in matches:
        _kt = _kickoff_ts(_m)
        if _kt is None or _kt > now_ts:
            _kept.append(_m)
    matches = _kept

    # v1.7.120 精简模式检测：CI 海外 IP 走 500.com 备用源时，官方支持率 / 盘口异动 /
    # 规则星级等技术信号接口不通，matches 里这些字段普遍为空。此时 confidence 公式
    # （d_prob×0.85 后被 max(55) 压平）会失去区分度、全部候选恒等于 55，永远够不到
    # 档位门槛 70/68/65 → 三档恒空。官方完整数据下这些信号齐全，不触发精简分支。
    def _has_rich_signal(m):
        v = m.get("verdict") or {}
        sup = m.get("hadSup") or {}
        mov = m.get("mov") or {}
        return ((isinstance(v.get("stars"), (int, float)) and (v.get("stars") or 0) > 0)
                or any(isinstance(x, (int, float)) for x in sup.values())
                or any(isinstance(x, (int, float)) for x in mov.values()))
    _rich_n = sum(1 for _m in matches if _has_rich_signal(_m))
    _lean = (len(matches) > 0 and _rich_n < len(matches) * 0.5)

    # ===== v1.7.121 选边证据口径：后验命中率 + 实证超额 =====
    # 用户质疑「不要看到低赔率就无脑的选」——核查属实。旧 _lean_pick 主项是
    # 0.886/赔率（赔率越低分越高），而 confidence 又由同一个值线性映射，属于
    # 「用赔率证明赔率」的循环论证，不是独立证据。实测当日 5 条腿有 3 条的
    # 「历史同方向实证命中率 − 市场定价隐含概率」为负（−8.1 / −7.4 / −0.5pt），
    # 即这些低赔腿历史上反而比市场定价更差，系统却因「便宜」选了它们。
    # 现改为以市场共识概率为先验、用历史同方向实证命中率做贝叶斯收缩：
    #   · post = (n·实证 + 60·市场)/(n+60)：样本越少越贴近市场，不放大噪声；
    #   · edge = post − 市场：>0 才说明历史数据支持该选项比定价更靠谱；
    #   · 选边按 post（绝对把握）排序，低赔不再自动胜出；
    #   · 样本 <20 视为证据不足，退回市场概率且 edge=0（不假装有利）；
    #   · edge<−1pt 的腿不得进入「推荐」组合，从根上杜绝乱推荐。
    _PAYBACK_PRIOR = 0.886
    _PRIOR_N = 60.0          # 收缩强度：n=205 时实证权重 77%，n=54 时 47%
    # 证据准入门槛：组合内不得含「历史实证差于市场定价」的腿。
    # 凑不出组合时该档如实留空（页面说明原因），绝不硬凑。
    _STRICT_EDGE = os.environ.get("JC_STRICT_EDGE", "1") != "0"

    def _posterior(o):
        _o = o.get("odds") or 99
        market = _PAYBACK_PRIOR / _o if _o > 1 else 0.30
        so, n = o.get("sameOddsHit"), o.get("sameOddsN") or 0
        # v1.7.132：旧写法 n<20 就整段丢弃实证、返回 market / edge=0，
        # 与贝叶斯收缩（_PRIOR_N 本就是为小样本准备的）自相矛盾，还让所有
        # 中小样本选项 edge 恒为 0、再被 empN>=20 挡掉 → 结构性 0 档。
        # 现改为：有样本就用后验平滑（样本越小越向先验收缩，不会虚高优势），
        # 完全无样本才退回市场先验。资格门槛 empN>=20 保持不变，不降标准。
        if so is None or n <= 0:
            return market, 0.0, n, None
        post = (n * (so / 100.0) + _PRIOR_N * market) / (n + _PRIOR_N)
        return post, post - market, n, so

    # v1.7.132 结构性修复：资格门槛必须在「选唯一意见」阶段就生效，故提前定义。
    # 旧实现先按后验把握度挑出每场唯一意见（几乎必然是 1.1x 低赔正路），之后
    # 才判资格（赔率 1.6~3.2 / 实证超额≥0 / 样本≥20 / 非平局）→ 低赔必然因
    # 「蚊子肉」出界；而同场真正合理的中赔选项（让胜@1.88 / 让负@1.63 等）
    # 早在选意见时就被丢掉，根本没机会进入候选池。于是每天 qualified=0、三档
    # 全空，用户看到「分层串关如同摆设」。门槛一个都不降，只把判定前移。
    _EDGE_MIN = float(os.environ.get("JC_EDGE_MIN", "0"))
    _MIN_EMP_N = 20
    _MIN_LEG_ODDS = 1.60
    _MAX_LEG_ODDS = 2.80 if _lean else 3.20

    # 诊断统计：逐项记录选项被排除的原因，便于核对「为什么今天没有合格单场」
    _opt_stat = {"total": 0, "ok": 0, "odds": 0, "draw": 0, "edge": 0, "sample": 0}

    def _opt_qualified(o):
        """选项级资格：与后续单场资格 _qualified(c) 完全同源，不降低任何标准。"""
        _opt_stat["total"] += 1
        _o = o.get("odds") or 0
        if not (_MIN_LEG_ODDS <= _o <= _MAX_LEG_ODDS):
            _opt_stat["odds"] += 1
            return False                      # 蚊子肉 / 高赔冷门
        if o.get("dir") == "d":
            _opt_stat["draw"] += 1
            return False                      # 平局天然难测
        _p, _e, _n, _so = _posterior(o)
        if _e * 100 < _EDGE_MIN:
            _opt_stat["edge"] += 1
            return False                      # 历史实证跑不赢市场定价
        if _n < _MIN_EMP_N:
            _opt_stat["sample"] += 1
            return False                      # 样本不足，不假装有利
        _opt_stat["ok"] += 1
        return True

    candidates = []
    _qual_picked = [0]          # v1.7.132：有多少场选到了「原本已合格」的意见
    # 历史同指：载入竞彩官方赛果库（354+ 已完赛），免费自建同指命中率
    try:
        _hist_recs = load_history()
    except Exception:
        _hist_recs = []

    for m in matches:
        kickoff = m.get("kickoff") or ""
        try:
            if len(kickoff) >= 10 and kickoff[4] == '-':
                kt = time.mktime(time.strptime(kickoff, "%Y-%m-%d %H:%M"))
            else:
                kt = time.mktime(time.strptime(f"{m.get('date','')} {kickoff}", "%Y-%m-%d %H:%M"))
            if kt < now_ts:
                continue
        except Exception:
            pass

        had = m.get("had") or {}
        hhad = m.get("hhad") or {}
        ttg = m.get("ttg") or {}
        verdict = m.get("verdict") or {}
        hhad_v = m.get("hhadVerdict") or {}
        vtype = verdict.get("t", "n-a")
        stars = verdict.get("stars", 0) or 0
        vdir = verdict.get("dir")
        prob = m.get("hadProb") or {}
        sup = m.get("hadSup") or {}
        # v1.7.120 概率兜底：备用源 / 旧快照没有隐含概率时，就地从赔率反推，
        # 避免 `if d_prob < 10: continue` 把整批在售场次剔除、候选池清零。
        # 主流程已在 [3/6] 统一补过，这里再兜一层以覆盖单独调用与历史文件。
        if not any(isinstance(v, (int, float)) for v in prob.values()):
            prob = implied_from_odds(had)
        goals_exp = m.get("goalsExp") or 2.5
        attack = m.get("attack") or {}
        form = m.get("form") or {}
        score_rec = m.get("scoreRec") or {}
        had_open = m.get("hadOpen") or {}
        mov = m.get("mov") or {}
        hh_prob = m.get("hhProb") or 0
        aa_prob = m.get("aaProb") or 0

        match_options = []

        # ===== 泊松分布概率 =====
        exp_home = score_rec.get("expHome", goals_exp * 0.55)
        exp_away = score_rec.get("expAway", goals_exp * 0.45)
        poisson_probs = poisson_1x2_probs(exp_home, exp_away)

        # ===== 离散度 =====
        disp_h = abs(calc_dispersion(mov)) if mov else 0

        # ===== 稳胆指数（综合8维数据，0-100）：替代赔率筛选，选数据支撑最强的比赛 =====
        # 1. 实力集中度（20分）：概率越集中，实力差距越大
        max_prob = max(prob.get("h") or 0, prob.get("d") or 0, prob.get("a") or 0)
        strength_score = min(20, max(0, (max_prob - 33) * 0.6))
        # 2. 状态优势（15分）：近期状态差异
        form_h = (form.get("home") or {}).get("wr", (form.get("home") or {}).get("winRate", 50)) or 50
        form_a = (form.get("away") or {}).get("wr", (form.get("away") or {}).get("winRate", 50)) or 50
        form_diff = abs(form_h - form_a)
        form_score = min(15, form_diff * 0.3)
        # 3. 规则信号（25分）：bad反指权重加倍
        rule_score = 0
        if vtype == "bad":
            rule_score = 18 + stars * 2  # bad反指历史命中率74%
        elif vtype == "good" and stars >= 3:
            rule_score = 10 + stars * 2
        elif vtype == "cold":
            rule_score = 8
        rule_score = min(25, rule_score)
        # 4. 盘口一致性（15分）：市场概率与泊松吻合度
        poisson_max = max(poisson_probs.get("h") or 0, poisson_probs.get("d") or 0, poisson_probs.get("a") or 0)
        prob_align = 15 - min(15, abs(max_prob - poisson_max) * 1.5)
        # 5. 离散度（10分）：越低越稳定，无数据默认稳定给10分
        if mov:
            disp_h = abs(calc_dispersion(mov))
            disp_score = max(0, 10 - disp_h * 2)
        else:
            disp_score = 10
        # 6. 冷热偏差（10分）：支持率与概率背离
        sup_max = max(sup.get("h") or 0, sup.get("d") or 0, sup.get("a") or 0)
        cold_hot = abs(max_prob - sup_max)
        cold_score = min(10, cold_hot * 0.5)
        # 7. 比分预测信心（5分）
        score_conf = score_rec.get("confidence", 50) or 50
        score_score = min(5, score_conf / 20)
        # 稳胆指数合计（纯7维数据模型，不含赔率——赔率只展示不筛选）
        stable_index = strength_score + form_score + rule_score + prob_align + disp_score + cold_score + score_score
        stable_index = round(min(100, max(0, stable_index)), 1)

        # ========== 选项1：胜平负（核心玩法，历史命中率最高） ==========
        for d, label in [("h", "主胜"), ("d", "平局"), ("a", "客胜")]:
            odds = had.get(d)
            d_prob = prob.get(d, 0) or 0
            if not odds:
                continue
            # 赔率只过滤极端不合理值，不做硬下限——由稳胆指数（含赔率合理性维度）自然筛选
            if odds < 1.05 or odds > 10.0:
                continue
            # 概率下限：原本 25% 会把绝大多数中高赔（赔率>3.3）直接剔除，
            # 导致候选池只剩 1.3-1.5 的蚊子肉。放宽到 10%，各档位再按自身门槛把关。
            # v1.7.132：备用源常缺 hadProb，旧写法把「没数据」当成「概率 0」
            # 直接砍掉全部中赔方向。用同组三项赔率去水后的隐含概率作代理。
            if d_prob <= 0:
                _hv = [had.get(k) for k in ("h", "d", "a")]
                if all(isinstance(v, (int, float)) and v > 1 for v in _hv) and odds > 1:
                    _inv = [1.0 / v for v in _hv]
                    d_prob = round((1.0 / odds) / sum(_inv) * 100, 1)
            if d_prob < 10:
                continue
            # 稳胆指数门槛：只有数据支撑强的比赛才进入候选（32分门槛，适配数据维度少的联赛）
            if stable_index < 32:
                continue

            reasons = []
            tech_count = 0

            # 1. 市场概率
            reasons.append(f"市场概率{d_prob:.0f}%")

            # 2. 泊松验证
            poisson_p = poisson_probs.get(d, 0)
            poisson_diff = abs(poisson_p - d_prob)
            if poisson_diff < 8:
                tech_count += 1
                reasons.append(f"泊松验证{poisson_p:.0f}%")
            elif poisson_diff < 15:
                reasons.append(f"泊松参考{poisson_p:.0f}%")

            # 3. 凯利指数
            kelly = calc_kelly_index(odds, d_prob)
            if kelly > 0:
                tech_count += 1
                reasons.append(f"凯利正价值{kelly:.1f}")
            elif kelly > -8:
                reasons.append(f"凯利{kelly:.1f}")

            # 4. 规则引擎（bad反指是核心信号，历史命中率74%）
            rule_conf = 0
            if vtype == "bad" and vdir != d:
                tech_count += 2  # bad反指权重加倍
                rule_conf = 75 + stars * 3
                reverse_label = {"h": "主胜", "d": "平局", "a": "客胜"}.get(vdir, vdir)
                reasons.append(f"反指{stars}★(推{reverse_label})")
            elif vtype == "good" and vdir == d and stars >= 3:
                tech_count += 1
                rule_conf = 70 + stars * 2
                reasons.append(f"正路{stars}★")
            elif vtype == "cold" and vdir == d:
                tech_count += 1
                rule_conf = 72
                reasons.append("冷门确认")

            # 5. 盘口异动
            open_odds = had_open.get(d)
            if open_odds:
                move = calc_market_move(open_odds, odds)
                if move < -3:
                    tech_count += 1
                    reasons.append(f"降水{abs(move):.1f}%")
                elif move > 3:
                    reasons.append(f"升水{move:.1f}%")

            # 6. 冷热偏差
            d_sup = sup.get(d, 0) or 0
            cold_hot = calc_cold_hot_deviation(d_prob, d_sup)
            if cold_hot > 8:
                tech_count += 1
                reasons.append(f"被低估{cold_hot:.0f}%")

            # 7. 状态优势
            hf = form.get("home") or {}
            af = form.get("away") or {}
            if d == "h" and hf.get("wr", 0) > af.get("wr", 0) + 15:
                tech_count += 1
                reasons.append(f"主队状态{hf.get('wr',0)}%")
            elif d == "a" and af.get("wr", 0) > hf.get("wr", 0) + 15:
                tech_count += 1
                reasons.append(f"客队状态{af.get('wr',0)}%")

            # 8. 离散度
            if disp_h > 0 and disp_h < 8:
                tech_count += 1
                reasons.append(f"共识强(离散{disp_h:.0f}%)")

            # 冷门预警（只标记不扣tech，tech是数据维度计数；风险通过conf上限体现）
            upset = detect_upset_risk(d_prob, odds, kelly)
            if upset == 'high':
                reasons.append("⚠冷门预警")

            # ===== 综合信心度（纯数据驱动，不含赔率——赔率只展示不筛选） =====
            # 基础：市场概率 * 0.85（市场概率通常高估）
            base_conf = d_prob * 0.85
            # 技术加成：每项+2.5%
            tech_bonus = tech_count * 2.5
            # 规则加成：bad反指历史命中率74%，权重0.6
            rule_bonus = max(0, rule_conf - base_conf) * 0.6 if rule_conf else 0
            # 平局惩罚：平局天然难猜
            draw_penalty = 5 if d == "d" else 0

            conf = base_conf + tech_bonus + rule_bonus - draw_penalty
            conf = min(88, max(55, conf))

            # 筛选：纯数据驱动，赔率不参与，三档门槛
            # 1. bad反指(历史命中率74%)：tech≥1，反指本身是强依据
            # 2. good≥4★且方向一致：tech≥1，高星正路也是强依据
            # 3. 无强信号：tech≥2，需多维度交叉验证
            has_bad_reverse = (vtype == "bad" and vdir != d)
            has_good_strong = (vtype == "good" and stars >= 3 and vdir == d)
            # 入池只要求技术验证达标（conf 已被下限截断到 55，再叠加 conf 门槛等于排除中高赔）；
            # 真正的严格程度由各档位的 minConf / minJoint 控制。
            if has_bad_reverse:
                pass_filter = tech_count >= 1
            elif has_good_strong:
                pass_filter = tech_count >= 1
            else:
                pass_filter = tech_count >= 2
            if pass_filter:
                # ===== 历史同指（免费自建，仅用竞彩官方 history.json）=====
                so_hit, so_n = calc_same_odds_signal(_hist_recs, "spf", d, ref_odds=had)
                if so_hit is not None:
                    if so_hit >= 60 and so_n >= 10:  # 同指高命中：价值确认，+1 技术维度
                        tech_count += 1
                    same_odds_hit, same_odds_n = so_hit, so_n
                else:
                    same_odds_hit, same_odds_n = None, so_n
                # ===== 五维雷达（真实输出，已接线）：市场概率/规则/赔率价值/状态/市场共识 =====
                fd_prob = min(20, strength_score + max(0, prob_align - 5) * 0.9)
                fd_rule = min(20, rule_conf * 0.22)
                fd_odds = min(20, max(0, kelly) * 4)
                fd_form = min(20, abs(form_h - form_a) * 0.5)
                fd_mkt = min(20, disp_score * 1.4 + cold_score * 0.6)
                five_dim = round(five_dimension_rating(fd_prob, fd_rule, fd_odds, fd_form, fd_mkt), 1)
                match_options.append({
                    "play": "胜平负", "playKey": "spf", "dir": d, "label": label,
                    "odds": odds, "confidence": round(conf, 1),
                    "score": round(conf * odds, 1), "reasons": reasons,
                    "techCount": tech_count,
                    "pTrue": round(_parlay_true_prob(m, d) * 100, 2),
                    "sameOddsHit": same_odds_hit, "sameOddsN": same_odds_n,
                    "fiveDim": five_dim
                })

        # ========== 选项2：让球胜平负（辅助玩法，最多1场） ==========
        goal = hhad.get("goal", 0)
        hhad_prob = m.get("hhadProb") or {}
        hhad_vtype = hhad_v.get("t", "n-a")
        hhad_stars = hhad_v.get("stars", 0) or 0
        hhad_dir = hhad_v.get("dir")
        core_dir, _ = get_core_direction(m)
        try:
            gv = int(goal)
        except (TypeError, ValueError):
            gv = 0

        for d, label in [("h", "让胜"), ("d", "让平"), ("a", "让负")]:
            odds = hhad.get(d)
            d_prob = hhad_prob.get(d, 0) or 0
            if not odds:
                continue
            # 赔率只过滤极端不合理值，由稳胆指数自然筛选
            if odds < 1.05 or odds > 10.0:
                continue
            # 概率下限：原本 25% 会把绝大多数中高赔（赔率>3.3）直接剔除，
            # 导致候选池只剩 1.3-1.5 的蚊子肉。放宽到 10%，各档位再按自身门槛把关。
            # v1.7.132：精简数据源（500.com 备用源）常缺 hhadProb，旧写法把
            # 「没数据」当成「概率 0」→ d_prob<10 一刀切掉全部让球选项，候选池
            # 只剩 1.1x 低赔正路，随后又被赔率 1.6~3.2 门槛排除 → 每天 0 档。
            # 现用同组三项让球赔率去水后的隐含概率作代理（口径与官方一致，不编造优势）。
            if d_prob <= 0:
                _hh = [hhad.get(k) for k in ("h", "d", "a")]
                if all(isinstance(v, (int, float)) and v > 1 for v in _hh) and odds > 1:
                    _inv = [1.0 / v for v in _hh]
                    d_prob = round((1.0 / odds) / sum(_inv) * 100, 1)
            if d_prob < 10:
                continue
            # 稳胆指数门槛
            if stable_index < 50:
                continue
            # 注：让球盘方向与胜平负核心方向不矛盾，让负=主队赢不了2球+

            reasons = [f"让球概率{d_prob:.0f}%", f"盘口{goal}"]
            tech_count = 0

            # 规则引擎
            if hhad_vtype == "good" and hhad_dir == d and hhad_stars >= 3:
                tech_count += 2
                reasons.append(f"让球规则{hhad_stars}★")
            elif hhad_vtype == "bad" and hhad_dir != d:
                tech_count += 1
                reasons.append("让球反指")

            # 与胜平负bad反指联动：bad反指平局时，主队让球选让负=高信心
            bad_reverse_bonus = 0
            if vtype == "bad" and vdir == "d":  # 胜平负反指平局
                if gv < 0 and d == "a":  # 主队让球，选让负（主队赢不了2球+）
                    tech_count += 3
                    bad_reverse_bonus = 18
                    reasons.append("反指平局→让负(高信心)")
                elif gv > 0 and d == "h":  # 主队受让，选让胜（客队赢不了2球+）
                    tech_count += 3
                    bad_reverse_bonus = 18
                    reasons.append("反指平局→让胜(高信心)")
            elif vtype == "bad" and vdir == "h":  # 胜平负反指主胜
                if gv < 0 and d == "h":  # 主队让球，选让胜（主队赢2球+）
                    tech_count += 2
                    bad_reverse_bonus = 12
                    reasons.append("反指主胜→让胜")
                elif gv > 0 and d == "h":  # 主队受让，选让胜（主队不败）
                    tech_count += 2
                    bad_reverse_bonus = 12
                    reasons.append("反指主胜→让胜(受让)")
            elif vtype == "bad" and vdir == "a":  # 胜平负反指客胜
                if gv > 0 and d == "a":  # 主队受让，选让负（客队赢2球+）
                    tech_count += 2
                    bad_reverse_bonus = 12
                    reasons.append("反指客胜→让负")
                elif gv < 0 and d == "a":  # 主队让球，选让负（客队不败）
                    tech_count += 2
                    bad_reverse_bonus = 12
                    reasons.append("反指客胜→让负(让球)")

            # 与胜平负核心方向一致
            if core_dir and ((core_dir == "h" and d == "h") or (core_dir == "a" and d == "a")):
                tech_count += 1
                reasons.append("与核心方向一致")

            # 让球盘信心度（纯数据驱动，不含赔率）
            base_conf = d_prob * 0.95  # 让球盘概率本身较准
            tech_bonus = tech_count * 3
            conf = base_conf + tech_bonus + bad_reverse_bonus
            conf = min(88, max(55, conf))

            # 让球筛选：三档门槛
            has_bad = bad_reverse_bonus > 0
            has_good_strong = (vtype == "good" and stars >= 3)
            if has_bad:
                pass_filter = tech_count >= 1 and conf >= 55
            elif has_good_strong:
                pass_filter = tech_count >= 1 and conf >= 55
            else:
                pass_filter = tech_count >= 2 and conf >= 58
            if pass_filter:
                # ===== 历史同指（按盘口线 + 同方向匹配，免费自建）=====
                so_hit, so_n = calc_same_odds_signal(_hist_recs, "hhad", d, goal=str(goal))
                _scope = "同盘口同方向"
                # v1.7.132：盘口线细分导致样本稀疏（实测 1~17 场），不足以支撑
                # 「数据支撑」判定。回退到「同方向跨盘口」的大样本口径，并在
                # 逐腿证据里如实标注口径，不降低任何门槛、不编造优势。
                if so_n < _MIN_EMP_N:
                    _h2, _n2 = calc_same_odds_signal(_hist_recs, "hhad", d, goal=None)
                    if _n2 > so_n:
                        so_hit, so_n, _scope = _h2, _n2, "同方向跨盘口"
                if so_hit is not None:
                    if so_hit >= 60 and so_n >= 10:
                        tech_count += 1
                    same_odds_hit, same_odds_n = so_hit, so_n
                else:
                    same_odds_hit, same_odds_n = None, so_n
                # ===== 五维雷达（让球盘：概率/规则/盘口价值/状态/市场）=====
                fd_prob = min(20, d_prob * 0.4)
                fd_rule = min(20, tech_count * 4)
                fd_odds = min(20, max(0, conf - 55) * 0.7)
                fd_form = min(20, form_score * 1.33)
                fd_mkt = min(20, prob_align * 1.3)
                five_dim = round(five_dimension_rating(fd_prob, fd_rule, fd_odds, fd_form, fd_mkt), 1)
                match_options.append({
                    "play": f"让球{goal}", "playKey": "hhad", "dir": d, "label": label,
                    "odds": odds, "confidence": round(conf, 1),
                    "score": round(conf * odds, 1), "reasons": reasons,
                    "techCount": tech_count,
                    "sameOddsHit": same_odds_hit, "sameOddsN": same_odds_n,
                    "sameOddsScope": _scope, "fiveDim": five_dim
                })

        # ========== 选项3：总进球（辅助玩法，最多1场） ==========
        if ttg and goals_exp:
            import math
            lam = float(goals_exp)
            ah = attack.get("home") or {}
            aa = attack.get("away") or {}
            stability = min(1.0, ((ah.get("n", 0) or 0) + (aa.get("n", 0) or 0)) / 20.0)
            for k in range(8):
                odds = ttg.get(str(k))
                if not odds or odds < 1.8 or odds > 3.5:
                    continue
                base_prob = math.exp(-lam) * (lam ** k) / math.factorial(k) * 100
                if base_prob < 20:
                    continue
                reasons = [f"预期{goals_exp}球", f"概率{base_prob:.0f}%"]
                tech_count = 0
                if abs(k - lam) < 1.0:
                    tech_count += 2
                    reasons.append("最可能区间")
                if stability > 0.7:
                    tech_count += 1
                    reasons.append("数据充足")
                conf = 55 + base_prob * 0.6 * stability + tech_count * 2
                conf = min(85, max(58, conf))
                if tech_count >= 2 and conf >= 70:
                    label = f"{k}球" if k < 7 else "7+球"
                    # ===== 历史同指（总进球代理：同预期进球区间→实际总进球命中）=====
                    so_hit, so_n = None, 0
                    _gh = 0
                    for r in _hist_recs:
                        res = r.get("result")
                        ge = r.get("goalsExp") or 0
                        if not isinstance(res, dict) or res.get("home") is None or res.get("cancel"):
                            continue
                        if abs(ge - k) < 0.6:
                            so_n += 1
                            if (res.get("home", 0) + res.get("away", 0)) == k:
                                _gh += 1
                    if so_n >= 5:
                        so_hit = round(_gh / so_n * 100, 1)
                        if so_hit >= 55 and so_n >= 10:
                            tech_count += 1
                    # ===== 五维雷达（总进球：概率/规则/赔率价值/状态/市场）=====
                    fd_prob = min(20, base_prob * 0.35)
                    fd_rule = min(20, tech_count * 4)
                    fd_odds = min(20, max(0, conf - 55) * 0.7)
                    fd_form = min(20, stability * 20)
                    fd_mkt = min(20, abs(k - lam) < 1.0 and 20 or 8)
                    five_dim = round(five_dimension_rating(fd_prob, fd_rule, fd_odds, fd_form, fd_mkt), 1)
                    match_options.append({
                        "play": "总进球", "playKey": "ttg", "dir": str(k), "label": label,
                        "odds": odds, "confidence": round(conf, 1),
                        "score": round(conf * odds, 1), "reasons": reasons,
                        "techCount": tech_count,
                        "sameOddsHit": so_hit, "sameOddsN": so_n,
                        "fiveDim": five_dim
                    })

        # ===== 单场单意见（v1.7.24）：每场只保留唯一「系统意见」选项 =====
        # 历史教训（用户实测反馈）：此前每场保留最多3个选项、各档位在组合时自行挑选，
        # 导致同一场比赛在稳健档选「客胜@2.2」、均衡档选「让球+1让胜@1.51」——
        # 同一场两套说法，用户视角自相矛盾（"一会客胜一会让胜，简直就是乱来"）。
        # 现改为：每场先用统一评分选出唯一意见（v1.7.43 起信心度主导：同指命中率
        # 仅在 ≥65 分段加分、45-60 反向区间扣分，叠加 EV/技术/五维微调），
        # 三档只在这个「意见池」里做组合——同一场比赛全天一个说法，
        # 档位差异只体现在「选不选它、拼几场」，不再有同场不同玩法。
        # 若某档因意见池收窄而凑不出达标组合，该档留空（前端如实展示），不靠改说法硬凑。
        if match_options:
            # v1.7.43：评分逻辑提取为模块级 parlay_canon_score（见上），此处直接调用
            if _lean:
                # v1.7.120 精简数据源（500.com 备用源）：官方支持率/盘口异动/规则星级
                # 全缺，confidence 被压平到下限 55，canon 评分里 score=conf×odds 变成
                # 纯由赔率主导 → 系统意见几乎全选「平局@3.x」（最难预测的方向）。
                # 改用「市场共识隐含概率 + 历史同指实证命中率」选唯一意见：
                # 低赔正路优先、平局重罚，杜绝把冷门平局塞进串关。
                # v1.7.121：改按「后验命中率」选边，不再按赔率绝对值。
                # 低赔若历史上实证命中率差于市场定价（edge<0），post 会被拉低，
                # 从而输给「赔率略高但实证有超额」的选项 —— 破除低赔无脑选。
                def _lean_pick(o):
                    _p, _e, _n, _so = _posterior(o)
                    if o.get("dir") == "d":
                        _p -= 0.08          # 平局天然难测，实证命中率显著低
                    return _p
                _pick = _lean_pick
            else:
                _pick = parlay_canon_score
            # v1.7.132 资格前移：只在该场「已满足全部硬标准」的选项里选唯一意见。
            # 门槛不降、每场仍只有唯一意见（不会自相矛盾），但不再因为先挑了
            # 1.1x 蚊子肉而把同场最合理的中赔选项提前丢掉。若该场没有任何
            # 合格选项，才退回全池取最把握的一条，仅用于页面逐条展示排除原因。
            _ok = [o for o in match_options if _opt_qualified(o)]
            if os.environ.get("JC_PARLAY_DEBUG"):
                print("    [%s %s vs %s] 选项 %d 条：" %
                      (m.get("num"), m.get("home"), m.get("away"), len(match_options)), flush=True)
                for _o in match_options:
                    _pp2, _ee2, _nn2, _so2 = _posterior(_o)
                    _q2 = (_MIN_LEG_ODDS <= (_o.get("odds") or 0) <= _MAX_LEG_ODDS
                           and _o.get("dir") != "d" and _ee2 * 100 >= _EDGE_MIN
                           and _nn2 >= _MIN_EMP_N)
                    print("      %-6s %-4s @%-5s edge=%+6.1fpt n=%-4s %s" %
                          (_o.get("play"), _o.get("label"), _o.get("odds"),
                           _ee2 * 100, _nn2, "合格" if _q2 else "排除"), flush=True)
            opt = max((_ok or match_options), key=_pick)
            canon = _pick(opt)
            if _ok:
                _qual_picked[0] += 1
            _pp, _pe, _pn, _pso = _posterior(opt)
            candidates.append({
                "num": m.get("num"), "league": m.get("league"),
                "home": m.get("home"), "away": m.get("away"),
                "kickoff": kickoff, "play": opt["play"], "playKey": opt["playKey"],
                "dir": opt["dir"], "label": opt["label"],
                "odds": opt["odds"], "confidence": opt["confidence"],
                "stableIndex": stable_index,
                "score": opt["score"], "reasons": opt["reasons"],
                "techCount": opt.get("techCount", 0),
                "pTrue": opt.get("pTrue"),
                "sameOddsHit": opt.get("sameOddsHit"),
                "sameOddsN": opt.get("sameOddsN"),
                "sameOddsScope": opt.get("sameOddsScope") or "同赔同方向",
                "fiveDim": opt.get("fiveDim"),
                # v1.7.121 选边证据：后验命中率 / 实证超额 / 原始实证样本。
                # 页面逐腿展示，负超额标红；用户可直接核对「这条腿凭什么被选」。
                "postProb": round(_pp * 100, 1),
                "edge": round(_pe * 100, 1),
                "empHit": _pso,
                "empN": _pn,
                # v1.7.43：选腿时的 canon 评分快照，供赛后回溯「为什么选这条腿」
                "canon": round(canon, 3),
            })

    # ===== v1.7.121 精简数据源：信心度由「后验命中率」重标定 =====
    # v1.7.120 曾把 confidence = 55 + (0.886/赔率 − 0.30)×70，本质仍是赔率的
    # 单调变换（用赔率证明赔率），实测信心标 66~79 而同方向实证只有 47~57、
    # 系统性虚高约 20pt。现改用贝叶斯后验命中率 post 驱动：低赔但实证差于
    # 市场定价的腿会被拉低，赔率略高但实证有超额的腿反而更靠前。
    # 档位门槛仍按当日候选池分位数自适应，保证任何数据源下都从「相对最有
    # 证据支持」的场次里出组合，既不硬凑也不空档。
    # v1.7.122：档位信心门槛彻底废除。旧实现按档位分位数一路放宽
    # （_q(0.70) → _q(0.90) → 全池最低分），等于「腿数越多、单场质量要求越低」，
    # 与用户「先选出最有把握的单场、才进行组合」的原则正好相反。实测真实 EV
    # 从稳健 -3.1% 恶化到均衡 -12.0%、精锐 -38.9%，且均衡档的腿不在精锐档里。
    # 现统一由下方「合格单场」绝对标准把关，档位不再各自设门槛、各自凑组合。
    _tier_conf = [0.0, 0.0, 0.0]
    if _lean and candidates:
        for c in candidates:
            _p, _e, _n, _so = _posterior(c)
            if c.get("dir") == "d":
                _p -= 0.05
            c["confidence"] = round(min(86.0, max(52.0, 40 + _p * 55)), 1)
        print("  分层串关：精简数据源，信心度已按后验命中率重标定", flush=True)

    # ===== v1.7.121 通用证据修正（所有数据源，含官方完整源）=====
    # 精简源分支的 confidence 已由后验命中率 post 驱动（post 内含实证超额），
    # 不重复扣分；官方完整源走 parlay_canon_score，其 confidence 来自规则星级/
    # 支持率等技术信号，与「历史实证是否跑赢定价」无关 —— 实测这类信心会标到
    # 79 分、而同方向实证只有 47.3%（比市场定价低 8pt）。这里按负超额扣分，
    # 让「历史数据不支持」真正影响选边排序与档位门槛，而不是只贴个标签。
    if not _lean:
        for c in candidates:
            _e = c.get("edge") or 0
            if _e < -1.0:
                c["confidence"] = round(max(40.0, c["confidence"] + _e * 1.2), 1)

    candidates.sort(key=lambda x: x["confidence"], reverse=True)

    # ===== v1.7.122 核心：先选合格单场，才进行串关组合 =====
    # 用户原则：「选串关是把单场最有把握，数据支撑，合理，才进行串关组合」。
    # 旧实现先定 2/3/4 腿的档位、再各自 combinations() 凑组合，且档位越高
    # 门槛越松（精锐直接取全池最低信心），实测真实 EV 稳健 -3.1% → 均衡
    # -12.0% → 精锐 -38.9%，均衡档的腿甚至不在精锐档里。现改为四步：
    #   ① 单场层面用统一「绝对标准」筛合格单场，不因档位变化：
    #      数据支撑 = 历史同方向实证超额 ≥0 且样本 ≥20 场（不编造优势）；
    #      合理     = 赔率 1.60~上限、非平局（平局天然难测）；
    #      最有把握 = 按后验命中率降序（已含市场先验 + 历史实证贝叶斯收缩，
    #                 不是赔率的单调变换，杜绝「低赔无脑选」）。
    #   ② 排成唯一序列 qualified，每场记 gripRank = 今日第 N 有把握。
    #   ③ 串关 = 该序列前缀：稳健=前2、均衡=前3、精锐=前4。天然严格嵌套、
    #      总赔天然单调递增（每条赔率 >1），不再需要独立凑组合与动态地板。
    #   ④ 合格单场不足 N 条，第 N 档如实留空并写明原因，绝不降门槛/换腿硬凑。
    # v1.7.132：_EDGE_MIN / _MIN_EMP_N / _MIN_LEG_ODDS / _MAX_LEG_ODDS 已提前到
    # 函数开头定义（选唯一意见阶段就要用同一套标准），此处不再重复定义。
    def _qualified(c):
        if (c.get("edge") or 0) < _EDGE_MIN:
            return False                      # 历史实证跑不赢市场定价 = 无数据支撑
        if (c.get("empN") or 0) < _MIN_EMP_N:
            return False                      # 样本不足 = 证据不足，不假装有利
        _o = c.get("odds") or 0
        if not (_MIN_LEG_ODDS <= _o <= _MAX_LEG_ODDS):
            return False                      # 蚊子肉 / 高赔冷门，都不「合理」
        if c.get("dir") == "d":
            return False                      # 平局天然难测
        return True

    qualified = sorted((c for c in candidates if _qualified(c)),
                       key=lambda c: -(c.get("postProb") or 0))
    for _i, _c in enumerate(qualified, 1):
        _c["gripRank"] = _i                  # 今日第 N 有把握的合格单场
    print("  分层串关：资格前移命中 %d 场 | 合格单场 %d/%d 条（按后验把握度排序）%s" % (
        _qual_picked[0], len(qualified), len(candidates),
        ("，首位 %s %s @%s 后验%s%%" % (qualified[0]["num"], qualified[0]["label"],
                                       qualified[0]["odds"], qualified[0].get("postProb")))
        if qualified else "，今日无合格单场"), flush=True)
    print("  分层串关：选项资格分布 %s" % _opt_stat, flush=True)

    # ===== 串关档位：拒绝蚊子肉，按风险分三档，每档在自身赔率区间内选最优组合 =====
    # (key, 档位, 场数, 单场下限, 总赔下限, 总赔上限, 单腿信心下限, 联合概率下限, EV下限, 模式, 说明, 单腿赔率上限, 同指硬门槛)
    # 2026-10-20 改革（v1.7.25）：赔率单调承诺——三档按 稳健→均衡→精锐 顺序构建，
    # 每档总赔必须高于上一档实际总赔（动态地板），杜绝「精锐4串1(6.03) 反而低于
    # 均衡3串1(6.27)」的档位倒挂（根因：三档独立构建 + 精锐 hit 模式偏爱便宜腿，
    # 4 条便宜腿乘积极可能低于 3 条中价腿，档位语义被破坏）。
    # 均衡档同步调整：静态总赔下限 4.50→4.00（让位给动态地板，避免带重叠）、
    # 单腿信心下限 55→60（拒绝为填赔率带塞入信心仅 55 的弱腿）。
    # v1.7.33 改革：EV 下限（min_ev）改为「地面真实口径」（同指命中率×总赔−1）。
    # v1.7.43 回调（2026-10-26 命中率归因）：选腿信号全面回调——信心主导。
    #   归因实证（parlay_history 72 组回溯 + 二项检验）：
    #   · 同指命中率 45-60% 区间的腿实际命中 17%（4/24），市场共识期望 49%，
    #     z=-3.15 p<0.001——同指率在该区间虚高且反向，v1.7.25/33 把它当
    #     「地面真相」是 10-20 后 11 组全败、腿级 55.9%→36.6% 的直接原因；
    #   · 同指 ≥65% 区间实际 67-82%（可信）；confidence≥75 实际 94%（17/18）。
    #   回调：_canon_score 信心主导（同指仅高分段加成、中分段惩罚）；
    #   同指硬门槛 45→60（精锐 65），4 串零容忍软腿；combo_hit/real_ev 只在
    #   同指 ≥65 时采信地面值，45-60 区间回退市场+alpha 口径。
    # v1.7.118（用户反馈「每天没有推荐，如同摆设」）：此前同指命中率硬门槛 60/65
    # 把 9 场候选一刀切到只剩 3 场，且这 3 场全是 1.28-1.51 的蚊子肉；
    # 均衡/精锐的总赔下限 3.4/4.4 又高于这 3 场能凑出的上限 → 两档永远为空。
    # 归因实证（代码内既有结论）：同指命中率 45-60% 区间实际命中仅 17%（反向虚高），
    # 而 confidence≥75 实际 94%（17/18）——「最有把握」应由信心度+技术信号主导，
    # 同指率只做软惩罚。同时把单腿赔率下限抬到 1.45，杜绝 1.2x 蚊子肉。
    TIERS = [
        # v1.7.120：单腿下限 1.45→1.60。用户明确反对「1.2-1.5 的低赔蚊子肉」，
        # 而 hit 模式评分由联合命中率主导，天然偏向最低赔腿 —— 1.45 下限会让
        # 三档全挤在 1.47~1.64。抬到 1.60 后单腿落在 1.6~2.33，是有把握又不
        # 蚊子肉的区间；1.70 实测会把稳健/均衡两档挤空（见实验），故取 1.60。
        # v1.7.122：档位不再「定腿数凑组合」，而是合格单场序列的前缀。
        # 总赔下限置 0（前缀随腿数天然递增，动态地板足以保证单调）；
        # 总赔上限/联合概率下限按腿数放宽到「前缀模式的自然量级」，
        # 避免沿用凑组合时代的窄区间把合理的第 3/4 名误判成不达标。
        ("parlay2", "稳健", (2,), 1.60, 0.0, 6.00, 0.0, 0.20, -0.08, "hit",
         "2串1 · 稳胆哲学：由今日第 1~2 有把握的合格单场组成（历史实证跑赢定价、样本≥20场、赔率≥1.60 拒绝蚊子肉）", 3.2, 50),
        ("parlay3", "均衡", (3,), 1.60, 0.0, 12.0, 0.0, 0.08, -0.15, "ev",
         "3串1 · 递进哲学：稳健 2 场 + 今日第 3 有把握的合格单场，严格包含稳健档全部腿", 3.2, 50),
        ("parlay4", "精锐", (4,), 1.60, 0.0, 24.0, 0.0, 0.03, -0.08, "hit",
         "4串1 · 递进哲学：均衡 3 场 + 今日第 4 有把握的合格单场，严格包含均衡档全部腿；联合命中率天然更低，理性看待", 3.2, 55),
    ]
    if _lean:
        # v1.7.120 精简数据源档位重标定：官方接口不通时 500.com 备用源只给
        # 胜平负/让球赔率，可用正路腿集中在 1.77-3.15，最小 3 串乘积已达 8.6、
        # 最小 4 串约 20，而旧档位总赔上限写死 8 / 12、联合概率下限 0.10 / 0.06
        # 是按官方低赔腿调的 → 3串1/4串1 组合被整批挡光，页面天天「无达标组合」。
        # 现按腿数放宽总赔上限与联合概率下限（后者是市场去水概率连乘的自然量级），
        # 单腿赔率上限收到 2.80 挡掉 3.x 冷门平局，三档统一「命中率优先」模式，
        # 保证从最有把握的场次里挑 2/3/4 场，而不是为凑赔率去搏冷门。
        # (key, 档位, 场数, 单腿下限, 总赔下限, 总赔上限, 信心下限, 联合下限, EV下限, 模式, 说明, 单腿上限, 同指软门槛)
        _lean_bounds = [
            (6.00, 0.10, "hit", 2.80),
            (12.0, 0.04, "hit", 2.80),
            (24.0, 0.02, "hit", 2.80),
        ]
        TIERS = [t[:5] + (bd[0],) + t[6:7] + (bd[1],) + t[8:9] + (bd[2],) + t[10:11] + (bd[3],) + t[12:]
                 for t, bd in zip(TIERS, _lean_bounds)]
    # 竞彩单场返奖率：对当日全部场次实测 1/(1/h+1/d+1/a) ≈ 88.6%，即单场抽水约 11.4%。
    # （此前按 70% 估算是错的，会把串关抽水夸大一倍）
    PAYBACK = 0.886

    # alpha 置信度折扣：各细分样本只有 7~71 场、95% 置信区间全部跨越 0，
    # 直接采信 alpha 会高估。按 0.6 折收缩，偏向市场共识（保守）。
    ALPHA_SHRINK = 0.6

    def _leg_prob(c):
        """单个腿的真实概率估计（0-1）"""
        o = c.get("odds") or 0
        p_market = (PAYBACK / o) if o > 1 else 0.0   # 市场共识概率（去抽水）
        pt = c.get("pTrue")
        if pt:
            # 胜平负：p_cal = 市场共识 + alpha，对 alpha 部分打折后使用
            p = p_market + (pt / 100.0 - p_market) * ALPHA_SHRINK
            return min(max(p, 0.01), 0.95)
        # 让球/总进球没有校准概率时直接用市场共识。
        # 不能拿 confidence 当概率用——confidence 是信心指标且被截断在 55 分以上，
        # 会把 60% 的事件估算成 85%，导致 EV 严重虚高。
        if p_market > 0:
            return min(max(p_market, 0.01), 0.95)
        return min(max((c.get("confidence") or 0) / 100.0, 0.01), 0.95)

    # ---- v1.7.118：按信心分桶的「腿级实证命中率」，收缩到市场口径 ----
    # parlay_history 217 条已判定腿的实测：信心≥75 → 80.0%（市场 58.0%，+22pt），
    # 70-75 → 52.5%（≈市场），65-70 → 42.1%（低于市场），<65 → 35.7%。
    # 此前 combo_hit 用市场去水概率连乘，抽水决定了它数学上恒为负 EV，
    # 于是 100% 的日子三档都标「不建议下注」——功能等同摆设。
    # 改为「每腿自身市场/校准概率 + 该信心桶的实证优势×0.5 收缩」：
    # 保留逐场赔率差异，又用实测选边优势修正，小样本桶(n<10)不采信。
    _emp_buckets = [(75, 200), (70, 75), (65, 70), (60, 65), (0, 60)]
    _emp_stats = {i: [0, 0, []] for i in range(len(_emp_buckets))}
    try:
        with open(os.path.join(HERE, "parlay_history.json"), encoding="utf-8") as _f:
            _ph = json.load(_f)
        for _r in (_ph.get("records") or []):
            for _lg in (_r.get("legs") or []):
                _hit = _lg.get("legHit")
                _o = _lg.get("odds") or 0
                if _hit is None or _o <= 1:
                    continue
                _c = _lg.get("confidence") or 0
                for _i, (_lo, _hi) in enumerate(_emp_buckets):
                    if _lo <= _c < _hi:
                        _emp_stats[_i][0] += 1
                        _emp_stats[_i][1] += 1 if _hit else 0
                        _emp_stats[_i][2].append(PAYBACK / _o)
                        break
    except Exception as _e:
        print("  [warn] 腿级实证命中率读取失败: %s" % _e, flush=True)
    _emp_delta = {}
    for _i, (_n, _h, _mkts) in _emp_stats.items():
        if _n < 10 or not _mkts:
            _emp_delta[_i] = 0.0
        else:
            _emp_delta[_i] = round(((_h / _n) - (sum(_mkts) / len(_mkts))) * 0.5, 4)

    def _emp_prob(c):
        if _lean:
            # v1.7.120 精简数据源：上面的信心度已按市场概率重标定，与历史腿的
            # 信心口径不一致，再叠加实证分桶 delta 会系统性高估命中率（实测能把
            # 4串1 抬成「实证+49%、EV+49%」的虚高假象）。此处直接退回市场去水
            # 概率，保证联合命中率与 EV 诚实无偏：竞彩抽水决定恒为负期望，
            # 页面如实标「观望」，但推荐组合照常给出、绝不用假正期望诱导下注。
            return _leg_prob(c)
        _c = c.get("confidence") or 0
        _di = len(_emp_buckets) - 1
        for _i, (_lo, _hi) in enumerate(_emp_buckets):
            if _lo <= _c < _hi:
                _di = _i
                break
        return min(0.95, max(0.05, _leg_prob(c) + _emp_delta.get(_di, 0.0)))

    def build_tier(tier, floor_total=0.0):
        key, name, ns, min_odds, min_total, max_total, min_conf, min_joint, min_ev, mode, desc, max_leg, so_floor = tier
        # v1.7.25 赔率单调：本档总赔不得低于上一档实际总赔（+0.01 保证严格大于）。
        # 倒挂根因：三档独立构建时，精锐档 hit 模式天然偏爱便宜腿（赔率低=市场共识
        # 概率高=同指命中率高），4 条便宜腿乘积极可能低于 3 条中价腿（6.03 vs 6.27），
        # 用户视角「4 串比 3 串赔得少」= 档位语义崩坏。顺序构建+动态地板修复。
        eff_min_total = max(min_total, floor_total + 0.01)
        best_pass = None      # 通过 EV 护栏的达标组合（优先返回）
        best_pass_score = None
        best_fb = None        # 兜底组合：EV 未达标时取最接近的，仅在没有达标组合时返回
        best_fb_score = None
        for n in ns:
            if len(qualified) < n:
                continue
            max_hhad = 3 if n >= 4 else (2 if n >= 3 else 1)
            if os.environ.get("JC_PARLAY_DEBUG"):
                _cb = tuple(qualified[:n])
                _to = _jp = _ch = 1.0
                for _c in _cb:
                    _to *= _c["odds"]
                    _jp *= _leg_prob(_c)
                    _q = _c.get("postProb")
                    _ch *= (_q / 100.0) if _q else _leg_prob(_c)
                print("      [档 %s n=%d] %s | 总赔%.3f 联合%.3f 后验连乘%.3f realEV%+.1f%% | 门槛 总赔[%.2f,%.2f] 联合>=%.2f minEv=%.2f minOdds=%.2f maxLeg=%.2f maxHhad=%d conf>=%.1f" % (
                    name, n, "/".join("%s@%s" % (c["num"], c["odds"]) for c in _cb),
                    _to, _jp, _ch, (_ch * _to - 1) * 100, eff_min_total, max_total,
                    min_joint, min_ev, min_odds, max_leg, max_hhad, min_conf), flush=True)
                print("        逐腿: %s" % " | ".join(
                    "%s conf=%s edge=%s play=%s" % (c["num"], c.get("confidence"),
                                                    c.get("edge"), c.get("playKey"))
                    for c in _cb), flush=True)
            # v1.7.122：唯一候选组合 = 合格单场按把握度排序后的前 n 名前缀。
            # 不再遍历 combinations()：档位是优质单场的自然叠加，而非定腿数凑组合。
            for combo in (tuple(qualified[:n]),):
                # v1.7.121 证据准入：一条腿若连历史同方向实证都跑不赢市场定价
                # （edge < −1pt），就没有资格被拼进任何一档。宁可该档留空，
                # 也不把「便宜但历史上更不准」的腿包装成串关推荐。
                if _STRICT_EDGE and any((c.get("edge") or 0) < -1.0 for c in combo):
                    continue
                nums = [c["num"] for c in combo]
                if len(set(nums)) < n:
                    continue
                if sum(1 for c in combo if c["playKey"] == "hhad") > max_hhad:
                    continue
                if sum(1 for c in combo if c["playKey"] == "ttg") > 1:
                    continue
                # 拒绝蚊子肉：单场赔率必须达到档位下限
                if any(c["odds"] < min_odds for c in combo):
                    continue
                # 单腿赔率上限：精锐档 ≤3.2——高赔腿市场共识概率低、同指命中差，
                # 「纯挑高倍」正是搏击档 23 战 0 胜的根因，从选腿环节杜绝
                if any(c["odds"] > max_leg for c in combo):
                    continue
                # v1.7.118：同指命中率不再一刀切剔除。实证 45-60% 区间虚高反向，
                # 但「低于门槛」≠「没把握」；硬剔除会把 9 场候选砍到只剩 3 场低赔，
                # 均衡/精锐永远凑不齐 → 页面长期「今日无达标组合」，等同于摆设。
                # 改为在组合评分里软惩罚（so_penalty + _soft_legs 扣分）。
                _soft_legs = sum(1 for c in combo
                                 if c.get("sameOddsHit") is not None
                                 and (c.get("sameOddsN") or 0) >= 10
                                 and c.get("sameOddsHit") < so_floor)
                # 档位信心门槛（单腿）
                if any((c.get("confidence") or 0) < min_conf for c in combo):
                    continue
                total_odds = 1.0
                joint_p = 1.0
                for c in combo:
                    total_odds *= c["odds"]
                    joint_p *= _leg_prob(c)
                if total_odds < eff_min_total or total_odds > max_total:
                    continue
                # v1.7.132：移除「市场去水概率连乘 joint_p」的硬门槛。
                # 下方注释已明确：模型口径（joint_p / ev）系统性偏保守，
                # 「不能再当推荐标准」，推荐判定统一用后验连乘 combo_hit。
                # 但旧代码仍拿 joint_p < min_joint 一刀切，形成双标：实测稳健
                # joint 0.164 < 0.20 被拒，而同源后验 0.238、realEV +7.9%
                # 完全达标 —— 这是分层串关天天 0 档的最后一环。
                # 同源门槛移到下方 combo_hit 算完后判定。
                # 组合真实历史命中率（地面真实优先，样本不足回退去水概率）
                # v1.7.43：同指命中率只在 ≥65 分段采信（实证 67-82% 可信）；
                # 45-60 分段实证反向（17%），一律回退市场+alpha 口径（_leg_prob），
                # 不再让虚高的同指率抬高 combo_hit / real_ev / 推荐判定。
                # v1.7.118：改用「按信心分桶的腿级实证命中率（收缩到市场口径）」，
                # 而非市场去水概率连乘——后者抽水决定恒负 EV，会让所有推荐
                # 永远挂「不建议下注」。实测高信心腿(≥75)命中 80% vs 市场 58%。
                # v1.7.122：命中率估计与选边依据统一到「后验命中率」。
                # 旧口径按 confidence 分桶加实证 delta，与新版按 postProb 排序
                # 选腿不是同一套把握度，且历史分桶加成会把负期望粉饰成接近
                # 平衡（旧稳健 -3.1% 靠约 +6pt 加成，而其中一条腿超额为负）。
                # 现在「用什么标准选腿，就用什么概率算 EV」，逐条可核对、不双标；
                # 后验概率已含市场共识先验 + 历史实证贝叶斯收缩，不虚高。
                combo_hit = 1.0
                for c in combo:
                    _pp = c.get("postProb")
                    combo_hit *= (_pp / 100.0) if _pp else _leg_prob(c)
                # ===== 双口径 EV（v1.7.33 推荐标准改革）=====
                # ev      = 模型口径（pTrue 校准概率 + alpha 0.6 收缩）。该口径系统性偏保守：
                #          历史实证选出的腿明显优于「同赔率桶」均值（稳健2串1 实测 14 战 9 中、
                #          均衡3串1 18 战 5 中，两档实际盈利），而模型口径几乎每天都判负 EV，
                #          导致 86% 的日子全部档位挂「不推荐」——功能等于废掉，不能再当推荐标准。
                # real_ev = 地面真实口径（同指命中率 × 总赔 − 1，竞彩官方赛果库实测）。
                #          推荐判定、档位达标线、排序、凯利仓位全部改用 real_ev；
                #          模型口径 ev 仅作参考展示（页面标注「模型期望·参考」）。
                ev = joint_p * total_odds - 1.0
                real_ev = combo_hit * total_odds - 1.0
                # v1.7.132：联合概率下限改按「后验连乘」同源口径判定，
                # 与选腿依据 / real_ev / 推荐资格完全一致，不再双标。
                if combo_hit < min_joint:
                    continue
                # 达标线按地面真实口径卡：负期望日不再整层消失，兜底取真实期望最高的组合
                if real_ev < min_ev:
                    # 兜底记录：取该档真实期望最高（最接近达标）的组合，避免整层不显示。
                    # 注意：兜底与达标分开计分——达标组合永远优先返回，
                    # 杜绝「高同指但深度负期望」的组合挤掉达标组合（旧实现两者同池竞争的缺陷）。
                    fb_score = combo_hit * 100 + 0.01 * real_ev
                    if best_fb is None or fb_score > best_fb_score:
                        best_fb_score = fb_score
                        best_fb = (list(combo), total_odds, joint_p, ev, real_ev, n, combo_hit)
                    continue
                tech_sum = sum(c.get("techCount", 0) for c in combo)
                stable_sum = sum(c.get("stableIndex", 0) for c in combo)
                five_dim_sum = sum(c.get("fiveDim") or 0 for c in combo)
                # 同指陷阱惩罚（v1.7.43：阈值随档位 so_floor，默认 60）：
                # 某腿同指命中率低于门槛且样本充足 → 该组合减分（已被硬门槛剔除，
                # 这里对 n<10 无样本腿不做惩罚，仅保留原 45% 深罚逻辑）
                so_penalty = 0.0
                for c in combo:
                    so = c.get("sameOddsHit")
                    if so is not None and c.get("sameOddsN", 0) >= 10 and so < so_floor:
                        so_penalty += 0.0006 * (so_floor - so)
                # 组合真实历史命中率已在前述门槛前计算（combo_hit），此处直接用于排序。
                # 选择哲学分支（v1.7.33：排序分同步改用真实期望口径）：
                avg_conf = sum((c.get("confidence") or 0) for c in combo) / n
                # v1.7.118：组合评分加入「平均信心度」主导项，真正实现
                # 「十场里挑最有把握的 3-4 场」；同指偏低的腿按条数软扣分，
                # 不再直接剔除（保留质量区分，而不是把候选池砍空）。
                if mode == "hit":
                    # 稳胆哲学：信心度 + 真实历史命中率共同主导，护栏由 min_ev 保证
                    score = (combo_hit * 100 + 0.40 * avg_conf + 0.01 * real_ev
                             - so_penalty - 0.5 * _soft_legs)
                else:
                    # 价值哲学：真实期望主导，技术/稳胆/五维/信心做细分
                    score = (real_ev + 0.0015 * tech_sum + 0.0003 * stable_sum
                             + 0.0004 * five_dim_sum + 0.004 * avg_conf
                             - so_penalty - 0.02 * _soft_legs)
                if best_pass is None or score > best_pass_score:
                    best_pass_score = score
                    best_pass = (list(combo), total_odds, joint_p, ev, real_ev, n, combo_hit)
        best = best_pass if best_pass is not None else best_fb
        if not best:
            return None
        selected, total_odds, joint_p, ev, real_ev, n, real_hit = best
        avg_conf = sum(s["confidence"] for s in selected) / len(selected)
        play_types = list(set(s["play"] for s in selected))
        # 凯利仓位（v1.7.33 起按真实期望口径计算，模型口径恒负会导致仓位永远为 0）
        kelly = real_ev / (total_odds - 1.0) if total_odds > 1 else 0.0
        stake = min(max(kelly * 0.25 * 100, 0.0), 10.0)
        rake = (1.0 - PAYBACK ** n) * 100
        be_hit = 100.0 / total_odds          # 盈亏平衡命中率（需命中多高才不亏）
        if real_ev >= 0.10:
            ev_note = (f"正期望：历史同信心档实证命中率 {real_hit*100:.0f}%，高于盈亏平衡线"
                       f"（需 {be_hit:.0f}%），长期为正回报，值得下手")
        elif real_ev >= -0.02:
            ev_note = (f"达标：历史同信心档实证命中率 {real_hit*100:.0f}%，贴近盈亏平衡线"
                       f"（需 {be_hit:.0f}%），可小注参与")
        elif real_ev >= -0.10:
            ev_note = (f"轻度负期望：历史同信心档实证命中率 {real_hit*100:.0f}%，低于平衡线"
                       f"（需 {be_hit:.0f}%），建议观望")
        else:
            ev_note = (f"明显负期望：历史同信心档实证命中率仅 {real_hit*100:.0f}%"
                       f"（需 {be_hit:.0f}%），不建议下注")
        # v1.7.121：逐腿证据核查。负超额 = 该腿历史实证命中率低于市场定价，
        # 历史数据不支持它比市场更靠谱；这类腿出现在组合里必须显式警示。
        _neg_edges = [s for s in selected if (s.get("edge") or 0) < -1.0]
        _weak = [s for s in selected if (s.get("empN") or 0) < 20]
        if _neg_edges:
            _worst = min(s["edge"] for s in _neg_edges)
            edge_note = (f"证据核查：{len(_neg_edges)}/{n} 条腿历史实证命中率低于市场定价"
                         f"（最差 {_worst:+.1f}pt），历史数据不支持这些选项比市场更靠谱，"
                         f"不得作为推荐跟随")
        elif _weak:
            edge_note = (f"证据核查：{len(_weak)}/{n} 条腿同方向历史样本不足 20 场，"
                         f"按市场定价估计、未认定有超额优势")
        else:
            edge_note = (f"证据核查：{n}/{n} 条腿历史实证命中率均不差于市场定价"
                         f"（最短样本 {min((s.get('empN') or 0) for s in selected)} 场）")
        return {
            "type": f"{n}串1", "tier": name, "tierDesc": desc,
            "legs": selected,
            "totalOdds": round(total_odds, 2),
            "oddsGate": round(eff_min_total, 2),
            "avgConfidence": round(avg_conf, 1),
            "minOdds": min(s["odds"] for s in selected),
            "maxOdds": max(s["odds"] for s in selected),
            "playTypes": play_types,
            "isMixed": len(play_types) > 1,
            "jointProb": round(joint_p * 100, 1),
            "realHit": round(real_hit * 100, 1) if real_hit is not None else None,
            "ev": round(ev * 100, 1),
            "realEv": round(real_ev * 100, 1),
            "beHit": round(be_hit, 1),
            "suggestStake": round(stake, 1),
            "rake": round(rake, 1),
            "evNote": ev_note,
            "negEdgeLegs": len(_neg_edges),
            "edgeNote": edge_note,
            # v1.7.121 推荐资格加硬门槛：真实 EV 达标，且没有任何负超额腿。
            # 只要有一条腿历史实证差于市场定价，整组一律标「观望」，绝不推荐。
            # 用户明确要求「不要乱推荐、不要看到低赔率就无脑的选」：宁可少推，
            # 也不把「便宜但历史上更不准」的腿包装成高质量推荐。
            "recommended": real_ev >= -0.02 and not _neg_edges,
        }

    # v1.7.25 顺序构建：稳健→均衡→精锐，每档总赔必须高于上一档实际总赔（动态地板）。
    # 若某档无达标组合（候选稀薄/门槛未过），该档留空不硬凑，且不抬高后续档的地板。
    built = {}
    prev_total = 0.0
    for t in TIERS:
        r = build_tier(t, floor_total=prev_total)
        built[t[0]] = r
        if r and r.get("totalOdds"):
            prev_total = max(prev_total, r["totalOdds"])
    parlay2 = built.get("parlay2")
    parlay3 = built.get("parlay3")
    parlay4 = built.get("parlay4")

    # v1.7.122：把「单场筛选过程」如实摊开，用户能看到每一档为什么出、为什么空。
    pool_notes = []
    _excl = {
        "负超额（实证跑不赢定价）": sum(1 for c in candidates if (c.get("edge") or 0) < _EDGE_MIN),
        "样本不足 %d 场" % _MIN_EMP_N: sum(1 for c in candidates if (c.get("empN") or 0) < _MIN_EMP_N),
        "蚊子肉/冷门赔率": sum(1 for c in candidates
                         if not (_MIN_LEG_ODDS <= (c.get("odds") or 0) <= _MAX_LEG_ODDS)),
        "平局（天然难测）": sum(1 for c in candidates if c.get("dir") == "d"),
    }
    pool_notes.append(
        f"单场资格：{len(candidates)} 条候选中 {len(qualified)} 条合格"
        f"（实证超额≥{_EDGE_MIN:g}pt、样本≥{_MIN_EMP_N}场、"
        f"赔率{_MIN_LEG_ODDS}~{_MAX_LEG_ODDS:g}、非平局），按后验命中率排序后取前缀成档")
    _excl_txt = "、".join(f"{k} {v} 条" for k, v in _excl.items() if v)
    if _excl_txt:
        pool_notes.append("排除明细（各类可重叠）：" + _excl_txt)
    tier_notes = []
    for t, r in zip(TIERS, [built.get(t[0]) for t in TIERS]):
        n = t[2][0]
        if r is None:
            if len(qualified) < n:
                _note = (f"{t[1]}{n}串1 留空：今日合格单场仅 {len(qualified)} 场，不足 {n} 场；"
                         f"按「先有最有把握的单场才组合」不降门槛、不硬凑")
            else:
                _note = (f"{t[1]}{n}串1 留空：前 {n} 名组合未过合理性复核"
                         f"（总赔/联合概率），不为凑档换腿")
            tier_notes.append(_note)
            pool_notes.append(_note)

    result = {
        "generatedAt": time.strftime("%Y-%m-%d %H:%M:%S"),
        "candidateCount": len(candidates),
        "qualifiedCount": len(qualified),
        "tierNotes": tier_notes,
        "candidatePool": [
            {
                "num": c["num"], "home": c["home"], "away": c["away"],
                "play": c["play"], "label": c["label"], "odds": c["odds"],
                "confidence": c.get("confidence"),
                "sameOddsHit": c.get("sameOddsHit"), "sameOddsN": c.get("sameOddsN"),
                "edge": c.get("edge"), "postProb": c.get("postProb"), "empN": c.get("empN"),
                # v1.7.122：页面可逐条核对「这条单场够不够格、排第几有把握、
                # 不合格是因为哪一条」。排除原因由后端给出，前端不猜测。
                "qualified": bool(_qualified(c)), "gripRank": c.get("gripRank"),
                "excludeReasons": ([] if _qualified(c) else (
                    (["实证未跑赢定价"] if (c.get("edge") or 0) < _EDGE_MIN else [])
                    + (["样本不足%d场" % _MIN_EMP_N] if (c.get("empN") or 0) < _MIN_EMP_N else [])
                    + (["蚊子肉/冷门赔率"] if not (_MIN_LEG_ODDS <= (c.get("odds") or 0) <= _MAX_LEG_ODDS) else [])
                    + (["平局"] if c.get("dir") == "d" else []))),
            } for c in sorted(candidates, key=lambda x: -(x.get("postProb") or 0))
        ],
        "poolNotes": pool_notes,
        "strategy": "v1.7.122 选串关原则：先有单场，才有组合。① 单场资格用统一绝对标准（不因档位变化）——数据支撑：历史同方向实证命中率经贝叶斯收缩后的超额 ≥0pt 且样本 ≥20 场（样本不足不编造优势）；合理：赔率 1.60~3.20（拒绝低赔蚊子肉与高赔冷门）、非平局；最有把握：按后验命中率降序，后验已含市场先验+历史实证，不是赔率的单调变换（杜绝「看到低赔就无脑选」）。② 串关 = 合格单场序列的前缀：稳健=前2、均衡=前3、精锐=前4，严格嵌套、总赔随腿数单调递增；不再定腿数凑组合、不再按档位放宽门槛。③ 合格单场不足 N 条，第 N 档如实留空并写明原因，绝不降门槛/换腿硬凑。④ 推荐资格仍为硬条件：真实 EV 达标且全组无负超额腿，否则一律标「观望」。诚实口径：竞彩单场抽水 11.4%、串关按腿数复合放大，长期是负和游戏——不承诺盈利，只承诺每条腿「为什么够格、排第几有把握」可逐条核对",
        "parlay2": parlay2,
        "parlay3": parlay3,
        "parlay4": parlay4,
        "legNote": "串关抽水按场数放大：单场抽水11.4%，2串1约21.6%、3串1约30.6%、4串1约38.5%——串得越多，抽水越狠"
    }

    def _fmt(p):
        if not p:
            return "N/A"
        return f"{p['totalOdds']}倍(实证命中{p.get('realHit') or p['jointProb']}% 真实EV{p['realEv']:+.1f}% 建议{p['suggestStake']}%)"

    print(f"  分层串关：候选{len(candidates)}个 | 稳健 {_fmt(parlay2)} | 均衡 {_fmt(parlay3)} | 精锐 {_fmt(parlay4)}", flush=True)
    return result


def gen_safe_parlay(matches):
    """按竞彩销售批次分组，逐批独立成档（v1.7.123）。

    用户要求「把日期规律好，别周五的和周六的串起来，我需要的是竞彩当天开出的
    赛程」。竞彩每个销售批次用编号前缀标识（周五001~周五014 / 周六001~），
    与 date 字段严格一一对应；同一批次内允许跨零点开球（周五场次可能周六凌晨
    开球，仍属周五批次），但不同批次的场次绝不能串进同一注组合。

    旧实现用「未来 36 小时滚动窗口」把周五/周六/周日混进同一候选池再全池取
    前缀，于是稳健 2 串 1 会变成「周六009 + 周五006」；36h 之外的批次还会被
    整体丢弃。现按批次分组、每组独立调用 _gen_parlay_one_batch，结构上不可能
    跨批次；每批都带自己的三档、候选池、合格单场与留空说明。

    顶层仍返回「主批次」的完整字段（parlay2/3/4、candidatePool、qualifiedCount、
    poolNotes、tierNotes、strategy 等），保证 save_parlay_history / load_locked_parlay /
    selftest / 前端空态兜底 / 历史结算等全部下游零改动兼容。主批次优先取「当天
    开出的赛程」（date == 北京今天）；当天批次三档全空时才退到档位最多的在售
    批次，避免整页空白，并在 batchNote 如实说明。

    新增字段：batches（各批次完整结果，按日期升序）、activeBatch、
    batchDate、batchLabel、isToday、batchNote。
    """
    import re as _re
    # v1.7.132：唯一「今天」口径改用权威北京时间。旧写法 time.strftime 在沙箱
    # 时钟漂移（实测慢 6.5h）时会把 11-13 周五批次判成 11-12 周四批次，
    # 周四场次凌晨已开赛却仍被当成未开赛塞进候选池 → 每天展示错批次。
    today = beijing_clock.today() if beijing_clock else time.strftime("%Y-%m-%d")
    now_ts = beijing_clock.timestamp() if beijing_clock else time.time()
    print("  分层串关：竞彩当天口径 %s（时间源 %s）" % (
        today, beijing_clock.source() if beijing_clock else "local-clock"), flush=True)

    def _batch_of(m):
        d = str(m.get("date") or "").strip()
        n = str(m.get("num") or "")
        mt = _re.match(r"^(周[一二三四五六日])", n)
        lab = mt.group(1) if mt else ""
        return (d or lab or "未标注"), d, lab

    def _kickoff_ts(m):
        k = m.get("kickoff") or ""
        try:
            if len(k) >= 10 and k[4] == '-':
                return time.mktime(time.strptime(k[:16], "%Y-%m-%d %H:%M"))
            return time.mktime(time.strptime(f"{m.get('date','')} {k}", "%Y-%m-%d %H:%M"))
        except Exception:
            return None

    groups = {}
    for m in (matches or []):
        key, d, lab = _batch_of(m)
        g = groups.setdefault(key, {"date": d, "label": lab, "matches": []})
        if lab and not g["label"]:
            g["label"] = lab
        if d and not g["date"]:
            g["date"] = d
        kt = _kickoff_ts(m)
        # 只把「尚未开赛」的场次放进该批次（已开赛场次不可再下单）
        if kt is None or kt > now_ts:
            g["matches"].append(m)

    batches = []
    for key, g in sorted(groups.items(), key=lambda kv: (kv[1]["date"] or "9999-99-99", kv[0])):
        if not g["matches"]:
            continue
        one = _gen_parlay_one_batch(g["matches"]) or {}
        bdate = g["date"] or key
        blabel = g["label"] or key
        one["batchKey"] = key
        one["batchDate"] = bdate
        one["batchLabel"] = blabel
        one["isToday"] = (g["date"] == today)
        one["matchCount"] = len(g["matches"])
        # 批次标识透传到每条腿与每个候选，前端/自检可逐条核对「同批次」
        for tk in ("parlay2", "parlay3", "parlay4"):
            p = one.get(tk)
            if not p:
                continue
            p["batchDate"] = bdate
            p["batchLabel"] = blabel
            for lg in (p.get("legs") or []):
                lg["batchDate"] = bdate
                lg["batchLabel"] = blabel
        for c in (one.get("candidatePool") or []):
            c["batchDate"] = bdate
            c["batchLabel"] = blabel
        one["tierCount"] = sum(1 for tk in ("parlay2", "parlay3", "parlay4") if one.get(tk))
        batches.append(one)

    if not batches:
        # 极端兜底：没有任何未开赛场次（数据源异常/深夜全部售罄）时，仍返回一个
        # 结构完整的空壳，交给页面既有空态兜底处理，绝不抛异常中断 daily。
        empty = _gen_parlay_one_batch([]) or {}
        empty.update({"batches": [], "activeBatch": None, "batchDate": today,
                      "batchLabel": "", "isToday": True, "matchCount": 0, "tierCount": 0,
                      "batchNote": "当前无在售未开赛的竞彩批次，暂无串关推荐"})
        return empty

    # v1.7.132 主批次排序修正：用户明确「我需要的是竞彩当天开出的赛程」。
    # 旧排序把「有推荐」放在「当天」之前，于是当天批次 0 档时会跳去展示别天
    # 有推荐的批次（甚至前一天的已开赛场次），与「按竞彩当天批次隔离」冲突。
    # 现改为：当天批次绝对优先 > 有推荐 > 档位数多 > 日期早。
    def _main_score(b):
        n = b.get("tierCount") or 0
        return (0 if b.get("isToday") else 1, 0 if n > 0 else 1, -n, b.get("batchDate") or "9999")
    main = sorted(batches, key=_main_score)[0]

    result = dict(main)                       # 顶层 = 主批次完整结果（向后兼容）
    result["batches"] = batches
    result["activeBatch"] = main["batchKey"]
    if (main.get("tierCount") or 0) == 0:
        _today_b = next((b for b in batches if b.get("isToday")), None)
        result["batchNote"] = (
            "竞彩当天批次（%s）当前合格单场不足、三档留空，页面默认展示有推荐的"
            "在售批次（%s %s）；可用上方批次切换查看各批次各自独立的组合。"
            % (today, main["batchLabel"], main["batchDate"]))
    elif not main["isToday"]:
        result["batchNote"] = (
            "竞彩当天批次（%s）已无在售未开赛场次或暂无达标组合，当前展示最近"
            "在售批次（%s %s）；各批次组合完全独立，绝不跨批次串关。"
            % (today, main["batchLabel"], main["batchDate"]))
    else:
        result["batchNote"] = (
            "本批次为竞彩当天开出的赛程（%s %s），组合内所有场次同批次；"
            "其它在售批次可用上方切换查看，各自独立成档。"
            % (main["batchLabel"], main["batchDate"]))

    result["strategy"] = (main.get("strategy") or "") + (
        " 【v1.7.123 批次隔离】按竞彩销售批次（编号前缀=赛程日期）分组，每批独立"
        "筛选合格单场并前缀成档，任一组合的腿必须同批次，绝不把周五与周六的"
        "场次串在一起；页面默认展示竞彩当天开出的赛程批次，可切换查看其它在售批次。")
    print("  分层串关：共 %d 个竞彩批次 [%s]；主批次 %s %s（%d 档）" % (
        len(batches),
        " / ".join("%s %s:%d档" % (b["batchLabel"], b["batchDate"], b["tierCount"]) for b in batches),
        main["batchLabel"], main["batchDate"], main["tierCount"]), flush=True)
    return result


def check_parlay_history():
    """回查串关历史战绩：从parlay_history.json读取历史推荐，从history.json获取赛果，计算命中。
    修复：从result.score获取比分（而非score字段），正确计算让球胜平负，结果写回文件。
    返回 {total, hit, miss, pending, hitRate, recentDays, records}"""
    import os
    parlay_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "parlay_history.json")
    history_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "history.json")

    if not os.path.exists(parlay_file):
        return {"total": 0, "hit": 0, "miss": 0, "pending": 0, "hitRate": 0, "records": []}

    try:
        parlay_data = json.load(open(parlay_file, encoding="utf-8"))
    except Exception:
        return {"total": 0, "hit": 0, "miss": 0, "pending": 0, "hitRate": 0, "records": []}

    try:
        history_data = json.load(open(history_file, encoding="utf-8"))
        history_records = history_data.get("records", [])
    except Exception:
        history_records = []

    # 建立(date,num)->赛果的映射（必须按日期匹配，避免今天未开赛的比赛匹配到上周同num的赛果）
    score_map = {}
    goal_map = {}
    for r in history_records:
        num = r.get("num")
        date = r.get("date", "")
        result = r.get("result") or {}
        score = result.get("score")
        if num and score and isinstance(score, str) and ":" in score:
            try:
                parts = score.split(":")
                hs, as_ = int(parts[0]), int(parts[1])
                key = f"{date}|{num}"
                score_map[key] = {"home": hs, "away": as_, "score": score}
                # 让球数：goal<0主队让球，>0主队受让
                goal_raw = r.get("goal", 0)
                try:
                    goal_map[key] = int(goal_raw) if goal_raw else 0
                except (ValueError, TypeError):
                    goal_map[key] = 0
            except Exception:
                pass

    records = parlay_data.get("records", [])
    total = hit = miss = pending = 0
    modified = False

    for rec in records:
        legs = rec.get("legs", [])
        if not legs:
            continue
        total += 1
        all_hit = True
        has_pending = False
        decided_miss = False  # v1.7.34：任一腿已有赛果且判错 → 整组已必死
        rec_date = rec.get("date", "")
        for leg in legs:
            num = leg.get("num")
            play = leg.get("playKey", "spf")
            direction = leg.get("dir")
            key = f"{rec_date}|{num}"
            sm = score_map.get(key)
            if not sm:
                has_pending = True
                # 清除可能残留的赛果信息
                if "actualScore" in leg:
                    del leg["actualScore"]
                if "legHit" in leg:
                    del leg["legHit"]
                if "adjScore" in leg:
                    del leg["adjScore"]
                continue
            hs, as_ = sm["home"], sm["away"]
            leg_hit = False
            adj_info = ""
            # 判断命中
            if play == "spf":
                # 胜平负
                if direction == "h" and hs > as_:
                    leg_hit = True
                elif direction == "d" and hs == as_:
                    leg_hit = True
                elif direction == "a" and hs < as_:
                    leg_hit = True
            elif play == "ttg":
                # 总进球
                total_goals = hs + as_
                try:
                    target = int(direction)
                    if (target == 7 and total_goals >= 7) or total_goals == target:
                        leg_hit = True
                except Exception:
                    pass
            elif play == "hhad":
                # 让球胜平负：goal<0主队让球，>0主队受让
                # adj_home = 主队进球 + goal；>客=让胜(h)，=让平(d)，<让负(a)
                goal = goal_map.get(key, 0)
                adj_home = hs + goal
                adj_info = f" (让{goal:+d}后{adj_home}:{as_})"
                if direction == "h" and adj_home > as_:
                    leg_hit = True
                elif direction == "d" and adj_home == as_:
                    leg_hit = True
                elif direction == "a" and adj_home < as_:
                    leg_hit = True
            if not leg_hit:
                all_hit = False
                decided_miss = True  # 该腿已有赛果且判错：整组串关已必死
            # 把赛果和单场命中状态附加到leg，方便页面展示追溯
            leg["actualScore"] = f"{hs}:{as_}"
            leg["legHit"] = leg_hit
            leg["hit"] = "hit" if leg_hit else "miss"
            if adj_info:
                leg["adjScore"] = adj_info
        # v1.7.34：decided_miss 优先于 has_pending——串关只要有一条腿已开奖且错误，
        # 无论其余腿是否开赛，整组都不可能再命中，应立即判 miss。
        # 旧逻辑「任一无赛果就整组 pending」会把已输掉的组挂成待开奖：
        # 2026-10-21 实测——12:31 含 003 的推荐 0:3 主负已死，却因其余腿是
        # 10-22 比赛一直显示「待开奖」，用户以为还能中等荒谬结果。
        if decided_miss:
            miss += 1
            new_result = "miss"
        elif has_pending:
            pending += 1
            new_result = "pending"
        elif all_hit:
            hit += 1
            new_result = "hit"
        else:
            miss += 1
            new_result = "miss"
        # 写回结果到parlay_history.json
        if rec.get("result") != new_result:
            rec["result"] = new_result
            rec["checkedAt"] = time.strftime("%Y-%m-%d %H:%M")
            modified = True
        else:
            # v1.7.34：result 未变也持久化腿上的赛果/命中信息——pending 组里
            # 已开奖的腿（混合态：003 已中、其余 10-22 开赛）需要在页面展示
            # 「该腿已中/已错」进度，只在内存算不落盘等于白算
            modified = True

    # 写回文件
    if modified:
        try:
            parlay_data["updatedAt"] = time.strftime("%Y-%m-%d %H:%M:%S")
            json.dump(parlay_data, open(parlay_file, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            print(f"  串关历史回查：已写回{hit+miss}条结果（命中{hit}/错误{miss}/待开奖{pending}）", flush=True)
        except Exception as e:
            print(f"  串关历史写回失败: {e}", flush=True)

    hit_rate = round(hit / (hit + miss) * 100, 1) if (hit + miss) > 0 else 0

    # 最近7天（基于写回后的result）
    recent = [r for r in records if r.get("date", "") >= time.strftime("%Y-%m-%d", time.localtime(time.time() - 7 * 86400))]
    recent_hit = sum(1 for r in recent if r.get("result") == "hit")
    recent_miss = sum(1 for r in recent if r.get("result") == "miss")
    recent_rate = round(recent_hit / (recent_hit + recent_miss) * 100, 1) if (recent_hit + recent_miss) > 0 else 0

    # 2026-11-12：顶层统计字段同步写回。此前只把 result 写回 records，
    # total/hit/miss/pending/hitRate 一直留在旧值（曾出现文件 78/15/63、
    # 实际 records 85 条 17中68错），页面由此显示「15/78 命中」却列出
    # 「85 组」，前后矛盾。按本轮重算结果对齐，且与注入 matches.json 的
    # 返回值同源，保证独立文件 / 内嵌 / 页面三处一致。仅在有差异时写盘，
    # 避免每轮无谓 IO 与时间戳抖动。
    _stat = {"total": total, "hit": hit, "miss": miss, "pending": pending,
             "hitRate": hit_rate, "recent7Rate": recent_rate}
    if any(parlay_data.get(k) != v for k, v in _stat.items()):
        parlay_data.update(_stat)
        try:
            json.dump(parlay_data, open(parlay_file, "w", encoding="utf-8"),
                      ensure_ascii=False, indent=1)
            print(f"  串关历史统计已对齐：{total} 组（中{hit}/错{miss}/待{pending}）"
                  f"，命中率 {hit_rate}%", flush=True)
        except Exception as e:
            print(f"  串关历史统计写回失败: {e}", flush=True)

    return {
        "total": total, "hit": hit, "miss": miss, "pending": pending,
        "hitRate": hit_rate, "recent7Rate": recent_rate,
        # 全量返回，绝不截断：历史记录是「已发布推荐」的凭证，
        # 曾因只返回最近20条，导致昨日14组只露出6组、今天组数一涨
        # 就把昨天的推荐全部挤出页面——用户翻查时「昨天的推荐不见了」。
        # 记录量级很小（日均<20组），全量注入无压力。
        "records": records
    }


def _parlay_engine_version():
    """读取 template.html 的 const VERSION 作为引擎版本（版本门用，v1.7.25）"""
    import re
    try:
        tpl = os.path.join(os.path.dirname(os.path.abspath(__file__)), "template.html")
        m = re.search(r'const\s+VERSION\s*=\s*"([^"]+)"',
                      open(tpl, encoding="utf-8").read())
        return m.group(1) if m else ""
    except Exception:
        return ""


def load_locked_parlay(today_matches=None):
    """从parlay_history.json加载今天已锁定的串关推荐，避免每批次变动。
    返回 (safe_parlay, high_odds_parlay) 或 (None, None) 表示今天尚未锁定。

    锁定规则（2026-10-13 修正）：
    当天一旦发布过任何一档串关，立即整体锁定，之后无论赔率怎么变都不再改动。
    —— 已发布的推荐必须是「不可篡改」的：用户拿着昨天的推荐来翻查对账，
       如果同一档位隔几小时就换一组，等于推荐可以被随时改写，专业性无从谈起。
    当天尚未发布过的档位，由主流程补生成（只增不改），不影响已发布档位。

    引擎版本门（v1.7.25 新增）：
    当日由**旧引擎**生成、且**尚未开球**的推荐（result=pending 且 engineVer
    旧于当前版本），视为「缺陷版本产物」——删除并解锁，让新引擎当日重生。
    背景：2026-10-20 三档倒挂推荐（v1.7.23 引擎）被当日锁定保护，v1.7.25 修复后
    无法当日生效（定时任务用自己的旧历史覆盖部署）。已判定（hit/miss）的记录
    是历史战绩凭证，绝不删除；已开球的 pending 记录同样保留。

    停售腿门（v1.7.34 新增）：
    pending 记录的腿若已**停售**（不在当日竞彩在售清单 today_matches），
    无论引擎版本，该档删除解锁，让主流程用**可下单**的比赛当日重生。
    背景：2026-10-21 实测——12:31 生成的推荐含周三003（18:00 开球），
    当晚用户看到的「今日推荐」实际已无法下单（003 停售后从 matches 滚出）。
    推荐必须保持「可下单」：已停售的 pending 档位留着只会误导用户。
    已判定（hit/miss）记录照旧绝不删；today_matches 为空/None 时跳过校验
    （防抓取异常把全部档位误删）。
    """
    import os
    import re
    parlay_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "parlay_history.json")
    today = time.strftime("%Y-%m-%d")
    if not os.path.exists(parlay_file):
        return None, None
    try:
        data = json.load(open(parlay_file, encoding="utf-8"))
    except Exception:
        return None, None
    records = data.get("records", [])
    today_records = [r for r in records if r.get("date") == today]
    if not today_records:
        return None, None

    # 当日竞彩在售编号集合（matches 快照中在售=可下单）；空则不校验，防误删
    sold_nums = set()
    if today_matches:
        sold_nums = {m.get("num") for m in today_matches if m.get("num")}

    # ===== 引擎版本门（v1.7.25）+ 停售腿门（v1.7.34）=====
    def _ver_tuple(v):
        m = re.match(r'v?(\d+)\.(\d+)\.(\d+)', v or "")
        return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)

    cur_ver = _parlay_engine_version()
    cur_t = _ver_tuple(cur_ver)
    stale_ids = set()
    for r in today_records:
        if r.get("result") != "pending":
            continue  # 已判定：历史战绩凭证，绝不删
        # 停售腿门（v1.7.34，优先于版本门）：任何引擎版本，腿停售即解锁
        if sold_nums:
            legs = r.get("legs") or []
            if legs and any((l.get("num") or "") not in sold_nums for l in legs):
                stale_ids.add(id(r))
                continue
        if _ver_tuple(r.get("engineVer", "")) >= cur_t:
            continue  # 当前引擎产物：正常锁定
        # 旧引擎产物：仅当全部腿未开球才解锁（开球后的推荐已进入投注窗口，不可篡改）
        not_started = True
        for l in (r.get("legs") or []):
            ko = l.get("kickoff") or ""
            try:
                if len(ko) >= 10 and ko[4] == '-':
                    kt = time.mktime(time.strptime(ko, "%Y-%m-%d %H:%M"))
                else:
                    kt = time.mktime(time.strptime(f"{r.get('date','')} {ko}", "%Y-%m-%d %H:%M"))
                if kt <= time.time():
                    not_started = False
                    break
            except Exception:
                pass
        if not_started:
            stale_ids.add(id(r))
    if stale_ids:
        data["records"] = [r for r in records if id(r) not in stale_ids]
        try:
            json.dump(data, open(parlay_file, "w", encoding="utf-8"),
                      ensure_ascii=False, indent=1)
        except Exception:
            pass
        print(f"  串关门禁：当日 {len(stale_ids)} 条待开奖推荐已解锁"
              f"（旧引擎未开球 / 腿已停售不可下单，{cur_ver} 当日重生）",
              flush=True)
        # v1.7.34：不再整体 return None——剩余在售档位照常锁定回放，
        # 被删档位由主流程补生成（只增不改）。否则「一档停售、其余在售」
        # 会导致其余档位也被重新生成，旧记录残留 + 新记录追加成双轨
        #（同一天同一档两条记录，用户看到推荐被偷偷换组）。
        today_records = [r for r in today_records if id(r) not in stale_ids]
        if not today_records:
            return None, None

    def rebuild(tier_name):
        """按档位名找回当天已发布的该档推荐（**只回放 pending（未判定）记录**）。
        历史 type 形如 稳健2串1/均衡3串1/精锐4串1。
        同一档位当天有多条 pending 时取第一条——发布顺序即锁定顺序，
        第一条就是当初对用户公布的那组，后续生成的绝不覆盖它。
        有 snapshot 字段的记录按快照完整还原发布时的卡片（EV/仓位/说明等）；
        旧格式记录（无 snapshot）用顶层字段兜底还原。

        v1.7.34：已判定（hit/miss）的记录**不再作为当前推荐回放**——当日修订
        （如剔除停售腿重生）会删旧存新，旧组已判错时若仍回放，用户会把一组
        已经输掉/已完结的推荐当成可下单的「今日推荐」（2026-10-21 实测：
        12:31 含 003 的推荐 0:3 主负全军覆没，绝不能再出现在推荐位）。
        已判定记录的归宿是「串关历史战绩」区（战后对账），由 check_parlay_history
        自动判定展示；当日推荐位只呈现仍未开球的 pending 组。
        """
        cands = [r for r in today_records
                 if str(r.get("type", "")).startswith(tier_name)]
        pending = [r for r in cands if r.get("result") == "pending"]
        if not pending:
            return None  # 无未开球推荐：不拿已判定旧组充当当前推荐
        rec = pending[0]
        snap = rec.get("snapshot") or {}
        p = dict(snap) if snap else {}
        p.setdefault("tier", tier_name)
        p.setdefault("type", rec.get("type", "").replace(tier_name, "", 1) or "串1")
        p["legs"] = rec.get("legs", [])
        p["totalOdds"] = rec.get("totalOdds", 0)
        p["avgConfidence"] = rec.get("avgConfidence", 0)
        if rec.get("ev") is not None:
            p["ev"] = rec.get("ev")
        p["recommended"] = bool(rec.get("recommended", False))
        p["locked"] = True
        p["savedAt"] = rec.get("savedAt", "")
        return p

    safe_p2 = rebuild("稳健")   # parlay2 槽位：稳健档（2串1）
    safe_p3 = rebuild("均衡")   # parlay3 槽位：均衡档（3串1）
    safe_p4 = rebuild("精锐")   # parlay4 槽位：精锐档（4串1）

    # 回放来源只可能是 pending 记录（rebuild 已保证）；取其中最早发布的一条作 generatedAt
    _pend_all = [r for r in today_records if r.get("result") == "pending"]
    # v1.7.134：从生成时的 snapshot 恢复候选/合格统计，锁定回放不再显示 0。
    # 旧记录（无这些字段）保持缺失，由前端按「已锁定」诚实文案处理，绝不编造数字。
    _meta = {}
    for _r in _pend_all:
        _s = _r.get("snapshot") or {}
        for _k in ("candidateCount", "qualifiedCount", "candidatePool",
                   "poolNotes", "tierNotes", "matchCount",
                   "batchDate", "batchLabel", "generatedAt"):
            if _k in _s and _k not in _meta:
                _meta[_k] = _s[_k]
    safe_parlay = {
        "generatedAt": (_pend_all[0].get("savedAt", "") if _pend_all else ""),
        "candidateCount": _meta.get("candidateCount", 0),
        "strategy": "分层串关（今日已锁定，不再变动）",
        "parlay2": safe_p2, "parlay3": safe_p3,
        "parlay4": safe_p4, "locked": True,
        **{k: v for k, v in _meta.items() if k not in ("generatedAt", "candidateCount")},
    } if (safe_p2 or safe_p3 or safe_p4) else None

    # 高倍串关已按用户要求永久移除，不再返回
    high_parlay = None

    return safe_parlay, high_parlay


def save_parlay_history(safe_parlay, high_parlay):
    """保存当天串关推荐到parlay_history.json，用于后续回查。"""
    import os
    parlay_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "parlay_history.json")
    today = time.strftime("%Y-%m-%d")

    try:
        if os.path.exists(parlay_file):
            data = json.load(open(parlay_file, encoding="utf-8"))
        else:
            data = {"updatedAt": "", "records": []}
    except Exception:
        data = {"updatedAt": "", "records": []}

    records = data.get("records", [])
    # 锁定机制：当天已保存的「同一组 legs（按 场次+玩法+方向）」不再覆盖，避免重复。
    # 用 legs 签名去重（不依赖展示用 type 文案），命名随档位变化也不产生重复。
    def _leg_sig(legs):
        return tuple(sorted((l.get("num"), l.get("playKey"), l.get("dir")) for l in (legs or [])))
    today_sigs = {_leg_sig(r.get("legs", [])) for r in records if r.get("date") == today}

    # 保存各档串关（稳健/均衡/精锐）：即便真实口径未达标标「观望」也照常落盘，
    # 方便赛后对照「不推荐」是否真的没中，反向验证 EV 模型是否成立。
    for key in ("parlay2", "parlay3", "parlay4"):
        p = (safe_parlay or {}).get(key)
        if not p or not p.get("legs"):
            continue
        sig = _leg_sig(p["legs"])
        if sig in today_sigs:
            continue
        today_sigs.add(sig)
        ptype = f'{p.get("tier", "")}{p.get("type", "")}'
        records.append({
            "date": today, "type": ptype,
            "totalOdds": p["totalOdds"], "avgConfidence": p.get("avgConfidence", 0),
            "legs": p["legs"], "recommended": bool(p.get("recommended", False)),
            "ev": p.get("ev"),
            # v1.7.43：地面真实口径 EV（同指命中率×总赔−1）顶层透传。
            # 此前仅存于 snapshot 内，回溯「为什么推荐/为什么不推荐」要翻快照，
            # 现与 ev 并列落盘，推荐标准可逐日审计。
            "realEv": p.get("realEv"),
            "result": "pending",
            "savedAt": time.strftime("%Y-%m-%d %H:%M:%S"),
            # 引擎版本门（v1.7.25）：记录生成时的引擎版本。当日未开球的推荐若为旧引擎
            # 产物，下次跑批时 load_locked_parlay 会自动解锁并由新引擎当日重生。
            "engineVer": _parlay_engine_version(),
            # 完整快照：把发布时该档的全部字段原样留存（EV/建议仓位/档位说明/
            # 命中率/抽水等）。锁定回放时按快照还原，用户翻看历史看到的
            # 必须和当初发布的卡片一模一样，不能是残缺重建。
            # v1.7.134：额外带上生成时的顶层候选/合格统计。此前锁定回放把
            # candidateCount 写死成 0、qualifiedCount 整个丢失，于是「今日
            # 推荐已锁定」后每轮自动刷新，页面都显示「候选 0 / 合格 0 ·
            # 已产出 2 档」，看着又像分层串关坏了（用户会再来提醒一次）。
            "snapshot": {
                **{k: v for k, v in p.items()},
                **{k: (safe_parlay or {}).get(k)
                   for k in ("candidateCount", "qualifiedCount", "candidatePool",
                             "poolNotes", "tierNotes", "matchCount",
                             "batchDate", "batchLabel", "generatedAt")
                   if (safe_parlay or {}).get(k) is not None},
            },
        })

    data["updatedAt"] = time.strftime("%Y-%m-%d %H:%M:%S")
    data["records"] = records
    json.dump(data, open(parlay_file, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"  串关历史已保存：{len(records)}条记录", flush=True)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        # 顶层兜底：任何未预期异常都打印清晰错误并退出 1，
        # 避免抛出原始 traceback；由 run_daily.sh 决定是否判失败。
        import traceback
        traceback.print_exc()
        print(f"\n[致命] fetch_daily.py 执行异常: {e}", flush=True)
        sys.exit(1)
    # 抓取高手推荐（92玩球易红单）：北京时间 08:00-23:00 抓取（CI 为 UTC，用 gmtime+8）
    current_hour = (time.gmtime().tm_hour + 8) % 24
    if 8 <= current_hour <= 23:
        print("\n[7/7] 抓取高手推荐...", flush=True)
        try:
            from fetch_expert import main as expert_main
            expert_main()
        except Exception as e:
            print(f"  高手推荐抓取失败: {e}", flush=True)
    else:
        print(f"\n[7/7] 跳过高手推荐抓取（当前北京时间{current_hour}:00，仅08:00-23:00抓取）", flush=True)
