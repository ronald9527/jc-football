#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""构建看板：读取 matches.json + history.json + rules_config.json -> 注入 template.html -> 生成 index.html"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))

def main():
    with open(os.path.join(HERE, "matches.json"), encoding="utf-8") as f:
        data = json.load(f)
    hist = {"updatedAt": "", "total": 0, "records": []}
    hp = os.path.join(HERE, "history.json")
    if os.path.exists(hp):
        try:
            with open(hp, encoding="utf-8") as f:
                hist = json.load(f)
        except Exception:
            pass
    cfg = {}
    cp = os.path.join(HERE, "rules_config.json")
    if os.path.exists(cp):
        try:
            with open(cp, encoding="utf-8") as f:
                cfg = json.load(f)
        except Exception:
            pass
    # 北单、半全场 tab 已下线，不再加载相关数据
    bd = {"updateTime": "", "count": 0, "matches": []}
    bdh = {"updateTime": "", "count": 0, "records": []}
    # 从 matches.json 中剥离半全场数据（tab 已下线）
    if isinstance(data, dict):
        data.pop("halfFull", None)
        data.pop("halfFullHistory", None)
    hkmoh = {"records": []}
    hkp = os.path.join(HERE, "hkmo_history.json")
    if os.path.exists(hkp):
        try:
            with open(hkp, encoding="utf-8") as f:
                hkmoh = json.load(f)
        except Exception:
            pass
    # 强弱对战历史
    swh = {}
    swp = os.path.join(HERE, "strongweak_history.json")
    if os.path.exists(swp):
        try:
            with open(swp, encoding="utf-8") as f:
                swh = json.load(f)
        except Exception:
            pass
    expert = {"updatedAt": "", "recommendations": []}
    ep = os.path.join(HERE, "expert_recommendations.json")
    if os.path.exists(ep):
        try:
            with open(ep, encoding="utf-8") as f:
                expert = json.load(f)
        except Exception:
            pass
    exporth = {}
    ehp = os.path.join(HERE, "expert_history.json")
    if os.path.exists(ehp):
        try:
            with open(ehp, encoding="utf-8") as f:
                exporth = json.load(f)
        except Exception:
            pass
    expertstats = {}
    esp = os.path.join(HERE, "expert_stats.json")
    if os.path.exists(esp):
        try:
            with open(esp, encoding="utf-8") as f:
                esd = json.load(f)
                expertstats = esd.get("stats", {})
        except Exception:
            pass
    # BSD 国际权威赔率（独立源，不污染核心 matches.json）
    odds_bsd = {"updatedAt": "", "source": "", "independent": True, "matches": [], "total_movements": 0}
    obp = os.path.join(HERE, "odds_bsd.json")
    if os.path.exists(obp):
        try:
            with open(obp, encoding="utf-8") as f:
                odds_bsd = json.load(f)
        except Exception:
            pass
    # football-data.org 官方赛果核对（独立源，不参与模型）
    fd = {"updatedAt": "", "source": "football-data.org", "enabled": False, "matches": [], "byNum": {}}
    fdp = os.path.join(HERE, "fd_data.json")
    if os.path.exists(fdp):
        try:
            with open(fdp, encoding="utf-8") as f:
                fd = json.load(f)
        except Exception:
            pass
    # BSD 伤停/首发/教练/天气/裁判/AI预测（独立源，不污染核心 matches.json）
    bsd_data = {"byNum": {}}
    bsp = os.path.join(HERE, "bsd_data.json")
    if os.path.exists(bsp):
        try:
            with open(bsp, encoding="utf-8") as f:
                bsd_data = json.load(f)
        except Exception:
            pass
    # 把专家战绩合并到每条推荐（主推荐expertStats + 其他专家hitRate）
    for _r in expert.get("recommendations", []):
        _name = _r.get("expertName", "")
        _st = expertstats.get(_name)
        if _st:
            _r["expertStats"] = _st
        for _o in _r.get("otherExperts", []):
            _oname = _o.get("expertName", "")
            _ost = expertstats.get(_oname)
            if _ost:
                _o["hitRate"] = _ost.get("hitRate", 0)
                _o["judged"] = _ost.get("judged", 0)
                _o["isNew"] = _ost.get("isNew", False)
    with open(os.path.join(HERE, "template.html"), encoding="utf-8") as f:
        tpl = f.read()

    js_data = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
    js_hist = json.dumps(hist, ensure_ascii=False).replace("</", "<\\/")
    js_cfg = json.dumps(cfg, ensure_ascii=False).replace("</", "<\\/")
    js_bd = json.dumps(bd, ensure_ascii=False).replace("</", "<\\/")
    js_bdh = json.dumps(bdh, ensure_ascii=False).replace("</", "<\\/")
    js_hkmoh = json.dumps(hkmoh, ensure_ascii=False).replace("</", "<\\/")
    js_swh = json.dumps(swh, ensure_ascii=False).replace("</", "<\\/")
    js_expert = json.dumps(expert, ensure_ascii=False).replace("</", "<\\/")
    js_exporth = json.dumps(exporth, ensure_ascii=False).replace("</", "<\\/")
    js_expertstats = json.dumps(expertstats, ensure_ascii=False).replace("</", "<\\/")
    js_odds_bsd = json.dumps(odds_bsd, ensure_ascii=False).replace("</", "<\\/")
    js_fd = json.dumps(fd, ensure_ascii=False).replace("</", "<\\/")
    js_bsd = json.dumps(bsd_data.get("byNum", {}), ensure_ascii=False).replace("</", "<\\/")
    # 比分预测（独立源：football-data.org + 自建 Poisson，零耦合核心数据/模型）
    score_pred = {"matches": [], "reliable": {}, "accuracy": {}, "source": "", "updatedAt": "", "note": ""}
    spp = os.path.join(HERE, "score_predict.json")
    if os.path.exists(spp):
        try:
            with open(spp, encoding="utf-8") as f:
                score_pred = json.load(f)
        except Exception:
            pass
    # v1.7.113：赛果规范化的「最后一道关」——无论 fetch_scores.py 在步骤1.85 还是
    # 步骤2.5 陈旧豁免重跑，页面数据都保证：有赛果的场次 status=FINISHED、整数比分、
    # 命中判定齐全，且历史竞彩日不缺场（10-24/10-25 曾整段被滚动窗口挤出）。
    # 纯内存修正不写源盘；持久化由 sp_results.py CLI（步骤1.852）负责。
    try:
        import sys as _sys
        _sys.path.insert(0, HERE)
        import sp_results
        sp_results.normalize_sp(score_pred)
    except Exception as _e:
        print("  [sp_results] 规范化跳过（沿用源数据）:", _e)
    js_scorepred = json.dumps(score_pred, ensure_ascii=False).replace("</", "<\\/")
    # 模型 vs WhoScored 命中率 A/B 对比（accuracy_ab.py 每日累积，独立分析源）
    _ab = {}
    try:
        _ab = json.load(open(os.path.join(HERE, "ab_compare.json"), encoding="utf-8")).get("stats", {})
    except Exception:
        pass
    js_ab = json.dumps(_ab, ensure_ascii=False).replace("</", "<\\/")
    # WhoScored 人工预测比分（独立源，与核心数据/模型零耦合）
    ws_data = {"matches": [], "dateList": [], "history": [], "historyDateList": [], "reliable": {}}
    wsp = os.path.join(HERE, "whoscored_data.json")
    if os.path.exists(wsp):
        try:
            with open(wsp, encoding="utf-8") as f:
                ws_data = json.load(f)
        except Exception:
            pass
    js_ws = json.dumps(ws_data, ensure_ascii=False).replace("</", "<\\/")
    # V站·呼死狗情报（中文原味源，免翻译；v1.7.75）
    vz_data = {"updatedAt": "", "matches": []}
    vzp = os.path.join(HERE, "vzhan_data.json")
    if os.path.exists(vzp):
        try:
            with open(vzp, encoding="utf-8") as f:
                vz_data = json.load(f)
        except Exception:
            pass
    js_vz = json.dumps(vz_data, ensure_ascii=False).replace("</", "<\\/")
    # V站网关稳定性状态（check_vzhan_gateway.py 产出；v1.7.77）
    vzgw_data = {"updatedAt": "", "status": "unknown", "latencyMs": None,
                 "lastUp": "", "lastDown": "", "consecFails": 0,
                 "totalChecks": 0, "totalFails": 0, "note": ""}
    vzgwp = os.path.join(HERE, "vzhan_gateway_status.json")
    if os.path.exists(vzgwp):
        try:
            with open(vzgwp, encoding="utf-8") as f:
                vzgw_data = json.load(f)
        except Exception:
            pass
    js_vzgw = json.dumps(vzgw_data, ensure_ascii=False).replace("</", "<\\/")
    # V站 赛果回填档案（fetch_vzhan.py 完赛归档，含 highConf/confWhy 高信心标记）
    vzhist_data = {"updatedAt": "", "matches": {}}
    vzhistp = os.path.join(HERE, "vzhan_history.json")
    if os.path.exists(vzhistp):
        try:
            with open(vzhistp, encoding="utf-8") as f:
                vzhist_data = json.load(f)
        except Exception:
            pass
    js_vzhist = json.dumps(vzhist_data, ensure_ascii=False).replace("</", "<\\/")
    # 竞彩篮球（独立源：官方 basketball 接口，与足球数据/模型零耦合，v1.7.29）
    bk_data = {"updatedAt": "", "matches": []}
    bkp = os.path.join(HERE, "basketball.json")
    if os.path.exists(bkp):
        try:
            with open(bkp, encoding="utf-8") as f:
                bk_data = json.load(f)
        except Exception:
            pass
    js_bk = json.dumps(bk_data, ensure_ascii=False).replace("</", "<\\/")
    bkh_data = {"updatedAt": "", "records": {}}
    bkhp = os.path.join(HERE, "basketball_history.json")
    if os.path.exists(bkhp):
        try:
            with open(bkhp, encoding="utf-8") as f:
                bkh_data = json.load(f)
        except Exception:
            pass
    js_bkh = json.dumps(bkh_data, ensure_ascii=False).replace("</", "<\\/")
    # 篮球 AI 预测（v1.7.44 独立源）
    bkai_data = {"updatedAt": "", "note": "", "predictions": []}
    bkaip = os.path.join(HERE, "basketball_ai.json")
    if os.path.exists(bkaip):
        try:
            with open(bkaip, encoding="utf-8") as f:
                bkai_data = json.load(f)
        except Exception:
            pass
    js_bkai = json.dumps(bkai_data, ensure_ascii=False).replace("</", "<\\/")
    # 篮球串关历史（v1.7.44 独立源）
    bkpl_data = {"updatedAt": "", "total": 0, "hit": 0, "miss": 0, "pending": 0, "records": []}
    bkplp = os.path.join(HERE, "basketball_parlay_history.json")
    if os.path.exists(bkplp):
        try:
            with open(bkplp, encoding="utf-8") as f:
                bkpl_data = json.load(f)
        except Exception:
            pass
    js_bkpl = json.dumps(bkpl_data, ensure_ascii=False).replace("</", "<\\/")
    # 篮球历史统计（v1.7.44 独立源）
    bkst_data = {"updatedAt": "", "sample": {}, "leagues": {}, "hdc_overall": {},
                 "hilo_overall": {}, "wnm_dist": {}, "home_advantage": {}, "roi": {}}
    bkstp = os.path.join(HERE, "basketball_stats.json")
    if os.path.exists(bkstp):
        try:
            with open(bkstp, encoding="utf-8") as f:
                bkst_data = json.load(f)
        except Exception:
            pass
    js_bkst = json.dumps(bkst_data, ensure_ascii=False).replace("</", "<\\/")
    # 篮球 AI 预测回溯库（v1.7.46）
    bkaiacc_data = {"updatedAt": "", "history": []}
    bkaiaccp = os.path.join(HERE, "basketball_ai_accuracy.json")
    if os.path.exists(bkaiaccp):
        try:
            with open(bkaiaccp, encoding="utf-8") as f:
                bkaiacc_data = json.load(f)
        except Exception:
            pass
    js_bkaiacc = json.dumps(bkaiacc_data, ensure_ascii=False).replace("</", "<\\/")
    # SP_TEAM_ZH：英文队名 → 竞彩中文名，由 team_map.py 单一真相源生成
    # （原为 template.html 内手写硬编码字典，key 格式与 WhoScored 实际输出
    #  不一致导致大量汉化失败，v1.7.22 改为自动注入，杜绝双字典漂移）
    sp_team_zh = {}
    try:
        sys.path.insert(0, HERE)
        from team_map import TEAM_EN2ZH
        sp_team_zh = {k: v for k, v in TEAM_EN2ZH.items()}
    except Exception as e:
        print("! team_map 导入失败，SP_TEAM_ZH 为空：%s" % e)
    js_sp_team_zh = json.dumps(sp_team_zh, ensure_ascii=False).replace("</", "<\\/")
    # SP_TEAM_CREST：队名 → 队标(crest) URL（英文 FD 名 + 中文竞彩名 双键），由 fetch_crests.py 生成
    sp_team_crest = {}
    tcp = os.path.join(HERE, "team_crests.json")
    if os.path.exists(tcp):
        try:
            with open(tcp, encoding="utf-8") as f:
                sp_team_crest = json.load(f)
        except Exception as e:
            print("! team_crests.json 读取失败：%s" % e)
    js_sp_team_crest = json.dumps(sp_team_crest, ensure_ascii=False).replace("</", "<\\/")
    out = (tpl.replace("__DATA_PLACEHOLDER__", js_data)
              .replace("__HISTORY_PLACEHOLDER__", js_hist)
              .replace("__CONFIG_PLACEHOLDER__", js_cfg)
              .replace("__BD_DATA_PLACEHOLDER__", js_bd)
              .replace("__BD_HISTORY_PLACEHOLDER__", js_bdh)
              .replace("__HKMO_HISTORY_PLACEHOLDER__", js_hkmoh)
              .replace("__STRONGWEAK_HISTORY_PLACEHOLDER__", js_swh)
              .replace("__EXPERT_PLACEHOLDER__", js_expert)
              .replace("__EXPERT_HISTORY_PLACEHOLDER__", js_exporth)
              .replace("__EXPERT_STATS_PLACEHOLDER__", js_expertstats)
              .replace("__ODDS_BSD_PLACEHOLDER__", js_odds_bsd)
              .replace("__FD_PLACEHOLDER__", js_fd)
              .replace("__BSD_PLACEHOLDER__", js_bsd)
              .replace("__SCORE_PREDICT_PLACEHOLDER__", js_scorepred)
              .replace("__SP_TEAM_ZH_PLACEHOLDER__", js_sp_team_zh)
              .replace("__SP_TEAM_CREST_PLACEHOLDER__", js_sp_team_crest)
              .replace("__WHOSCORED_PLACEHOLDER__", js_ws)
              .replace("__VZHAN_PLACEHOLDER__", js_vz)
              .replace("__VZGW_PLACEHOLDER__", js_vzgw)
              .replace("__VZHAN_HISTORY_PLACEHOLDER__", js_vzhist)
              .replace("__BASKETBALL_PLACEHOLDER__", js_bk)
              .replace("__BASKETBALL_HISTORY_PLACEHOLDER__", js_bkh)
              .replace("__BASKETBALL_AI_PLACEHOLDER__", js_bkai)
              .replace("__BASKETBALL_PARLAY_PLACEHOLDER__", js_bkpl)
              .replace("__BASKETBALL_STATS_PLACEHOLDER__", js_bkst)
              .replace("__BASKETBALL_AI_ACC_PLACEHOLDER__", js_bkaiacc)
              .replace("__AB_STATS_PLACEHOLDER__", js_ab))

    for ph in ("__DATA_PLACEHOLDER__", "__HISTORY_PLACEHOLDER__", "__CONFIG_PLACEHOLDER__",
               "__BD_DATA_PLACEHOLDER__", "__BD_HISTORY_PLACEHOLDER__", "__HKMO_HISTORY_PLACEHOLDER__",
               "__STRONGWEAK_HISTORY_PLACEHOLDER__",
               "__EXPERT_PLACEHOLDER__", "__EXPERT_HISTORY_PLACEHOLDER__", "__EXPERT_STATS_PLACEHOLDER__",
               "__ODDS_BSD_PLACEHOLDER__", "__FD_PLACEHOLDER__", "__BSD_PLACEHOLDER__",
               "__SCORE_PREDICT_PLACEHOLDER__", "__SP_TEAM_ZH_PLACEHOLDER__",
               "__WHOSCORED_PLACEHOLDER__", "__VZHAN_PLACEHOLDER__", "__VZGW_PLACEHOLDER__",
               "__VZHAN_HISTORY_PLACEHOLDER__",
               "__BASKETBALL_PLACEHOLDER__",
               "__BASKETBALL_HISTORY_PLACEHOLDER__", "__BASKETBALL_AI_PLACEHOLDER__",
               "__BASKETBALL_PARLAY_PLACEHOLDER__", "__BASKETBALL_STATS_PLACEHOLDER__",
               "__BASKETBALL_AI_ACC_PLACEHOLDER__"):
        assert ph not in out, f"占位符未替换: {ph}"
    out_path = os.path.join(HERE, "index.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(out)
    print("已生成:", out_path, f"({len(out)} 字符, 今日{data.get('count',0)}场, 历史{hist.get('total',0)}条, 港澳历史{len(hkmoh.get('records',[]))}条, 高手推荐{len(expert.get('recommendations',[]))}条, 国际权威赔率{len(odds_bsd.get('matches',[]))}场, 官方赛果{len(fd.get('matches',[]))}场, 比分预测{len(score_pred.get('matches',[]))}场)")

if __name__ == "__main__":
    main()
