#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
selftest.py —— 数据自检（每日自动跑，发现问题退出码非 0）

检查 6 大类：
  1. 数据完整性：必填字段、编号唯一、日期合法
  2. 赔率合理性：范围 1.05~25、返奖率落在 85%~92%（异常说明接口数据错乱）
  3. 概率一致性：胜平负三者概率之和接近 100%（±3pt）
  4. 串关合理性：拒绝蚊子肉（单场 >= 1.60）、总赔 >= 2.2、EV/命中率字段存在
  4.5 串关历史完整性：防截断（页面注入量≥源文件）、防消失（昨天组数完整可见）、
      防快照丢失（最新记录带 snapshot）——2026-10-13「昨天推荐翻不到」事故加固
  5. 历史库：条数、日期连续、命中判定字段完整
  6. 页面产物：占位符是否已全部替换、无未替换标记
  7. 数据源隔离：独立源（The Odds API / football-data.org / 高手荐单）不得写回核心
     matches.json 或 history.json（模型训练数据），各自落独立文件

输出：selftest_report.json；控制台打印 [OK]/[WARN]/[ERROR]
退出码：0=通过  1=有 ERROR  2=仅有 WARN（可用 --strict 让 WARN 也失败）
"""
import json
import os
import re
import sys
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
REPORT = os.path.join(HERE, "selftest_report.json")

issues = []          # {"level":"ERROR|WARN","cat":"...","msg":"..."}


def add(level, cat, msg):
    issues.append({"level": level, "cat": cat, "msg": msg})
    print("  [%s] %s：%s" % (level, cat, msg))


def load(name, default=None):
    p = os.path.join(HERE, name)
    if not os.path.exists(p):
        return default
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        add("ERROR", "文件", "%s 解析失败：%s" % (name, e))
        return default


def check_matches(data):
    print("· 检查 1/6 数据完整性")
    ms = (data or {}).get("matches", [])
    if not ms:
        add("ERROR", "数据完整性", "matches.json 无比赛数据")
        return
    today = datetime.date.today().strftime("%Y-%m-%d")
    upd = data.get("updateTime") or ""
    if not upd:
        add("ERROR", "数据完整性", "缺少 updateTime")
    elif upd[:10] != today:
        add("WARN", "时效性", "数据更新时间 %s 不是今天（%s），抓取任务可能停摆" % (upd, today))

    nums = [m.get("num") for m in ms]
    dup = {n for n in nums if nums.count(n) > 1}
    if dup:
        add("ERROR", "数据完整性", "编号重复：%s" % sorted(dup))

    for m in ms:
        n = m.get("num")
        if not m.get("home") or not m.get("away"):
            add("ERROR", "数据完整性", "%s 缺少队名" % n)
        if not m.get("kickoff"):
            add("WARN", "数据完整性", "%s 缺少开赛时间" % n)

    print("  共 %d 场" % len(ms))


def check_odds(data):
    print("· 检查 2/6 赔率合理性")
    ms = (data or {}).get("matches", [])
    bad_range, rates = [], []
    for m in ms:
        had = m.get("had") or {}
        hs = [had.get(k) for k in ("h", "d", "a")]
        if not all(isinstance(x, (int, float)) and x > 0 for x in hs):
            continue
        for k, v in had.items():
            if k in ("h", "d", "a") and not (1.05 <= v <= 25):
                bad_range.append("%s %s=%.2f" % (m.get("num"), k, v))
        s = 1 / hs[0] + 1 / hs[1] + 1 / hs[2]
        rates.append(1 / s)
    if bad_range:
        add("ERROR", "赔率合理性", "赔率超出合理区间：%s" % bad_range[:5])
    if rates:
        avg = sum(rates) / len(rates)
        print("  平均返奖率 %.1f%%（样本 %d 场）" % (avg * 100, len(rates)))
        if not (0.84 <= avg <= 0.93):
            add("WARN", "赔率合理性", "平均返奖率 %.1f%% 偏离常态 88.6%%，接口数据可能异常" % (avg * 100))


def check_prob(data):
    print("· 检查 3/6 概率一致性")
    ms = (data or {}).get("matches", [])
    off = []
    for m in ms:
        p = m.get("hadProb") or {}
        hs = [p.get("h"), p.get("d"), p.get("a")]
        if not all(isinstance(x, (int, float)) for x in hs):
            continue
        tot = sum(hs)
        if abs(tot - 100) > 3:
            off.append("%s=%.1f" % (m.get("num"), tot))
    if off:
        add("WARN", "概率一致性", "概率之和偏离 100%% 超过 3pt：%s" % off[:5])


def check_parlay(data):
    print("· 检查 4/6 串关合理性（蚊子肉检测）")
    sp = (data or {}).get("safeParlay") or {}
    found = 0
    for key in ("parlay2", "parlay3", "parlay4"):
        p = sp.get(key)
        if not p:
            continue
        found += 1
        legs = p.get("legs") or []
        if not legs:
            add("ERROR", "串关", "%s 无腿" % key)
            continue
        min_o = min(l.get("odds") or 0 for l in legs)
        tot = p.get("totalOdds") or 0
        if min_o < 1.60:
            add("WARN", "串关", "%s 存在蚊子肉单场 %.2f（下限 1.60）" % (key, min_o))
        if tot < 2.2:
            add("WARN", "串关", "%s 总赔 %.2f 偏低" % (key, tot))
        for f in ("jointProb", "ev", "rake"):
            if p.get(f) is None:
                add("WARN", "串关", "%s 缺少字段 %s" % (key, f))
        # v1.7.121 证据门禁：负超额腿 = 历史同方向实证命中率低于市场定价，
        # 这类腿不得进入任何一档；被标「推荐」更是乱推荐，直接判 ERROR。
        neg = [l for l in legs if (l.get("edge") or 0) < -1.0]
        if neg:
            add("ERROR", "串关", "%s 含 %d 条负超额腿（历史实证差于市场定价，证据准入失效）" % (key, len(neg)))
        if p.get("recommended"):
            if (p.get("realEv") or 0) < -2:
                add("ERROR", "串关", "%s 标为推荐但真实EV %s%% 未达标" % (key, p.get("realEv")))
            if p.get("negEdgeLegs"):
                add("ERROR", "串关", "%s 标为推荐却有负超额腿" % key)
        print("  %s：%s %.2f倍 命中%s%% EV%s%% 真实EV%s%% 负超额腿%d 推荐=%s" % (
            key, p.get("tier"), tot, p.get("jointProb"), p.get("ev"),
            p.get("realEv"), len(neg), p.get("recommended")))
    # ===== v1.7.122 门禁：先有合格单场、才有组合（前缀嵌套 + 统一资格）=====
    # 用户原则「选串关是把单场最有把握，数据支撑，合理，才进行串关组合」。
    # 防止引擎退回「先定 2/3/4 腿档位、再各自凑组合、档位越高门槛越松」。
    _tiers = [(k, sp.get(k)) for k in ("parlay2", "parlay3", "parlay4")]
    _present = [(k, p) for k, p in _tiers if p]
    for _k, _p in _present:
        _ls = _p.get("legs") or []
        # ① 每条腿都必须是合格单场：实证超额≥0、样本≥20、赔率 1.60~3.20
        _bad = [l for l in _ls if (l.get("edge") or 0) < 0
                or (l.get("empN") or 0) < 20
                or not (1.60 <= (l.get("odds") or 0) <= 3.20)]
        if _bad:
            add("ERROR", "串关", "%s 含 %d 条不合格单场（应：超额≥0、样本≥20、赔率1.60~3.20）" % (_k, len(_bad)))
        # ② 把握度排名必须连续 1..n（前缀）
        _ranks = sorted((l.get("gripRank") or 0) for l in _ls)
        if _ranks != list(range(1, len(_ls) + 1)):
            add("ERROR", "串关", "%s 把握度排名不连续 %s（应为 1..%d 前缀）" % (_k, _ranks, len(_ls)))
    # ③ 后档严格包含前档全部腿（嵌套）
    def _sig(legs):
        return set((l.get("num"), l.get("label")) for l in (legs or []))
    for (_ka, _pa), (_kb, _pb) in zip(_present, _present[1:]):
        if not _sig(_pa.get("legs")).issubset(_sig(_pb.get("legs"))):
            add("ERROR", "串关", "%s 未包含 %s 全部腿（前缀嵌套被破坏，又在独立凑组合）" % (_kb, _ka))
    # ④ 总赔随腿数严格递增
    _tos = [_p.get("totalOdds") or 0 for _k, _p in _present]
    if any(x >= y for x, y in zip(_tos, _tos[1:])):
        add("ERROR", "串关", "三档总赔未严格递增 %s" % _tos)
    # ⑤ v1.7.123 竞彩批次隔离：任一组合的所有腿必须来自同一竞彩销售批次。
    # 用户明确要求「别周五的和周六的串起来」——用腿上 num 前缀（周五/周六/周日）
    # 与 batchDate 双重判定；顶层三档与 batches 内每一档都检查。
    import re as _re
    def _batch_violation(legs):
        dates, labels = set(), set()
        for l in (legs or []):
            d = l.get("batchDate")
            n = str(l.get("num") or "")
            mt = _re.match(r"^(周[一二三四五六日])", n)
            lab = l.get("batchLabel") or (mt.group(1) if mt else "")
            if d:
                dates.add(d)
            elif lab:
                dates.add(lab)
            if lab:
                labels.add(lab)
        # 兼容旧单批数据（无批次字段）：不作要求，只检查有标注的情况
        return len(dates) > 1, sorted(dates), sorted(labels)
    for _k, _p in _present:
        _bad, _ds, _ls = _batch_violation(_p.get("legs"))
        if _bad:
            add("ERROR", "串关", "%s 跨竞彩批次组合 %s（禁止把周五和周六串起来）" % (_k, _ds))
    _batches = sp.get("batches")
    if isinstance(_batches, list):
        for _b in _batches:
            _bk = _b.get("batchKey") or _b.get("batchDate")
            for _k in ("parlay2", "parlay3", "parlay4"):
                _p = _b.get(_k)
                if not _p:
                    continue
                _bad, _ds, _ls = _batch_violation(_p.get("legs"))
                if _bad:
                    add("ERROR", "串关", "批次 %s 的 %s 跨批次 %s" % (_bk, _k, _ds))
                # 每档腿的批次必须等于所属批次
                _bd = set(str(l.get("batchDate") or "") for l in (_p.get("legs") or [])
                          if l.get("batchDate"))
                if _bd and _b.get("batchDate") and not _bd.issubset({_b["batchDate"]}):
                    add("ERROR", "串关", "批次 %s 的 %s 混入其它批次腿 %s" % (_bk, _k, sorted(_bd)))
        print("  批次隔离：%d 个竞彩批次，逐档核对同批次完成" % len(_batches))
    # ⑥ 合格单场不足 N 条时该档必须为空（不得硬凑）
    _qn = sp.get("qualifiedCount")
    if isinstance(_qn, int):
        for _k, _n in (("parlay2", 2), ("parlay3", 3), ("parlay4", 4)):
            if _qn < _n and sp.get(_k):
                add("ERROR", "串关", "合格单场仅 %d 条，%s 却仍出档（硬凑）" % (_qn, _k))
    print("  合格单场 %s 条 | 前缀嵌套 / 总赔递增 / 排名连续 检查完成" % sp.get("qualifiedCount"))
    if found == 0:
        add("WARN", "串关", "今日无串关推荐（候选不满足档位门槛）")


def check_parlay_history(data):
    """串关历史「防截断 / 防消失」专项检查（2026-10-13 事故加固）。

    事故回顾：check_parlay_history() 曾只返回最近 20 条注入页面，
    昨天 14 组只露出 6 组；今天组数继续涨，直接把昨天的推荐全部挤出页面，
    用户翻查时「昨天的推荐不见了」，被误认为数据作假。
    这类 bug 静默且直接伤害信任，必须每轮跑批自动盯防：
      防线1 页面注入量不得少于源文件记录数（任何截断都是事故）
      防线2 最近一个已过去日期（昨天）的组数必须完整可见
      防线3 最新一条记录必须带 snapshot 快照（保存逻辑被改回旧版会丢失回放字段）
    """
    print("· 检查 4.5/6 串关历史完整性（防截断/防消失）")
    src = load("parlay_history.json")
    if not isinstance(src, dict) or not src.get("records"):
        return  # 全新部署无历史文件，不报错
    src_recs = src["records"]
    ph = (data or {}).get("parlayHistory") or {}
    inj = ph.get("records") or []
    if not inj:
        add("ERROR", "串关历史", "matches.json 未注入串关历史（页面历史区将空白）")
        return

    # 防线1：页面注入量不得少于源文件（源文件是唯一真相，少显示=截断复发）
    if len(inj) < len(src_recs):
        add("ERROR", "串关历史",
            "页面只注入 %d/%d 组，存在截断——历史推荐会残缺，昨天的组可能翻不到"
            % (len(inj), len(src_recs)))

    # 防线2：最近一个已过去日期（昨天）的组数必须完整可见
    src_cnt, inj_cnt = {}, {}
    for r in src_recs:
        d = r.get("date")
        if d:
            src_cnt[d] = src_cnt.get(d, 0) + 1
    for r in inj:
        d = r.get("date")
        if d:
            inj_cnt[d] = inj_cnt.get(d, 0) + 1
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    past = sorted(d for d in src_cnt if d < today)
    if past:
        y = past[-1]
        if inj_cnt.get(y, 0) < src_cnt[y]:
            add("ERROR", "串关历史",
                "%s 的推荐页面只显示 %d/%d 组——昨日的组被挤出，用户无法翻查对账"
                % (y, inj_cnt.get(y, 0), src_cnt[y]))
        else:
            print("  %s 推荐 %d 组完整可见（防消失 ✓）" % (y, src_cnt[y]))

    # 防线3：最新一条记录必须带 snapshot（保存逻辑若被改回旧版，回放丢字段）
    newest = max(src_recs, key=lambda r: r.get("savedAt") or "")
    if newest.get("date") == today and "snapshot" not in newest:
        add("WARN", "串关历史",
            "今日最新记录（%s）无 snapshot 快照，锁定回放将丢失卡片字段，"
            "检查 save_parlay_history 是否被改动" % newest.get("savedAt"))
    print("  串关历史：源文件 %d 组 / 页面注入 %d 组" % (len(src_recs), len(inj)))


def check_history(hist):
    print("· 检查 5/6 历史库")
    recs = (hist or {}).get("records", [])
    if not recs:
        add("ERROR", "历史库", "history.json 无记录")
        return
    dates = sorted({r.get("date") for r in recs if r.get("date")})
    no_result = sum(1 for r in recs if not (r.get("result") or {}).get("score"))
    print("  共 %d 条，覆盖 %d 个日期（%s ~ %s），无赛果 %d 条" % (
        len(recs), len(dates), dates[0], dates[-1], no_result))
    if len(recs) < 50:
        add("WARN", "历史库", "历史仅 %d 条，模型统计不可靠" % len(recs))


def check_page():
    print("· 检查 6/6 页面产物")
    p = os.path.join(HERE, "index.html")
    if not os.path.exists(p):
        add("ERROR", "页面", "index.html 不存在")
        return
    with open(p, encoding="utf-8") as f:
        html = f.read()
    left = re.findall(r"__[A-Z_]+_PLACEHOLDER__", html)
    if left:
        add("ERROR", "页面", "存在未替换占位符：%s" % set(left))
    m = re.search(r'const VERSION = "([^"]+)"', html)
    print("  页面版本 %s，大小 %.2f MB" % (m.group(1) if m else "?", len(html.encode()) / 1048576))
    if "分层串关" not in html:
        add("WARN", "页面", "未发现分层串关渲染，可能未重建")

    # 版本一致性：网页版本是唯一真相源，APK 必须跟随。
    # 一旦分叉（如曾经的「网页 v1.2.2 / App v1.5」），用户无法判断手机里是否是最新版。
    try:
        import version_sync
        ver = version_sync.page_version()
        name, code = version_sync.apk_version()
        want = version_sync.ver_code(ver)
        if name != ver.lstrip("v") or code != want:
            add("ERROR", "版本", "APK 版本 %s(%s) 与网页 %s 不一致（应为 %s/%d）"
                % (name, code, ver, ver.lstrip("v"), want))
        else:
            print("  APK 版本 %s(%d) 与网页一致" % (name, code))
    except Exception as e:
        add("WARN", "版本", "版本一致性检查失败：%s" % e)


def check_isolation():
    print("· 检查 7/7 数据源隔离（独立源不得污染核心数据/模型）")
    data = load("matches.json", {})
    ms = (data or {}).get("matches", [])
    leaked = [m.get("num") for m in ms if isinstance(m, dict) and "odds_bsd" in m]
    if leaked:
        add("ERROR", "隔离", "核心 matches.json 仍含 odds_bsd 字段（%d 场），未与独立源解耦" % len(leaked))
    else:
        print("  核心 matches.json 不含 odds_bsd（已解耦）")

    # 独立源文件结构校验（存在即校验合法性；缺失不报错，属正常降级）
    obsd = load("odds_bsd.json")
    if obsd is not None:
        if not isinstance(obsd.get("matches"), list) or not obsd.get("independent"):
            add("WARN", "隔离", "odds_bsd.json 结构异常")
        else:
            print("  独立源 odds_bsd.json：%d 场（The Odds API）" % len(obsd.get("matches", [])))
    fd = load("fd_data.json")
    if fd is not None:
        if not isinstance(fd.get("matches"), list) or fd.get("source") != "football-data.org":
            add("WARN", "隔离", "fd_data.json 结构异常")
        else:
            print("  独立源 fd_data.json：%d 场（football-data.org）" % len(fd.get("matches", [])))
    # 高手荐单（独立展示源）：只校验存在时不污染核心数据
    exp = load("expert_recommendations.json")
    if exp is not None and not isinstance(exp.get("recommendations"), list):
        add("WARN", "隔离", "expert_recommendations.json 结构异常")

    # 竞彩篮球（独立源，v1.7.29）：与足球编号空间不同（篮球 301 起 / 足球 001 起），
    # 校验核心数据零混入 + 篮球文件结构合法
    bk = load("basketball.json")
    if bk is not None:
        bms = bk.get("matches") if isinstance(bk, dict) else None
        if not isinstance(bms, list):
            add("ERROR", "隔离", "basketball.json 结构异常（matches 应为列表）")
        else:
            leak = [m.get("num") for m in ms
                    if isinstance(m, dict) and ("mnl" in m or "hilo" in m or "wnm" in m)]
            if leak:
                add("ERROR", "隔离", "核心 matches.json 混入篮球字段（%d 场）：%s" % (len(leak), leak[:5]))
            print("  独立源 basketball.json：%d 场（篮球编号 %s~%s）"
                  % (len(bms), bms[0].get("num") if bms else "-",
                     bms[-1].get("num") if bms else "-"))
            check_basketball_freshness(bk)


def check_basketball_freshness(bk):
    """篮球数据新鲜度：抓取静默失败的可见性兜底（v1.7.38）。

    背景（2026-10-22 事故）：fetch_basketball.py 按隔离设计「失败只跳过篮球、
    exit 0 保足球主流程」，失败信息只进 stderr；而自举代码包里携带的篮球数据
    快照会让部署继续 Serve 旧数据——结果篮球数据停了 44 小时无人知晓。
    本检查让「停更」在每轮自检里显形，随任务汇报与 selftest_report.json 曝光。

    阈值按任务节奏（9-23 点每 30 分钟一轮、夜间停跑）设定：
      10-22 点（白天）：>3h WARN / >8h ERROR
      9 点 / 23 点（交接）：>12h WARN / >16h ERROR（23 点停跑到次日 9 点约 10h 属正常）
      0-8 点（夜间停跑）：>12h WARN / >24h ERROR
    """
    upd = bk.get("updatedAt") if isinstance(bk, dict) else None
    if not upd:
        add("WARN", "隔离", "basketball.json 无 updatedAt，无法判断新鲜度")
        return
    try:
        t = datetime.datetime.strptime(str(upd)[:19], "%Y-%m-%d %H:%M:%S")
    except ValueError:
        add("WARN", "隔离", "basketball.json updatedAt 无法解析: %r" % upd)
        return
    now = datetime.datetime.now()
    age_h = (now - t).total_seconds() / 3600.0
    if age_h < 0:                      # 沙箱时钟偏差，向前漂移视为新鲜
        print("  篮球数据新鲜度：updatedAt 晚于本机时钟（时钟偏差，跳过）")
        return
    hour = now.hour
    if 10 <= hour <= 22:
        warn_h, err_h = 3, 8
    elif hour in (9, 23):
        warn_h, err_h = 12, 16
    else:
        warn_h, err_h = 12, 24
    tag = "最后更新 %s（%.1f 小时前）" % (upd, age_h)
    if age_h > err_h:
        add("ERROR", "隔离", "篮球数据已停更 %s——fetch_basketball 连续失败或被预算"
            "门槛跳过，页面在 Serve 旧快照，需立即排查" % tag)
    elif age_h > warn_h:
        add("WARN", "隔离", "篮球数据超过 %d 小时未刷新（%s）" % (warn_h, tag))
    else:
        print("  篮球数据新鲜度：%.1f 小时（正常，更新于 %s）" % (age_h, upd))


def check_basketball_ai():
    """篮球预测/串关/统计（v1.7.44）新鲜度与隔离兜底。

    让「篮球 AI 停更 / 串关未生成 / 统计缺失」在每轮自检显形，并守住零耦合红线：
    篮球三份文件不得混入足球字段、预测 id 必须全部来自 basketball.json。
    """
    print("· 检查 8 篮球预测/串关/统计（v1.7.44）新鲜度与隔离")
    bk = load("basketball.json", {})
    bk_ms = (bk or {}).get("matches", []) if isinstance(bk, dict) else []
    # v1.7.119：在售口径改为「尚未开赛且无赛果」。此前把已开赛但赛果未出、
    # 以及停更期残留的旧比赛都算进分母，门禁生效后必然误报「AI 覆盖不足」。
    _bk_now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    bk_unsold_ids = {m.get("id") for m in bk_ms
                     if isinstance(m, dict) and not m.get("score")
                     and (m.get("kickoff") or "")[:16] > _bk_now}

    # 1) 预测篮球_ai.json
    ai = load("basketball_ai.json")
    if ai is None:
        add("WARN", "隔离", "basketball_ai.json 缺失——篮球预测未生成（降级：专区 AI 预测为空）")
    else:
        preds = ai.get("predictions") if isinstance(ai, dict) else None
        if not isinstance(preds, list):
            add("ERROR", "隔离", "basketball_ai.json.predictions 结构异常（应为列表）")
        else:
            if not preds:
                add("WARN", "隔离", "篮球 AI 预测为空——大概率 fetch_basketball_ai 失败，专区预测空白")
            else:
                # 覆盖度：当前在售场应有预测（允许个别比赛四玩法全缺赔率而落榜）
                covered = sum(1 for p in preds if p.get("id") in bk_unsold_ids)
                if bk_unsold_ids and covered < len(bk_unsold_ids):
                    add("WARN", "隔离", "篮球 AI 覆盖不足：%d/%d 在售场有预测"
                        % (covered, len(bk_unsold_ids)))
                else:
                    print("  篮球 AI 预测：%d 场（覆盖在售 %d 场）" % (len(preds), len(bk_unsold_ids)))
                # 四玩法健全：每场含 mnl/hdc/hilo/wnm 且赔率>1
                bad = 0
                for p in preds:
                    pls = p.get("plays") or {}
                    m = next((x for x in bk_ms if x.get("id") == p.get("id")), {})
                    for pk in ("mnl", "hdc", "hilo", "wnm"):
                        if not isinstance(m.get(pk), dict):
                            continue
                        if pk not in pls or not (pls[pk].get("odds", 0) > 1):
                            bad += 1
                if bad:
                    add("WARN", "隔离", "篮球 AI 有 %d 处「有赔率却缺预测」" % bad)
                # 隔离：不得混入足球独立源字段
                if any("odds_bsd" in p for p in preds):
                    add("ERROR", "隔离", "basketball_ai.json 混入 odds_bsd 字段（隔离破防）")
                # 样本薄提示应随预测下发（诚实）
                if ai.get("note"):
                    print("  样本薄提示已下发：%s" % ai["note"][:30] + "…")

    # 2) 串关 basketball_parlay_history.json
    pf = load("basketball_parlay_history.json")
    if pf is None:
        add("WARN", "隔离", "basketball_parlay_history.json 缺失——篮球串关未生成（降级：专区串关为空）")
    else:
        recs = pf.get("records") if isinstance(pf, dict) else None
        if not isinstance(recs, list):
            add("ERROR", "隔离", "basketball_parlay_history.json.records 结构异常")
        else:
            if not recs:
                add("WARN", "隔离", "篮球串关历史为空——fetch_basketball_parlay 未落盘（降级：专区串关空白）")
            else:
                # 最新一组应为近期（今天或昨天），证明串关每日生成
                today = datetime.datetime.now().strftime("%Y-%m-%d")
                yest = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
                # 修复：取所有记录中日期最大的一组（recs[0] 未必是日期最新，
                # 文件中今日组常排在后面，直接取 [0] 会误把旧日期当最新 → 虚假「停更」告警）
                latest = max((r.get("date") for r in recs if r.get("date")), default=None)
                if latest not in (today, yest):
                    add("WARN", "隔离", "篮球串关最新一组 %s 非今/昨（%s）——串关可能停更"
                        % (latest, today))
                else:
                    print("  篮球串关历史：%d 组（最新 %s，命中 %d/错 %d/待 %d）"
                          % (len(recs), latest, pf.get("hit", 0), pf.get("miss", 0), pf.get("pending", 0)))
                # 诚实标记：realEv<0 必 recommended=False
                dishonest = [r for r in recs
                             if isinstance(r.get("realEv"), (int, float)) and r["realEv"] < 0
                             and r.get("recommended") is not False]
                if dishonest:
                    add("ERROR", "隔离", "篮球串关有 %d 组 realEv<0 却标记推荐（诚实破防）" % len(dishonest))
                # 结构对齐足球：含 legs/engineVer
                if any("engineVer" not in r for r in recs):
                    add("WARN", "隔离", "篮球串关记录缺 engineVer（版本溯源缺失）")

    # 3) 统计 basketball_stats.json
    st = load("basketball_stats.json")
    if st is None:
        add("WARN", "隔离", "basketball_stats.json 缺失——篮球历史统计未生成（降级：专区统计空白）")
    else:
        if not isinstance(st, dict) or not isinstance(st.get("roi"), dict):
            add("ERROR", "隔离", "basketball_stats.json 结构异常（缺 roi）")
        else:
            sc = (st.get("sample") or {}).get("scored", 0)
            if sc <= 0:
                add("WARN", "隔离", "篮球统计样本为 0——历史档案无赛果回填")
            else:
                print("  篮球历史统计：样本 %d 条有赛果，ROI 含 %d 玩法"
                      % (sc, len(st.get("roi", {}))))
            if not isinstance(st.get("leagues"), dict):
                add("WARN", "隔离", "basketball_stats.json 缺 leagues 统计")


def check_basketball_backtrack():
    """篮球 AI 预测 / 串关 历史回溯（v1.7.46 新增）完整性。

    让「篮球回溯库缺失 / 串关结算卡死（永远全 pending）」显形：
    - basketball_ai_accuracy.json 必须存在且 history 非空（回溯库已累积）
    - basketball_parlay_history.json 若存在「本应结算却仍 pending」的记录
      （腿 id 命中了有赛果的档案）则判 ERROR——v1.7.46 前 save_parlay_history
      漏写 leg.id/kickoff，结算恒失败 → 全 pending，回溯形同虚设。
    """
    print("· 检查 8.5 篮球 AI/串关历史回溯（v1.7.46）")
    # 1) AI 预测回溯库
    acc = load("basketball_ai_accuracy.json")
    if acc is None:
        add("WARN", "隔离", "basketball_ai_accuracy.json 缺失——篮球 AI 预测回溯未生成"
            "（降级：专区无历史回溯）")
    else:
        h = acc.get("history") if isinstance(acc, dict) else None
        if not isinstance(h, list) or not h:
            add("WARN", "隔离", "篮球 AI 预测回溯库为空——尚未累积任何回溯记录")
        else:
            settled = [r for r in h if r.get("topHit") in (True, False)]
            print("  篮球 AI 预测回溯库：%d 条（已结算 %d 条）" % (len(h), len(settled)))

    # 2) 串关结算不应卡死
    pf = load("basketball_parlay_history.json")
    bkh = load("basketball_history.json", {})
    bkrec = (bkh or {}).get("records", {}) if isinstance(bkh, dict) else {}
    if isinstance(pf, dict) and isinstance(pf.get("records"), list):
        recs = pf["records"]
        stuck = 0
        for r in recs:
            if r.get("result") != "pending":
                continue
            for leg in (r.get("legs") or []):
                rid = leg.get("id")
                if rid and isinstance(bkrec.get(rid, {}).get("score"), list):
                    stuck += 1
                    break
        if stuck:
            add("ERROR", "隔离", "篮球串关有 %d 组本应已结算却仍 pending"
                "（结算逻辑故障，回溯卡死）" % stuck)
        else:
            print("  篮球串关结算：无卡死（hit %d / miss %d / pending %d）"
                  % (pf.get("hit", 0), pf.get("miss", 0), pf.get("pending", 0)))


def check_scorepred_freshness(sp):
    """比分预测数据新鲜度：配置丢失/停更的可见性兜底（v1.7.39）。

    背景（2026-10-21~22 事故）：任务沙箱丢失 fd_config.json（密钥文件被自举包
    排除、沙箱重置后不回），fetch_scores.py 无密钥路径天天把 score_predict.json
    抹成空结构再部署——「比分预测」Tab 空了 5 天无人知晓（用户侧症状：
    「又几天没更新」）。本检查让停更/缺配置在每轮自检显形。

    与篮球检查的差异：比分预测的正常节奏是任务每 30 分钟一轮都刷新
    （--keep-cache 也照样拉展示窗并写 updatedAt），阈值同篮球；另外
    note 里出现「未配置 Key」通常直接 ERROR——那是确定性停更。但 v1.7.45 起缺 Key
    会改走「本地竞彩赔率兜底」（note 含『兜底/本地竞彩』），数据每日随赛程刷新，
    属正常模式，不再判停更，仅走 updatedAt 新鲜度检查（兜底也失效则照样报错）。
    """
    if not isinstance(sp, dict):
        add("WARN", "隔离", "score_predict.json 缺失或结构异常，无法判断新鲜度")
        return
    note = str(sp.get("note") or "")
    # v1.7.45：缺 football-data Key 时 fetch_scores 改走「本地竞彩赔率兜底」，
    # 数据每日随赛程刷新（note 含『兜底/本地竞彩』），此时不应判停更——改走 updatedAt
    # 新鲜度检查即可（兜底若也失效，updatedAt 会变旧，新鲜度检查照样报错）。
    # 仅当「未配置 Key」且『非兜底』（兜底彻底失败、无数据）才确定停更。
    is_fallback = ("兜底" in note) or ("本地竞彩" in note) or \
                  str(sp.get("source") or "").startswith("本地竞彩")
    if "未配置" in note and not is_fallback:
        add("ERROR", "隔离", "比分预测未配置 football-data.org Key（fd_config.json 或环境变量 "
            "FD_API_KEY）且本地竞彩兜底也不可用——模块已停更，页面 Serve 的是旧数据；"
            "请在任务环境变量加 FD_API_KEY 恢复")
        return
    upd = sp.get("updatedAt")
    if not upd:
        add("WARN", "隔离", "score_predict.json 无 updatedAt，无法判断新鲜度")
        return
    try:
        t = datetime.datetime.strptime(str(upd)[:19], "%Y-%m-%d %H:%M:%S")
    except ValueError:
        add("WARN", "隔离", "score_predict.json updatedAt 无法解析: %r" % upd)
        return
    now = datetime.datetime.now()
    age_h = (now - t).total_seconds() / 3600.0
    if age_h < 0:                      # 沙箱时钟偏差，向前漂移视为新鲜
        print("  比分预测新鲜度：updatedAt 晚于本机时钟（时钟偏差，跳过）")
        return
    hour = now.hour
    if 10 <= hour <= 22:
        warn_h, err_h = 3, 8
    elif hour in (9, 23):
        warn_h, err_h = 12, 16
    else:
        warn_h, err_h = 12, 24
    n_match = len(sp.get("matches") or [])
    tag = "最后更新 %s（%.1f 小时前，展示窗 %d 场）" % (upd, age_h, n_match)
    if age_h > err_h:
        add("ERROR", "隔离", "比分预测已停更 %s——fetch_scores 连续失败/缺 Key/被预算"
            "门槛跳过，页面在 Serve 旧数据，需立即排查" % tag)
    elif age_h > warn_h:
        add("WARN", "隔离", "比分预测超过 %d 小时未刷新（%s）" % (warn_h, tag))
    elif n_match == 0:
        add("WARN", "隔离", "比分预测展示窗 0 场（%s）——确认联赛覆盖/接口是否正常" % tag)
    else:
        if is_fallback:
            print("  比分预测新鲜度：%.1f 小时（正常·本地竞彩兜底模式，更新于 %s，%d 场）"
                  % (age_h, upd, n_match))
        else:
            print("  比分预测新鲜度：%.1f 小时（正常，更新于 %s，%d 场）" % (age_h, upd, n_match))


def check_pipeline_safeguards():
    """流水线自愈护栏静态校验（v1.7.46）。

    防止本次修复的两处根因被未来改动误删：
    (1) run_daily.sh 必须有「篮球/比分预测陈旧豁免强制重抓」（步骤2.5）——
        否则单轮被预算门槛跳过就会再次停更；
    (2) 部署决策 SHA 必须含 5 个篮球文件——否则篮球更新了也不触发上线。
    """
    print("· 检查 9 流水线自愈护栏（v1.7.46）")
    try:
        src = open("run_daily.sh", encoding="utf-8").read()
    except Exception:
        add("WARN", "隔离", "run_daily.sh 不可读，跳过自愈护栏校验")
        return
    # (1) 陈旧恢复护栏存在（_py_age 陈旧判定 + 64800s=18h 阈值 + 触发 fetch_basketball）
    if "fetch_basketball.py" in src and "_py_age" in src and "64800" in src:
        print("  篮球/比分预测陈旧豁免重抓护栏：存在")
    else:
        add("ERROR", "隔离", "run_daily.sh 缺少「陈旧豁免强制重抓」护栏（v1.7.46 根治项），"
            "篮球/比分预测将再次面临停更风险")
    # (2) 部署指纹含 5 个篮球文件（+ v1.7.46 篮球 AI 回溯库）
    missing = [f for f in ("basketball.json", "basketball_history.json",
                            "basketball_ai.json", "basketball_stats.json",
                            "basketball_parlay_history.json", "basketball_ai_accuracy.json")
               if ('filehash("%s")' % f) not in src]
    if not missing:
        print("  部署指纹含 5 个篮球文件：是")
    else:
        add("ERROR", "隔离", "run_daily.sh 部署指纹漏算篮球文件：%s（篮球更新不触发上线）"
            % ", ".join(missing))
    # (3) v1.7.129：刷新链路护栏（CI 超时根治）不得被误删
    _r129 = {
        "timeout \"$FETCH_WALL\"": "run_daily.sh 缺 fetch_daily.py 硬墙钟",
        ".ci_official_down": "run_daily.sh 缺『残缺数据部署守卫』",
    }
    for token, msg in _r129.items():
        if token not in src:
            add("ERROR", "刷新链路", msg + "（v1.7.129 根治项）")
    try:
        fd = open("fetch_daily.py", encoding="utf-8").read()
        for token, msg in (("_OFFICIAL_DOWN", "官方接口熔断标志"),
                           ("_official_blocked", "熔断短路判定"),
                           ("JC_FETCH_WALL_SEC", "单进程网络墙钟")):
            if token not in fd:
                add("ERROR", "刷新链路", "fetch_daily.py 缺 %s（CI 将再次 90 分钟超时）" % msg)
    except Exception:
        add("WARN", "刷新链路", "fetch_daily.py 不可读")



def _code_only(html):
    """剥离 CHANGELOG 字符串块与 JS/HTML 注释，只留真正会执行/渲染的代码。
    v1.7.137 护栏用：CHANGELOG 里会描述「已删除 XX 假承诺」，全文匹配会误伤。"""
    import re as _re
    # 1) 去掉 CHANGELOG 数组（从 const CHANGELOG = [ 到匹配的 ];）
    i = html.find("const CHANGELOG = [")
    j = html.find("\n];", i)
    if i >= 0 and j > i:
        html = html[:i] + "/*CHANGELOG_STRIPPED*/" + html[j+3:]
    # 2) 去掉 /* ... */ 块注释与 // 行注释（保留字符串里的 // 由后续精确串判定）
    html = _re.sub(r"/\*[\s\S]*?\*/", "", html)
    html = _re.sub(r"(?m)^\s*//[^\n]*", "", html)
    # 3) 去掉 HTML 注释
    html = _re.sub(r"<!--[\s\S]*?-->", "", html)
    return html


def check_refresh_chain():
    """检查 12 刷新按钮链路（v1.7.137 整体重写）：
    按钮不再赌注定失败的云端 CI，只做它 100% 能真实做到的 ——
    秒级全站同步 + 全站重渲染 + 诚实回执；禁止任何「云端刷新中…完成后
    自动同步」这类从未兑现的假承诺，也禁止静默 POST 触发垃圾 run。
    v1.7.136 旧护栏强制要求 api/refresh?run_id= 轮询 / cloud.newDeploy /
    cloud.ghPat 健康探测，正是「赌 CI」的实现——本版已全部移除，护栏同步升级。"""
    print("· 检查 12 刷新按钮链路（v1.7.137 真实同步 / 不赌 CI / 诚实回执）")
    try:
        t = open("template.html", encoding="utf-8").read()
    except Exception:
        add("ERROR", "刷新链路", "template.html 不可读")
        return
    # (1) 必须存在：真实全站同步 + 全站重渲染 + 诚实回执 + 报告卡
    must = {
        "function triggerRePull": "缺刷新按钮入口",
        "function renderAllTabs": "缺全站重渲染入口（按刷新只会更新当前 Tab）",
        "function refreshAllBadges": "缺全站角标统一重算（角标会显示 0 像没更新）",
        "function renderDataReport": "缺数据状态报告卡（用户要的「有用的报告」）",
        "loadLiveDatasets(false).then": "刷新按钮主路径未即时拉取云端全部数据",
        "window.__lastCloudRefresh": "缺刷新状态留痕（无法核对真实同步结果）",
        "function __dataFresh": "缺数据新鲜度判定（云端旧批次会被误报成同步成功）",
        "function __bjToday": "缺北京时间今日批次判定（设备时区会误判新鲜度）",
        "function watchNewDeploy": "缺云端新部署自动同步（后台上线新批次时页面不会自动同步）",
        'get("auto_pilot_status.json")': "缺巡检留痕数据源（报告卡的保鲜状态会是空的）",
        "已全站同步 ": "缺诚实的全站同步回执",
        "这是云端最新一批": "缺「云端旧批次如实说明」文案（会误导为拉到了新数据）",
    }
    for token, msg in must.items():
        if token not in t:
            add("ERROR", "刷新链路", msg)
    # (2) 严禁：赌 CI 的假承诺 / 静默 POST / 假实时面板 / 吞错
    forbid = {
        'fetch("/api/refresh", {method:"POST", cache:"no-store"}).catch(()=>{})':
            "仍在用 .catch(()=>{}) 吞掉云端刷新错误",
        'fetch("/api/refresh",{method:"POST",cache:"no-store"})':
            "仍在静默 POST 触发注定失败的云端 CI（制造 pending/cancelled 垃圾 run）",
        "api/refresh?run_id=": "仍在轮询 CI run 状态（回到「赌 CI」老路）",
        "cloud.ghPat": "仍残留云端凭证状态机（按钮已不触发 CI）",
        "云端全量刷新已真实发起": "仍残留「云端全量刷新已真实发起」假承诺文案",
        "完成后自动同步": "仍残留「完成后自动同步」假承诺",
        "● 实时": "仍残留假实时「● 实时」面板",
        "距下次数据自动更新": "仍残留「距下次自动更新」倒计时",
        "BATCH_SECS": "仍残留批次倒计时死代码",
        "setInterval(updateClock, 1000)": "仍残留每秒跳秒定时器",
        "setTimeout(__hardReload, 2600)": "仍在无条件 2.6s 硬重载（会闪屏且打断回执）",
        '"已重新加载本页数据"': "仍残留「已重新加载本页数据」假成功文案",
        "已拉取云端全部数据 · 当前批次更新于":
            "仍残留含糊的『已拉取云端全部数据』旧文案",
    }
    code = _code_only(t)   # 只在真实代码里判定，CHANGELOG/注释描述修复的文字不算残留
    for token, msg in forbid.items():
        if token in code:
            add("ERROR", "刷新链路", msg)
    # 统计类数据源必须随刷新一起拉新，且不得再请求云端不部署的 404 大文件
    for f in ("good_rate_stats.json", "vz_high_stats.json", "expert_leaderboard.json",
              "whoscored_recent.json", "whoscored_history.json", "auto_pilot_status.json"):
        if ('get("%s")' % f) not in t and f != "auto_pilot_status.json":
            add("ERROR", "刷新链路", "全站刷新漏拉统计数据源 %s（该面板会停在构建期旧值）" % f)
    if 'get("ab_compare.json")' in t:
        add("ERROR", "刷新链路", "仍在请求云端不部署的 ab_compare.json（必然 404）")
    # (3) 后端函数：保留健康探测供巡检用，且 POST 不得再宣称产出新数据
    try:
        fn = open("functions/api/refresh.js", encoding="utf-8").read()
        if "ghPatConfigured" not in fn or "probed" not in fn:
            add("ERROR", "刷新链路", "refresh.js 缺无参 / ?health=1 健康探测分支（自动巡检 C13 依赖）")
        if "if (!runId)" not in fn:
            add("ERROR", "刷新链路", "refresh.js 健康探测未做「无 run_id 不触发 CI」隔离")
        if "willProduceData: false" not in fn:
            add("WARN", "刷新链路", "refresh.js POST 回执未声明「此处不产出新数据」（可能又给出假承诺）")
        if "云端正在构建并部署" in fn:
            add("ERROR", "刷新链路", "refresh.js 仍宣称「云端正在构建并部署」（注定失败的假承诺）")
    except Exception:
        add("WARN", "刷新链路", "functions/api/refresh.js 不可读")
    # (4) 生效的 workflow 配置：清队列 / 去 push / 收紧超时 / 墙钟
    for wf in (".github/workflows/daily.yml",):
        for path in (os.path.join(HERE, wf), os.path.join(os.path.dirname(HERE), wf)):
            if not os.path.exists(path):
                continue
            w = open(path, encoding="utf-8").read()
            if "cancel-in-progress: true" not in w:
                add("ERROR", "刷新链路", "%s 未开启 cancel-in-progress（僵尸 run 会排队堵塞）" % path)
            if "branches: [main]" in w and "on:" in w:
                import re as _re
                if _re.search(r"^\s*push:\s*$", w, _re.M):
                    add("ERROR", "刷新链路", "%s 仍保留 push 自动触发" % path)
            if "JC_FETCH_WALL_SEC" not in w and "JC_FETCH_TIMEOUT" not in w:
                add("WARN", "刷新链路", "%s 未设置抓取墙钟环境变量" % path)
    print("  刷新按钮：全站真实同步 + 诚实回执 + 数据报告；不赌 CI、不假实时、不吞错")


def check_good_rate(data, hist):
    """检查 10 正路推荐正确率统计（v1.7.124）。

    重点：口径与 history.json 按 judge_hit() 同规则复算比对，防止统计脚本
    悄悄换口径、把未结算/反指场次混进来把正确率做高；再校验竞彩批次隔离、
    独立文件一致性、前端与流水线接线。
    """
    print("· 检查 10 正路推荐正确率统计（v1.7.124）")
    s = (data or {}).get("goodRateStats")
    if not isinstance(s, dict) or not s.get("overall") or not s.get("today"):
        add("ERROR", "正确率统计",
            "matches.json 缺少 goodRateStats（gen_good_rate.py 未跑，或构建前被 fetch_scores 重写覆盖）")
        return
    o, t = s["overall"], s["today"]

    # (1) 与 history.json 官方开奖回溯复算：样本、命中数、正确率必须完全一致
    recs = (hist or {}).get("records", [])
    core = [r for r in recs if r.get("hitFlag") in ("hit", "miss")
            and (r.get("verdict") or {}).get("t") == "good"]
    hits = sum(1 for r in core if r["hitFlag"] == "hit")
    if o.get("n") != len(core) or o.get("hit") != hits:
        add("ERROR", "正确率统计",
            "样本口径与 history.json 不一致：统计 n=%s/hit=%s，复算 n=%s/hit=%s"
            % (o.get("n"), o.get("hit"), len(core), hits))
    elif len(core):
        rate = round(100.0 * hits / len(core), 2)
        if abs(float(o.get("rate") or 0) - rate) > 0.01:
            add("ERROR", "正确率统计",
                "正确率与复算不一致：显示 %s%%，复算 %.2f%%" % (o.get("rate"), rate))
        else:
            print("  口径复算一致：%d 战 %d 中 = %.2f%%" % (len(core), hits, rate))
    if o.get("n") != (o.get("hit") or 0) + (o.get("miss") or 0):
        add("ERROR", "正确率统计", "n ≠ hit + miss，统计结构不自洽")
    w = o.get("wilson95") or []
    if len(w) != 2 or not (0 <= w[0] <= float(o.get("rate") or 0) <= w[1] <= 100):
        add("ERROR", "正确率统计", "Wilson 95% 置信区间异常：%s" % w)
    if (o.get("pricedN") or 0) > (o.get("n") or 0):
        add("ERROR", "正确率统计", "有赔率样本数大于总样本数")

    # (2) 诚实口径必填：不能只报一个漂亮命中率
    for k in ("marketDeVig", "breakEven", "roi", "vsDeVig", "vsBreakEven",
              "testVsDeVig", "testVsBreakEven"):
        if o.get(k) is None:
            add("ERROR", "正确率统计", "缺少关键口径字段 %s（去水隐含/盈亏平衡线/ROI 必须齐全）" % k)
    if "不构成盈利依据" not in (s.get("conclusion") or ""):
        add("ERROR", "正确率统计", "结论缺少「不构成盈利依据」的诚实声明")
    if not (s.get("notes") or []):
        add("ERROR", "正确率统计", "缺少可核对的统计口径说明")

    # (3) 今日竞彩批次隔离：绝不混入周六/周日
    picks = t.get("picks") or []
    if t.get("goodCount") != len(picks):
        add("ERROR", "正确率统计", "今日正路场次数与清单条数不一致")
    prefix = t.get("batchPrefix") or ""
    cross = [p.get("num") for p in picks
             if prefix and not str(p.get("num") or "").startswith(prefix)]
    if cross:
        add("ERROR", "正确率统计", "今日清单混入非本竞彩批次的场次：%s" % ", ".join(map(str, cross)))
    if (t.get("pendingCount") or 0) + (t.get("settledCount") or 0) != len(picks):
        add("ERROR", "正确率统计", "今日已开奖 + 未开奖 ≠ 正路清单条数")
    unsettled_bad = [p.get("num") for p in picks if not p.get("settled") and p.get("hit") is not None]
    if unsettled_bad:
        add("ERROR", "正确率统计", "未开奖场次被错误计入命中：%s" % ", ".join(map(str, unsettled_bad)))

    # (4) 独立统计文件与页面内嵌字段必须同源
    ind = load("good_rate_stats.json")
    if not isinstance(ind, dict):
        add("ERROR", "正确率统计", "缺少独立统计文件 good_rate_stats.json")
    else:
        def sig(x):
            d = json.loads(json.dumps(x))
            d.pop("generatedAt", None)
            return json.dumps(d, ensure_ascii=False, sort_keys=True)
        if sig(ind) != sig(s):
            add("ERROR", "正确率统计", "good_rate_stats.json 与 matches.json.goodRateStats 不同源")

    # (5) 前端模块与每日流水线接线
    try:
        tpl = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
    except Exception:
        tpl = ""
    if "renderGoodRate" not in tpl or 'id="goodRateView"' not in tpl:
        add("ERROR", "正确率统计", "template.html 缺少正路统计渲染模块")
    try:
        sh = open(os.path.join(HERE, "run_daily.sh"), encoding="utf-8").read()
    except Exception:
        sh = ""
    if "gen_good_rate.py" not in sh:
        add("ERROR", "正确率统计", "run_daily.sh 未接入 gen_good_rate.py，刷新后统计不会更新")
    if '"goodRateStats"' not in sh:
        add("ERROR", "正确率统计", "部署指纹未纳入 goodRateStats，统计变化不会触发上线")
    print("  今日批次 %s（%s）：%d 场 / 正路 %d 场 / 已开奖 %d 场"
          % (t.get("batchDate"), t.get("batchLabel"), t.get("totalMatches"),
             len(picks), t.get("settledCount")))


def check_vz_high_stats(data, hist):
    """检查 12 V站 🔥高信心预测比分/方向命中率统计（v1.7.126）。

    重点：按归档原始记录复算样本与命中，防止统计脚本换口径、把未开奖或
    「无法判定」场次混进高信心组把命中率做高；再校验官方赛果一致性、
    竞彩批次隔离、独立文件同源、前端与流水线/部署接线。
    """
    print("· 检查 12 V站 高信心预测命中率统计（v1.7.126）")
    s = (data or {}).get("vzHighStats")
    vh = load("vzhan_history.json", {}) or {}
    recs = [r for r in (vh.get("matches") or {}).values()
            if isinstance(r, dict) and r.get("finalH") is not None
            and r.get("finalA") is not None and r.get("predH") is not None]
    if not isinstance(s, dict) or not s.get("overall") or not s.get("groups") or not s.get("today"):
        add("ERROR", "V站高信心统计",
            "matches.json 缺少 vzHighStats（gen_vz_high_stats.py 未跑，或构建前被 fetch_scores 重写覆盖）")
        return
    if not recs:
        add("ERROR", "V站高信心统计", "vzhan_history.json 无已结算归档，统计无数据支撑")
        return

    def oc(h, a):
        return "H" if h > a else ("A" if a > h else "D")

    def calc(rs):
        return (len(rs),
                sum(1 for r in rs if int(r["predH"]) == int(r["finalH"])
                    and int(r["predA"]) == int(r["finalA"])),
                sum(1 for r in rs if oc(int(r["predH"]), int(r["predA"]))
                    == oc(int(r["finalH"]), int(r["finalA"]))))

    # (1) 样本与命中复算：全量 + 三组
    n, eh, dh = calc(recs)
    o = s["overall"]
    if (o.get("n"), o.get("exactHit"), o.get("dirHit")) != (n, eh, dh):
        add("ERROR", "V站高信心统计",
            "全量口径与归档复算不一致：统计 n=%s/精确%s/方向%s，复算 n=%s/精确%s/方向%s"
            % (o.get("n"), o.get("exactHit"), o.get("dirHit"), n, eh, dh))
    else:
        print("  全量复算一致：%d 场 / 比分精确 %d / 方向命中 %d" % (n, eh, dh))
    hot = [r for r in recs if r.get("confAvailable") and r.get("highConf")]
    normal = [r for r in recs if r.get("confAvailable") and not r.get("highConf")]
    unknown = [r for r in recs if not r.get("confAvailable")]
    for key, rs in (("high", hot), ("normal", normal), ("unknown", unknown)):
        g = s["groups"].get(key) or {}
        cn, ce, cd = calc(rs)
        if (g.get("n"), g.get("exactHit"), g.get("dirHit")) != (cn, ce, cd):
            add("ERROR", "V站高信心统计",
                "%s 组与归档复算不一致：统计 %s/%s/%s，复算 %s/%s/%s"
                % (key, g.get("n"), g.get("exactHit"), g.get("dirHit"), cn, ce, cd))
    if n != len(hot) + len(normal) + len(unknown):
        add("ERROR", "V站高信心统计", "三组样本数之和 ≠ 全量样本数（分组有重叠或漏算）")

    # (2) 官方赛果一致性：归档 finalH/finalA 必须等于 history.json 开奖结果
    off = {}
    for r in (hist or {}).get("records", []):
        res = r.get("result") or {}
        if res.get("cancel") or res.get("home") is None:
            continue
        off.setdefault((r.get("date"), r.get("num")), (int(res["home"]), int(res["away"])))
    bad = []
    for r in recs:
        exp = off.get((r.get("date"), r.get("jcNum")))
        if exp and (int(r["finalH"]), int(r["finalA"])) != exp:
            bad.append(str(r.get("jcNum")))
    if bad:
        add("ERROR", "V站高信心统计", "归档赛果与官方开奖不一致：%s" % ", ".join(bad[:8]))
    else:
        print("  赛果对齐一致：%d 条归档均可在 history.json 找到同场次官方开奖" % len(recs))

    # (3) 诚实口径与统计结构
    for key in ("high", "normal"):
        g = s["groups"].get(key) or {}
        for f in ("exactRate", "exactWilson95", "dirRate", "dirWilson95",
                  "exactBaseline", "dirBaseline"):
            if g.get(f) is None:
                add("ERROR", "V站高信心统计", "%s 组缺少关键字段 %s" % (key, f))
        for rate, ci in (("exactRate", "exactWilson95"), ("dirRate", "dirWilson95")):
            w = g.get(ci) or []
            if len(w) != 2 or not (0 <= w[0] <= (g.get(rate) or 0) <= w[1] <= 100):
                add("ERROR", "V站高信心统计", "%s 组 %s 置信区间异常：%s" % (key, ci, w))
    if "不构成投注建议" not in (s.get("conclusion") or ""):
        add("ERROR", "V站高信心统计", "结论缺少「不构成投注建议」的诚实声明")
    if not (s.get("notes") or []):
        add("ERROR", "V站高信心统计", "缺少可核对的统计口径说明")

    # (4) 今日竞彩批次隔离：绝不混入周六/周日、未开奖不得计命中
    t = s["today"]
    picks = t.get("picks") or []
    if t.get("highCount") != len(picks):
        add("ERROR", "V站高信心统计", "今日高信心场次数与清单条数不一致")
    prefix = t.get("batchPrefix") or ""
    cross = [p.get("num") for p in picks
             if prefix and not str(p.get("num") or "").startswith(prefix)]
    if cross:
        add("ERROR", "V站高信心统计", "今日清单混入非本竞彩批次的场次：%s" % ", ".join(map(str, cross)))
    if (t.get("pendingCount") or 0) + (t.get("settledCount") or 0) != len(picks):
        add("ERROR", "V站高信心统计", "今日已开奖 + 未开奖 ≠ 高信心清单条数")
    unsettled_bad = [p.get("num") for p in picks
                     if not p.get("settled") and (p.get("exactHit") is not None or p.get("dirHit") is not None)]
    if unsettled_bad:
        add("ERROR", "V站高信心统计", "未开奖场次被错误计入命中：%s" % ", ".join(map(str, unsettled_bad)))

    # (5) 独立统计文件与页面内嵌字段必须同源
    ind = load("vz_high_stats.json")
    if not isinstance(ind, dict):
        add("ERROR", "V站高信心统计", "缺少独立统计文件 vz_high_stats.json")
    else:
        def sig(x):
            d = json.loads(json.dumps(x))
            d.pop("generatedAt", None)
            return json.dumps(d, ensure_ascii=False, sort_keys=True)
        if sig(ind) != sig(s):
            add("ERROR", "V站高信心统计", "vz_high_stats.json 与 matches.json.vzHighStats 不同源")

    # (6) 前端模块 / 每日流水线 / 部署清单接线
    try:
        tpl = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
    except Exception:
        tpl = ""
    if "renderVzHighStats" not in tpl or 'id="vzHighStatsView"' not in tpl:
        add("ERROR", "V站高信心统计", "template.html 缺少 V站 高信心统计渲染模块")
    try:
        sh = open(os.path.join(HERE, "run_daily.sh"), encoding="utf-8").read()
    except Exception:
        sh = ""
    if "gen_vz_high_stats.py" not in sh:
        add("ERROR", "V站高信心统计", "run_daily.sh 未接入 gen_vz_high_stats.py，刷新后统计不会更新")
    if '"vzHighStats"' not in sh:
        add("ERROR", "V站高信心统计", "部署指纹未纳入 vzHighStats，统计变化不会触发上线")
    if "backfill_vzhan_history.py" not in sh:
        add("ERROR", "V站高信心统计", "run_daily.sh 未接入 V站 赛果回溯，归档不会自动累积")
    try:
        dep = open(os.path.join(HERE, "deploy_cf.py"), encoding="utf-8").read()
    except Exception:
        dep = ""
    if '"vz_high_stats.json"' not in dep:
        add("ERROR", "V站高信心统计", "deploy_cf.py 未部署 vz_high_stats.json 独立副本")
    print("  今日批次 %s（%s）：竞彩 %d 场 / 高信心 %d 场 / 已开奖 %d 场"
          % (t.get("batchDate"), t.get("batchLabel"), t.get("totalMatches"),
             len(picks), t.get("settledCount")))


def check_vzhan_batch(data):
    """检查 11 V站比分按竞彩批次呈现（v1.7.125）。

    用户「周六的 V站 比分呢」暴露的展示层问题：数据齐全但「今日竞彩」被
    UTC 最新日期误标成明天、V站 59 场周六周日混排且默认折叠。这里校验：
      · vzhan_data.json 每场都有明确的竞彩批次（date + 编号前缀一致）
      · 竞彩当天批次（safeParlay.batchDate）在 V站 数据里存在且有带比分场次
      · template.html 已接入 jcTodayBatch() 权威口径与 V站 批次切换，且不再折叠
    """
    print("· 检查 11 V站比分竞彩批次隔离（v1.7.125）")
    vz = load("vzhan_data.json")
    if not isinstance(vz, dict) or not isinstance(vz.get("matches"), list):
        add("ERROR", "V站批次", "vzhan_data.json 缺失或 matches 非列表")
        return
    ms = vz["matches"]
    if not ms:
        add("WARN", "V站批次", "V站情报 0 场（抓取失败会保留上次数据，请留意）")
        return
    # (1) 每场必须能归入唯一竞彩批次，且编号前缀与 date 的星期一致
    wk = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
    import datetime as _dt
    bad_pref = []
    groups = {}
    for m in ms:
        d = m.get("date") or "未排期"
        groups.setdefault(d, []).append(m)
        pre = str(m.get("jcNum") or "")[:2]
        if d != "未排期" and pre:
            try:
                w = wk[_dt.date.fromisoformat(d).weekday()]
                if w != pre:
                    bad_pref.append("%s(%s≠%s)" % (m.get("jcNum"), pre, w))
            except Exception:
                pass
    if bad_pref:
        add("ERROR", "V站批次", "编号前缀与赛程日期星期不一致：%s" % ", ".join(bad_pref[:6]))

    # (2) 当天批次在 V站 数据里必须有带比分场次（用户要看的「周六 V站比分」）
    # v1.7.130：区分【抓取故障】与【数据源当天未出比分】，不再一律判 ERROR。
    # 实据：2026-11-10 竞彩为英锦标赛/日联杯等小众杯赛，V站网关 UP(61ms/连续失败0)、
    # 情报抓到 8 场且 updatedAt 为当天，只是数据源未给这批场次预测比分。
    # 这种情况属「数据源无覆盖」，如实降级 WARN；网关异常或情报陈旧（疑似抓取失败）
    # 仍必须报 ERROR，避免把真故障悄悄放过。
    bd = ((data or {}).get("safeParlay") or {}).get("batchDate")
    if bd:
        sub = groups.get(bd, [])
        n_pred = sum(1 for m in sub if m.get("hasPred"))
        if not sub:
            add("ERROR", "V站批次", "竞彩当天批次 %s 在 V站 数据中无任何场次" % bd)
        elif n_pred == 0:
            gw = load("vzhan_gateway_status.json", {}) or {}
            gw_up = str(gw.get("status", "")).lower() == "up" and int(gw.get("consecFails") or 0) == 0
            vupd = str(vz.get("updatedAt") or vz.get("updateTime") or "")[:10]
            today = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).strftime("%Y-%m-%d")
            fresh = vupd == today
            if gw_up and fresh:
                add("WARN", "V站批次",
                    "竞彩当天批次 %s 共 %d 场均无 V站 预测比分（网关 UP、情报更新于 %s，"
                    "属数据源当日未覆盖这批小众杯赛，非抓取故障）" % (bd, len(sub), vupd))
            else:
                add("ERROR", "V站批次",
                    "竞彩当天批次 %s 共 %d 场无 V站 预测比分，且网关 status=%s/连续失败=%s、"
                    "情报更新于 %s（疑似抓取故障或数据陈旧）"
                    % (bd, len(sub), gw.get("status") or "?", gw.get("consecFails") or "?", vupd or "?"))
        else:
            print("  竞彩当天批次 %s：%d 场 / 带 V站比分 %d 场 / 在售批次 %s"
                  % (bd, len(sub), n_pred, ", ".join(sorted(groups))))
    # (3) 前端三处日期逻辑接线
    tp = os.path.join(HERE, "template.html")
    if os.path.exists(tp):
        with open(tp, encoding="utf-8") as f:
            t = f.read()
        if "function jcTodayBatch" not in t:
            add("ERROR", "V站批次", "template.html 缺少 jcTodayBatch() 竞彩当天批次权威口径")
        if "vzbatch-chip" not in t:
            add("ERROR", "V站批次", "template.html 缺少 V站 批次切换条")
        if "const _jcToday = jcTodayBatch();" not in t:
            add("ERROR", "V站批次", "比分预测 Tab 的 todayDate 仍未接入竞彩当天批次")
        # V站情报区不应再默认折叠
        import re as _re
        seg = _re.search(r"V站·呼死狗情报.{0,80}", t)
        if seg and 'class="sp-sec collapsed"' in t[t.rfind('<div class="sp-sec', 0, seg.start()):seg.start() + 20]:
            add("WARN", "V站批次", "V站情报区疑似仍默认折叠")


def check_expert_content(data):
    """v1.7.127 高手推荐「文章内容」准确性自检。

    逐篇/逐条复算：方向依据句是否在正文中、比分是否来自比分原句、
    理由/战绩是否含页脚噪音或 HTML 实体、方向值是否合法；
    另核对竞彩当天批次隔离、历史归档文本、流水线与前端接线。
    """
    ed = load("expert_recommendations.json", {})
    if not ed:
        add("ERROR", "高手推荐内容", "expert_recommendations.json 缺失")
        return
    arts = ed.get("articles", [])
    if not arts:
        add("ERROR", "高手推荐内容", "专家文章流为空")
        return
    try:
        from expert_content import verify_recommendation
    except Exception as e:
        add("ERROR", "高手推荐内容", "expert_content.py 无法导入：%s" % str(e)[:60])
        return

    noise = re.compile(r'(1、本站网址|就爱玩球|&nbsp;|喜欢的话可以分享|本站提供|文章观点仅供参考)')
    valid = {"主胜", "客胜", "平局", "主胜/平局", "客胜/平局",
             "让胜", "让平", "让负", "让胜/让平", "让胜/让负", "让平/让负"}
    bad_art, bad_rec = [], []
    total = 0
    for a in arts:
        aid = a.get("id", "?")
        if not a.get("expert"):
            bad_art.append("%s 缺专家署名（空壳文章不得入流）" % aid)
        if not a.get("contentSegments"):
            bad_art.append("%s 缺正文段落，无法回溯核对" % aid)
        ck = a.get("contentCheck") or {}
        if not ck.get("ok"):
            bad_art.append("%s 内容校验未通过：%s" %
                           (aid, "; ".join(ck.get("issues", [])[:2])))
        for f in ("reason", "trackRecord", "contentSummary", "analysis"):
            if noise.search(str(a.get(f) or "")):
                bad_art.append("%s 的 %s 含页脚/HTML 实体噪音" % (aid, f))
        segs = a.get("contentSegments") or []
        for r in a.get("recommendations", []):
            total += 1
            if r.get("recommend") not in valid:
                bad_rec.append("%s 方向值非法：%s" % (aid, r.get("recommend")))
            for f in ("analysis", "evidence", "scoreEvidence"):
                if noise.search(str(r.get(f) or "")):
                    bad_rec.append("%s 的 %s 含噪音" % (aid, f))
            chk = dict(r)
            chk["trackRecord"] = a.get("trackRecord", "")
            ok, issues = verify_recommendation(chk, segs)
            if not ok:
                bad_rec.append("%s [%s]：%s" %
                               (aid, r.get("recommend"), "; ".join(issues)))
    for x in bad_art[:8]:
        add("ERROR", "高手推荐内容", x)
    if len(bad_art) > 8:
        add("ERROR", "高手推荐内容", "另有 %d 篇文章异常" % (len(bad_art) - 8))
    for x in bad_rec[:8]:
        add("ERROR", "高手推荐内容", x)
    if len(bad_rec) > 8:
        add("ERROR", "高手推荐内容", "另有 %d 条推荐异常" % (len(bad_rec) - 8))

    # 竞彩当天批次隔离：推荐编号必须落在本批次赛程里
    batch = ((data.get("safeParlay") or {}).get("batchDate")
             or ed.get("batchDate") or "")
    valid_nums = {m.get("num") for m in data.get("matches", [])
                  if m.get("date") == batch}
    recs = ed.get("recommendations", [])
    if valid_nums:
        cross = [r.get("num") for r in recs if r.get("num") not in valid_nums]
        if cross:
            add("ERROR", "高手推荐内容",
                "推荐混入非本竞彩批次（%s）的编号：%s" % (batch, ", ".join(map(str, cross[:6]))))
    # 历史归档：理由不得残留噪音，存疑标注必须有原文依据
    eh = load("expert_history.json", {})
    dirty = sum(1 for v in eh.values() for r in v if noise.search(str(r.get("reason") or "")))
    if dirty:
        add("ERROR", "高手推荐内容", "历史归档仍有 %d 条理由含页脚噪音/半截句" % dirty)
    disp = [r for v in eh.values() for r in v if r.get("directionDisputed")]
    if any(not r.get("directionEvidence") for r in disp):
        add("ERROR", "高手推荐内容", "历史「方向存疑」标注缺少原文依据")
    # 流水线 / 前端接线
    try:
        rd = open(os.path.join(HERE, "run_daily.sh"), encoding="utf-8").read()
        if "rebuild_expert_history.py" not in rd:
            add("ERROR", "高手推荐内容", "run_daily.sh 未接入历史文章修复")
        if 'filehash("expert_recommendations.json")' not in rd:
            add("ERROR", "高手推荐内容", "部署指纹未纳入高手推荐数据，改动不会触发上线")
        tpl = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
        if "directionEvidence" not in tpl:
            add("ERROR", "高手推荐内容", "前端未展示「方向原文依据」")
        if "contentSummary" not in tpl:
            add("ERROR", "高手推荐内容", "前端未展示文章正文摘要")
        if "directionDisputed" not in tpl:
            add("ERROR", "高手推荐内容", "前端未提示历史方向存疑")
    except Exception as e:
        add("ERROR", "高手推荐内容", "流水线/前端接线检查失败：%s" % str(e)[:60])
    print("  高手推荐内容：%d 篇文章 / %d 条推荐逐条复算，历史存疑标注 %d 条"
          % (len(arts), total, len(disp)))



def check_expert_stats(data):
    """v1.7.128：专家命中率 / 排行榜 / 全部推荐附徽章 的离线一致性复算。"""
    cat = "专家命中率(v1.7.128)"
    ed = load("expert_recommendations.json", {}) or {}
    eh = load("expert_history.json", {}) or {}
    es = load("expert_stats.json", {}) or {}
    lb = load("expert_leaderboard.json", {}) or {}
    stats = es.get("stats", {}) or {}
    board = es.get("leaderboard", []) or []
    meta = es.get("meta", {}) or {}

    try:
        sys.path.insert(0, HERE)
        from fetch_expert import calculate_expert_stats
        recomputed = calculate_expert_stats(eh) or {}
    except Exception as e:
        add("ERROR", cat, "无法导入 fetch_expert.calculate_expert_stats 复算：%s" % e)
        return

    if not stats:
        add("ERROR", cat, "expert_stats.json 无 stats")
        return
    if set(stats.keys()) != set(recomputed.keys()):
        add("ERROR", cat, "专家集合与历史归档不一致：stats %d / 复算 %d"
            % (len(stats), len(recomputed)))
    for name, rc in recomputed.items():
        st = stats.get(name)
        if not st:
            add("ERROR", cat, "缺专家 %s 的战绩" % name)
            continue
        for k in ("judged", "hits", "miss", "pending", "hitRate"):
            if abs(float(st.get(k, 0)) - float(rc.get(k, 0))) > 0.05:
                add("ERROR", cat, "%s 的 %s 不一致：页面 %.1f / 复算 %.1f"
                    % (name, k, float(st.get(k, 0)), float(rc.get(k, 0))))
                break
    print("  · 专家战绩复算一致：%d 位专家" % len(recomputed))

    j_all = sum(x.get("judged", 0) for x in recomputed.values())
    h_all = sum(x.get("hits", 0) for x in recomputed.values())
    p_all = sum(x.get("pending", 0) for x in recomputed.values())
    for k, v in (("judgedRecords", j_all), ("hits", h_all), ("pendingRecords", p_all)):
        if meta.get(k) != v:
            add("ERROR", cat, "meta.%s=%r 与复算 %r 不一致" % (k, meta.get(k), v))

    if not board:
        add("ERROR", cat, "expert_stats.json 缺 leaderboard")
    else:
        ranks = [x.get("rank") for x in board]
        if ranks != list(range(1, len(board) + 1)):
            add("ERROR", cat, "排行榜 rank 不连续：%s" % ranks[:8])
        grp = [0 if int(x.get("judged", 0)) >= 3 else
               (1 if int(x.get("judged", 0)) >= 1 else 2) for x in board]
        for i in range(1, len(board)):
            if grp[i] < grp[i - 1]:
                add("ERROR", cat, "排行榜第 %d 行样本分层倒挂（样本不足未沉底）" % (i + 1))
                break
            if grp[i] == grp[i - 1] and float(board[i - 1].get("hitRate", 0)) < float(board[i].get("hitRate", 0)):
                add("ERROR", cat, "排行榜第 %d 行命中率未降序" % (i + 1))
                break
        if lb.get("leaderboard") and len(lb["leaderboard"]) != len(board):
            add("ERROR", cat, "expert_leaderboard.json 与 expert_stats.json 行数不一致")
        print("  · 排行榜 %d 行，排序与样本分层校验通过" % len(board))

    def chk(item, name, where):
        st = item.get("expertStats")
        if not isinstance(st, dict):
            add("ERROR", cat, "%s 缺 expertStats（专家 %s）" % (where, name))
            return
        ref = stats.get(name)
        if ref:
            if (abs(float(st.get("hitRate", 0)) - float(ref.get("hitRate", 0))) > 0.05
                    or int(st.get("judged", 0)) != int(ref.get("judged", 0))):
                add("ERROR", cat, "%s 的徽章数字与战绩不符（%s）" % (where, name))
        elif int(st.get("judged", 0)) != 0:
            add("ERROR", cat, "%s 无战绩却标了已判定场次（%s）" % (where, name))

    n_main = n_oth = n_art = 0
    for r in ed.get("recommendations", []):
        chk(r, r.get("expertName", ""), "今日推荐主推 %s" % r.get("num", ""))
        n_main += 1
        for o in r.get("otherExperts", []):
            chk(o, o.get("expertName", ""), "同场其他专家 %s" % r.get("num", ""))
            n_oth += 1
    for a in ed.get("articles", []):
        for r in a.get("recommendations", []):
            chk(r, a.get("expert", ""), "文章流推荐 %s" % a.get("id", ""))
            n_art += 1
    print("  · 命中率覆盖：主推 %d / 同场其他 %d / 文章流 %d 条" % (n_main, n_oth, n_art))
    if n_art == 0:
        add("WARN", cat, "文章流无推荐，无法校验覆盖")

    bad_hit = [(d, r.get("expertName")) for d, recs in eh.items() for r in recs
               if r.get("hit") not in (True, False, None)]
    if bad_hit:
        add("ERROR", cat, "历史归档 hit 出现非法值：%s" % bad_hit[:3])
    try:
        tpl = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
        for token in ("expertRateBadge", "专家命中率排行榜", "leaderboardMeta"):
            if token not in tpl:
                add("ERROR", cat, "template.html 缺 %s（前端未接线）" % token)
        sh = open(os.path.join(HERE, "run_daily.sh"), encoding="utf-8").read()
        if "gen_expert_stats.py" not in sh:
            add("ERROR", cat, "run_daily.sh 未接入 gen_expert_stats.py（赛后不会重算）")
    except Exception as e:
        add("ERROR", cat, "读取前端/流水线文件失败：%s" % e)
    print("  · 赛后回填与前端/流水线接线校验完成")


def check_basketball_history_guard():
    """篮球串关历史冷启动自愈护栏（2026-11-11）。

    2026-11-11 事故：deploy_cf.py 的 persistent_data 把篮球串关历史排除出
    code-bundle.tar.gz（设计上应靠 Pages 副本恢复），ensure_history.py 的
    HIST_FILES 却没同步收录；自动任务冷启动时工作区无此文件，脚本从空库
    重建为仅当日 3 组并覆盖线上，用户看到「篮球串关没有历史数据了」。
    同时 fetch_basketball_parlay.py._purge_fake 用 date >= 11-02 的无限窗口，
    把 11-06 之后每天真实推荐在下一轮一并删掉，历史永远无法按天累积。
    """
    cat = "篮球串关历史"
    print("· 检查 13 篮球串关历史冷启动自愈护栏（2026-11-11）")
    try:
        eh = open(os.path.join(HERE, "ensure_history.py"), encoding="utf-8").read()
    except Exception as e:
        add("ERROR", cat, "ensure_history.py 不可读：%s" % e)
        eh = ""
    _tokens = (
        ('"basketball_parlay_history.json"', "HIST_FILES 漏保护篮球串关历史"),
        ('"basketball_ai_accuracy.json"', "HIST_FILES 漏保护篮球 AI 回溯库"),
        ("UNION_RULES", "缺签名并集对账规则表"),
        ("bk_parlay_union", "缺篮球串关并集对账函数"),
        ("bk_accuracy_union", "缺 AI 回溯库并集对账函数"),
    )
    missing = [m for t, m in _tokens if t not in eh]
    if missing:
        for m in missing:
            add("ERROR", cat, "ensure_history.py %s（冷启动将再次清空累积历史）" % m)
    else:
        print("  ensure_history.py 保护名单 + 三路签名并集：完整")

    try:
        fb = open(os.path.join(HERE, "fetch_basketball_parlay.py"),
                  encoding="utf-8").read()
    except Exception as e:
        add("ERROR", cat, "fetch_basketball_parlay.py 不可读：%s" % e)
        fb = ""
    if "FAKE_TO" not in fb:
        add("ERROR", cat, "_purge_fake 缺有限窗口上界（会持续删掉新日期真实推荐）")
    elif 'if (r.get("date") or "") < FAKE_FROM]' in fb:
        add("ERROR", cat, "_purge_fake 仍是无限窗口（历史永远只剩当天一组）")
    else:
        print("  fetch_basketball_parlay.py 停更期清洗为有限窗口：是")

    pf = load("basketball_parlay_history.json", {})
    recs = pf.get("records") if isinstance(pf, dict) else None
    if isinstance(recs, list):
        judged = sum(1 for r in recs if isinstance(r, dict)
                     and r.get("result") in ("hit", "miss"))
        if judged < 20:
            add("ERROR", cat,
                "已结算历史仅 %d 组（应 ≥21）——疑似冷启动从空库重建覆盖了 Pages 副本"
                % judged)
        else:
            print("  已结算历史 %d 组 / 总 %d 组：完整（冷启动覆盖已防住）"
                  % (judged, len(recs)))


def check_parlay_scorepred_refresh():
    """分层串关 / 比分预测「一直不更新」防回归护栏（2026-11-12）。

    用户反馈两个 Tab 长期静止，根因不是没跑流水线，而是：
    ① loadLiveDatasets 只换 BUILT_DATA、不换 state.safeParlay，分层串关
       渲染读的却是 state（载入时快照）→ 刷新后永远是旧批次；
    ② fetch_scores.py 本地兜底只重写 matches，dateIndex/dateList 沿用旧
       文件 → 比分预测「日期回溯」永远停在最后一次 FD 主路径那天；
    ③ utcDate 把含日期的 kickoff 二次拼接成非法 ISO；
    ④ AB_STATS 是构建期 const，命中率区刷新后不更新；
    ⑤ 分层串关 0 档时摘要整行空白，用户看不到本批次与评估时间；
    ⑥ parlay_history.json 顶层统计字段与 records 不同步（数字自相矛盾）。
    """
    cat = "串关/比分刷新"
    print("· 检查 14 分层串关 / 比分预测刷新链路（2026-11-12）")
    try:
        t = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
    except Exception as e:
        add("ERROR", cat, "template.html 不可读：%s" % e)
        t = ""
    _t = (
        ('if(core.safeParlay){', "刷新主路径未同步 state.safeParlay（分层串关将停在旧快照）"),
        ('if(core.highOddsParlay)', "刷新主路径未同步 state.highOddsParlay"),
        ('get("ab_stats.json")', "刷新未拉取 A/B 命中率独立副本"),
        ('let AB_STATS =', "AB_STATS 仍是 const（命中率区刷新不更新）"),
        ('本批次 <b style="color:var(--text)">', "0 档时缺本批次/评估时间摘要"),
    )
    miss = [m for tok, m in _t if tok not in t]
    for m in miss:
        add("ERROR", cat, "template.html " + m)
    if not miss:
        print("  前端：safeParlay 同步 / AB 热更新 / 0 档状态条 齐全")

    try:
        fs = open(os.path.join(HERE, "fetch_scores.py"), encoding="utf-8").read()
    except Exception as e:
        add("ERROR", cat, "fetch_scores.py 不可读：%s" % e)
        fs = ""
    _f = (
        ("本地兜底 dateIndex 增量合并异常跳过", "本地兜底未把当日预测并入 dateIndex"),
        ("date_list = sorted(date_index.keys(), reverse=True)", "dateList 未按索引重建"),
        ('"date": date,', "缺显式竞彩销售日字段"),
    )
    miss2 = [m for tok, m in _f if tok not in fs]
    for m in miss2:
        add("ERROR", cat, "fetch_scores.py " + m)
    if not miss2:
        print("  fetch_scores.py 兜底日期索引增量合并：在位")

    # 数据：dateList 必须含竞彩当天批次（否则历史回溯又会被认为「没更新」）
    sp = load("score_predict.json", {})
    if isinstance(sp, dict):
        dl = sp.get("dateList") or []
        di = sp.get("dateIndex") or {}
        mj = load("matches.json", {})
        bd = ((mj.get("safeParlay") or {}).get("batchDate")) if isinstance(mj, dict) else ""
        if not bd:
            today = (datetime.datetime.now(datetime.timezone.utc) +
                     datetime.timedelta(hours=8)).strftime("%Y-%m-%d")
            bd = today
        if bd not in di:
            add("ERROR", cat, "dateIndex 缺竞彩当天批次 %s（比分预测日期回溯将停在旧日期）" % bd)
        elif bd not in dl:
            add("ERROR", cat, "dateList 缺竞彩当天批次 %s" % bd)
        else:
            print("  比分预测日期回溯含当天批次 %s：是" % bd)
        # utcDate 合法性：不得再出现 "...TYYYY-MM-DD ..." 的二次日期畸形串
        bad = [m.get("utcDate") for m in (sp.get("matches") or [])
               if isinstance(m, dict) and isinstance(m.get("utcDate"), str)
               and len(m["utcDate"]) > 11 and m["utcDate"][11:12].isdigit()
               and re.search(r"T\d{4}-\d{2}-\d{2}", m["utcDate"])]
        if bad:
            add("ERROR", cat, "仍有 %d 条非法 utcDate（kickoff 二次拼日期）" % len(bad))

    # parlay_history 顶层统计必须与 records 自洽
    ph = load("parlay_history.json", {})
    if isinstance(ph, dict) and isinstance(ph.get("records"), list):
        rs = ph["records"]
        hit = sum(1 for r in rs if isinstance(r, dict) and r.get("result") == "hit")
        miss = sum(1 for r in rs if isinstance(r, dict) and r.get("result") == "miss")
        pend = sum(1 for r in rs if isinstance(r, dict) and r.get("result") == "pending")
        for k, v in (("total", len(rs)), ("hit", hit), ("miss", miss), ("pending", pend)):
            if ph.get(k) != v:
                add("ERROR", cat, "parlay_history.json %s=%s 与 records 实算 %s 不一致"
                    % (k, ph.get(k), v))
        else:
            pass
    try:
        dc = open(os.path.join(HERE, "deploy_cf.py"), encoding="utf-8").read()
        if 'ab_stats.json' not in dc:
            add("ERROR", cat, "deploy_cf.py 未生成 ab_stats.json 云端副本")
    except Exception:
        pass


def check_parlay_vzhan_guards():
    """检查 15：分层串关「0 档空壳」/ 比分预测「没有 V站 信息」防回归护栏（2026-11-13）。

    三处结构性根因（不是门槛问题，改回去就会立刻复发）：
      ① 系统时钟漂移（沙箱休眠恢复实测慢 6.5h）→ 竞彩当天批次判成前一天，
         已开赛场次被当成未开赛；主批次排序还把「有推荐」排在「当天」之前。
      ② 每场先按后验把握度选唯一意见（必然 1.1x 低赔正路），之后才判资格，
         同场真正合理的中赔选项在选意见时就被丢掉 → 每天 qualified=0。
      ③ score_predict.json 自身零 V站 字段，只靠前端跨数据集按编号/翻译拼接，
         任一环节失配、日期回溯、离线 APK 都会整体丢失 V站 信息。
    """
    cat = "串关/V站根治"
    print("· 检查 15 分层串关 / V站 信息遗漏防回归（2026-11-13）")

    # ① 权威时间源接线
    try:
        import beijing_clock
        bj_today = beijing_clock.today()
        bj_src = beijing_clock.source()
    except Exception as e:
        add("ERROR", cat, "beijing_clock 不可用：%s" % e)
        bj_today, bj_src = "", "unavailable"
    try:
        rd = open(os.path.join(HERE, "run_daily.sh"), encoding="utf-8").read()
        if "JC_BEIJING_NOW" not in rd:
            add("ERROR", cat, "run_daily.sh 未注入权威北京时间（跨天批次会判错一天）")
    except Exception as e:
        add("ERROR", cat, "run_daily.sh 不可读：%s" % e)
    try:
        fd = open(os.path.join(HERE, "fetch_daily.py"), encoding="utf-8").read()
    except Exception:
        fd = ""
    for tok, msg in (
        ("beijing_clock.today()", "未用权威北京日期判竞彩当天批次"),
        ("_opt_qualified(o)", "缺选项级资格前移（合格中赔单场会被 1.1x 蚊子肉挤掉）"),
        ('0 if b.get("isToday") else 1', "主批次排序未把「竞彩当天」放在「有推荐」之前"),
        ("goal=None", "让球历史样本未回退到跨盘口大样本口径（样本稀疏导致永不达标）"),
        ("if combo_hit < min_joint", "联合概率硬门槛未统一到后验同源口径（双标挡光达标组合）"),
        ("if d_prob <= 0", "隐含概率缺失时仍把「没数据」当成概率 0 一刀切"),
        ("if so is None or n <= 0", "贝叶斯后验仍在 n<20 时丢弃全部实证"),
    ):
        if tok not in fd:
            add("ERROR", cat, "fetch_daily.py " + msg)

    # ② 批次 / 候选池数据自洽
    mj = load("matches.json", {})
    sp = (mj.get("safeParlay") or {}) if isinstance(mj, dict) else {}
    batches = sp.get("batches") or []
    if bj_today and batches:
        main_b = next((b for b in batches if b.get("batchKey") == sp.get("activeBatch")), None)
        if main_b is None:
            add("ERROR", cat, "activeBatch 在 batches 中找不到对应批次")
        elif main_b.get("batchDate") != bj_today:
            add("ERROR", cat, "主批次 %s 与权威竞彩当天 %s 不一致（时钟漂移/批次判错）"
                % (main_b.get("batchDate"), bj_today))
        else:
            print("  主批次 = 权威竞彩当天 %s（时间源 %s）" % (bj_today, bj_src))
            # 有 ≥2 条合格单场却 0 档 → 组合生成链路再次断裂，而非客观证据不足
            _q = main_b.get("qualifiedCount") or 0
            _t = main_b.get("tierCount") or 0
            if _q >= 2 and _t == 0:
                add("ERROR", cat, "当天 %d 条合格单场却 0 档（组合生成链路再次断裂）" % _q)
            else:
                print("  当天合格单场 %d 条 / 达标 %d 档" % (_q, _t))
        for b in batches:
            mc = b.get("matchCount") or 0
            cp = b.get("candidatePool") or []
            qc = b.get("qualifiedCount") or 0
            real_q = sum(1 for c in cp if isinstance(c, dict) and c.get("qualified"))
            if mc >= 3 and not cp:
                add("ERROR", cat, "批次 %s 有 %d 场却 0 条候选（候选池结构性遗漏）"
                    % (b.get("batchLabel"), mc))
            if real_q != qc:
                add("ERROR", cat, "批次 %s qualifiedCount=%s 与候选逐条实算 %s 不一致"
                    % (b.get("batchLabel"), qc, real_q))
        print("  批次 %d 个，候选池 / 合格数逐批自洽" % len(batches))

    # ③ V站 一等字段：源码 + 数据双向护栏
    try:
        fs = open(os.path.join(HERE, "fetch_scores.py"), encoding="utf-8").read()
    except Exception:
        fs = ""
    for tok, msg in (
        ("def _merge_vzhan(result)", "缺 V站 一等字段合并函数"),
        ("_merge_vzhan(result)          #", "未在写盘前调用 V站 合并"),
        ('"num": m.get("num")', "本地兜底未透传竞彩编号（V站 只能靠队名翻译猜测）"),
        ("used = set()", "V站 合并缺去重（队名前缀/日期容差会重复匹配）"),
        ('_utc = (_date + "T" + _hh + ":00")', "主路径本地补全未修非法 utcDate 二次拼日期"),
    ):
        if tok not in fs:
            add("ERROR", cat, "fetch_scores.py " + msg)
    try:
        t = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
    except Exception:
        t = ""
    for tok, msg in (
        ("_recVz", "比分预测卡片未优先读数据源 V站 字段"),
        ("m.vzHasPred", "排序/统计未纳数据源 V站 字段"),
        ("r.vzHasPred && r.vzPredH!=null", "日期回溯未显示 V站 比分"),
    ):
        if tok not in t:
            add("ERROR", cat, "template.html " + msg)

    sc = load("score_predict.json", {})
    vm = (sc.get("vzhanMerged") or {}) if isinstance(sc, dict) else {}
    vz = load("vzhan_data.json", {})
    vz_total = sum(1 for x in (vz.get("matches") or [])
                   if isinstance(x, dict) and x.get("hasPred") and x.get("predH") is not None)
    if not vm:
        add("ERROR", cat, "score_predict.json 缺 vzhanMerged（V站 信息未进入数据源）")
    else:
        matched = vm.get("matched") or 0
        real = sum(1 for m in (sc.get("matches") or [])
                   if isinstance(m, dict) and m.get("vzHasPred") and m.get("vzPredH") is not None)
        if vz_total and matched < vz_total:
            add("ERROR", cat, "V站 合并 %d/%d 场未齐（比分预测会漏显示 V站 信息）"
                % (matched, vz_total))
        if vz_total and matched > vz_total:
            add("ERROR", cat, "V站 合并重复匹配 %d > 当日有预测 %d（去重失效）"
                % (matched, vz_total))
        if real != matched:
            add("ERROR", cat, "vzhanMerged.matched=%s 与 matches 实算 %s 不一致" % (matched, real))
        hist_v = sum(1 for arr in (sc.get("dateIndex") or {}).values()
                     for x in (arr or []) if isinstance(x, dict) and x.get("vzHasPred"))
        if vz_total and not hist_v:
            add("ERROR", cat, "dateIndex 无任何 V站 记录（日期回溯看不到 V站 比分）")
        if vz_total and matched >= vz_total:
            print("  V站 一等字段：展示窗 %d/%d、回溯 %d 条齐全" % (matched, vz_total, hist_v))


def check_auto_pilot_guard():
    """检查 16：自动保鲜自治闭环防回归护栏（2026-11-13，v1.7.134）。

    用户要求「往后不要让我再提醒了，自动的落实这些东西，不要踢一脚做一步，
    不提醒就什么都不做」。真实事故：每小时自动保鲜任务 status=0 被停用，
    lastRunAt 停在 11-12 16:59，14h40m 一次都没跑，无人察觉。
    三层冗余（WorkBuddy 任务 / GitHub Actions / 页面心跳）与 auto_pilot.py
    闭环任一处被改回去或丢失，必须立刻报 ERROR，杜绝「修好又悄悄停摆」。
    """
    cat = "自动保鲜闭环"
    print("· 检查 16 自动保鲜自治闭环防回归（2026-11-13）")

    def read(fn):
        try:
            return open(os.path.join(HERE, fn), encoding="utf-8").read()
        except Exception:
            return ""

    ap = read("auto_pilot.py")
    if not ap:
        add("ERROR", cat, "auto_pilot.py 缺失（定时任务会退回旧版「跑一遍+汇报」）")
    else:
        for tok, msg in (
            ("def patrol(live)", "缺线上 12 项健康巡检"),
            ("def heal_l1(", "缺 L1 定点自愈"),
            ("GITHUB_ACTIONS=1 bash run_daily.sh deploy", "缺每轮必跑的全量刷新"),
            ("python3 selftest.py", "缺自检护栏接入"),
            ("线上复验", "缺线上复验（会假装成功）"),
            ("auto_pilot_status.json", "缺状态留痕"),
            ("beijing_clock", "未接权威北京时间"),
        ):
            if tok not in ap:
                add("ERROR", cat, "auto_pilot.py " + msg)

    dc = read("deploy_cf.py")
    for tok, msg in (
        ("lastPatrolAt", "version.json 未注入巡检心跳（用户看不到系统在自动跑）"),
        ("auto_pilot_status.json", "巡检状态未随部署上云"),
    ):
        if tok not in dc:
            add("ERROR", cat, "deploy_cf.py " + msg)

    if 'filehash("auto_pilot.py")' not in read("run_daily.sh"):
        add("ERROR", cat, "run_daily.sh 部署指纹漏算 auto_pilot.py（改了闭环上不了自举包）")

    tpl = read("template.html")
    for tok, msg in (
        ("__autoFresh", "缺页面自动保鲜心跳（第三层兜底）"),
        ("jcAutoFreshLast", "心跳缺 60 分钟节流（会刷爆 CI）"),
        ("今日推荐已锁定", "锁定态仍会显示「候选 0 / 合格 0」误导"),
    ):
        if tok not in tpl:
            add("ERROR", cat, "template.html " + msg)

    if '"candidateCount", "qualifiedCount", "candidatePool"' not in read("fetch_daily.py"):
        add("ERROR", cat, "fetch_daily.py 生成快照未留存候选/合格统计（锁定回放会显示 0）")

    try:
        st = json.load(open(os.path.join(HERE, "auto_pilot_status.json"), encoding="utf-8"))
        if not st.get("checkedAt"):
            add("ERROR", cat, "auto_pilot_status.json 缺 checkedAt（无法证明自动巡检跑过）")
        else:
            print("  最近自动巡检：%s / health=%s / ERROR=%s" % (
                st.get("checkedAt"), st.get("health"), st.get("errorCount")))
    except Exception as e:
        add("WARN", cat, "auto_pilot_status.json 不可读：%s（首次部署前正常）" % e)


def check_fullsite_refresh_and_cleanup():
    """检查 17（v1.7.137）：全站真实刷新 + 停用/无用内容清理 + 假实时取消 + 数据报告护栏。
    覆盖：renderAllTabs 是否真的调用 9 个足球 Tab + 篮球 6 子页渲染函数、
    全站角标是否统一实算、刷新回执是否落地、视觉噪音是否清干净、
    部署清单是否移除了无用大缓存、版本号是否同步。
    注意：断言一律用 HTML 精确串，避免误伤 CHANGELOG 里对本次修复的文字说明。"""
    print("· 检查 17 全站真实刷新 / 停用清理 / 假实时取消 / 数据报告（v1.7.137）")
    try:
        t = open("template.html", encoding="utf-8").read()
    except Exception:
        add("ERROR", "全站刷新", "template.html 不可读")
        return
    cat = "全站刷新"
    # (1) renderAllTabs 必须真实调用全部 9 个足球 Tab 的渲染函数
    football_tabs = {
        "今日赛程": ["renderStats()", "renderFocus()", "renderFilters()", "renderCards()", "renderTable()"],
        "历史战绩": ["renderHistory()"],
        "强弱对战": ["renderStrongWeak()"],
        "港澳赔率": ["renderHKMO()"],
        "分层串关": ["renderHighOdds()"],
        "高手推荐": ["renderExpert()"],
        "官方赛果": ["renderFD()"],
        "比分预测": ["renderScorePred()"],
    }
    for name, fns in football_tabs.items():
        for fn in fns:
            if fn not in t:
                add("ERROR", cat, "全站刷新缺失「%s」渲染调用 %s" % (name, fn))
    # 篮球 6 子页逐个渲染 + 恢复原选中子页
    for token in ('["sched","hist","ai","parlay","stats","acc"]',
                  "state.bkSubTab = _bkKeep", "renderBasketball()"):
        if token not in t:
            add("ERROR", cat, "篮球子页全站刷新不完整：缺 %s" % token)
    # (2) 角标统一重算 + 刷新回执
    for token in ('setB("todayBdg"', 'setB("highOddsBdg"', 'setB("expertBdg"',
                  "window.__lastRefreshReceipt", "return receipt;", "receipt.tabs.length"):
        if token not in t:
            add("ERROR", cat, "全站角标/刷新回执不完整：缺 %s" % token)
    # (3) 视觉噪音：停用说明、空卡、旧名称必须清干净（用 HTML 精确串避开 CHANGELOG）
    noise_forbid = {
        "📦 以下为历史存档：早期发布过的": "仍残留停用档位「搏击 / 狂击已永久下线」说明",
        "<span>🥊 模型 vs WhoScored 命中率对比</span>": "仍残留旧双源名称（实际是三源对比）",
        "<b>500彩票网北单公开页</b>": "关于弹层仍残留已下线北单数据源说明",
        "<b>北单历史</b>": "关于弹层仍残留已下线北单历史说明",
        "<b>2/3/4/5串1</b>": "关于弹层仍残留过时的串关档位说明",
        "09:00-21:00 每30分钟自动刷新赔率": "关于弹层仍残留过时的更新频率说明",
    }
    code17 = _code_only(t)
    for token, msg in noise_forbid.items():
        if token in code17:
            add("ERROR", cat, msg)
    # 高手推荐：不再逐场生成「暂无专家推荐」空卡，改为汇总一条
    if "暂无专家推荐</div>" in t:
        add("ERROR", cat, "高手推荐仍在逐场生成「暂无专家推荐」空卡")
    if "let _noRecCount = 0" not in t or "if(_noRecCount>0)" not in t:
        add("ERROR", cat, "高手推荐缺「无推荐场次汇总说明」（清理空卡后信息会丢）")
    # (4) 版本号 + v1.7.137 假实时取消 / 数据报告护栏
    if 'const VERSION = "v1.7.137"' not in t:
        add("ERROR", cat, "网页 VERSION 未统一到 v1.7.137（部署脚本按模板哈希自动升版后须全资产对齐）")
    # 假实时面板必须彻底删除（用户明确要求「取消那个实时数据」）
    for token, msg in {
        "● 实时": "仍残留假实时「● 实时」跳秒",
        "距下次数据自动更新": "仍残留「距下次数据自动更新」倒计时",
        "自动刷新:开": "仍残留假「自动刷新开关」",
        "setInterval(updateClock, 1000)": "仍残留每秒跳秒定时器",
        "BATCH_SECS": "仍残留批次倒计时死代码",
    }.items():
        if token in code17:
            add("ERROR", cat, msg)
    # 有用的数据报告卡必须存在且读真实字段
    for token, msg in {
        'class="report-card" id="updBanner"': "缺数据报告卡容器",
        "📊 数据状态报告": "缺报告卡标题",
        "renderDataReport": "缺报告卡渲染函数",
        "赛后回溯命中率（真实结算口径）": "报告卡缺命中率统计区",
        "grO.rate": "报告卡未读正路正确率真实值",
        "spAcc.outcomeHit": "报告卡未读比分预测命中率真实值",
        'run("数据报告", ()=>renderDataReport())': "全站刷新未重算报告卡",
    }.items():
        if token not in t:
            add("ERROR", cat, msg)
    # (5) 部署清单：无用大缓存必须移除
    try:
        d = open("deploy_cf.py", encoding="utf-8").read()
        if '"odds_bsd_cache.json"' in d:
            add("ERROR", cat, "部署清单仍在上传约 3.8MB 的 odds_bsd_cache.json（前端不拉、冷启动不恢复）")
    except Exception:
        add("WARN", cat, "deploy_cf.py 不可读")
    # (6) 前端不再拉已下线半全场死档 / 云端不部署的大文件
    for token in ('get("half_full_history.json")', 'get("ab_compare.json")'):
        if token in t:
            add("ERROR", cat, "刷新链路仍在拉取无用/404 文件：%s" % token)
    print("  全站刷新：9 Tab + 篮球 6 子页 + 全角标 + 诚实回执；假实时已取消、数据报告已上线、停用/空卡/死档已清")


def main():
    strict = "--strict" in sys.argv
    print("=" * 60)
    print("竞彩足球数据分析台 · 数据自检  %s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    print("=" * 60)

    data = load("matches.json", {})
    hist = load("history.json", {})
    check_matches(data)
    check_odds(data)
    check_prob(data)
    check_parlay(data)
    check_parlay_history(data)
    check_history(hist)
    check_page()
    check_isolation()
    check_basketball_ai()
    check_basketball_backtrack()
    check_scorepred_freshness(load("score_predict.json"))
    check_pipeline_safeguards()
    check_good_rate(data, hist)
    check_vz_high_stats(data, hist)
    check_vzhan_batch(data)
    check_expert_content(data)
    check_expert_stats(data)
    check_refresh_chain()
    check_basketball_history_guard()
    check_parlay_scorepred_refresh()
    check_parlay_vzhan_guards()
    check_auto_pilot_guard()
    check_fullsite_refresh_and_cleanup()

    errs = [i for i in issues if i["level"] == "ERROR"]
    warns = [i for i in issues if i["level"] == "WARN"]
    report = {
        "checkedAt": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "errorCount": len(errs),
        "warnCount": len(warns),
        "issues": issues,
    }
    with open(REPORT, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print("-" * 60)
    print("结果：ERROR %d 项 / WARN %d 项 → selftest_report.json" % (len(errs), len(warns)))
    if errs:
        return 1
    if warns and strict:
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
